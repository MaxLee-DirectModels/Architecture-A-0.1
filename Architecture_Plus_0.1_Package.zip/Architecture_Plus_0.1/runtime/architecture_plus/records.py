"""Record contracts and boundary-preserving validators."""

from __future__ import annotations

import re
from typing import Any


SCHEMA_VERSION = "architecture-plus.records/0.1"
OUTCOMES = {"EARNED", "REJECTED", "OPEN"}
PASSAGE_QUALIFICATIONS = {"QUALIFIED", "DISQUALIFIED", "OPEN", "NOT_APPLICABLE"}
DOMAIN_DISPOSITIONS = {"POSITIVE", "NEGATIVE", "ABSENT", "UNKNOWN", "BLOCKED", "CONFLICTED", "INCOMPARABLE", "REDACTED", "EMPTY", "NOT_APPLICABLE"}
COMPLETIONS = {"COMPLETE", "PARTIAL", "NONE"}
PHASES = {"free", "backward", "forward", "hinge", "trial", "binding", "return", "outcome"}
KINDS = {
    "candidate",
    "backward_sweep",
    "forward_sweep",
    "hinge_set",
    "trial",
    "return_envelope",
    "outcome_receipt",
    "note",
    "external_evidence",
    "passage_model",
    "passage_assessment",
    "reentry",
    "binding_set",
    "seal",
}
STAGES = (
    "recommendation",
    "choice",
    "permission",
    "attempt",
    "execution",
    "occurrence",
    "technical_receipt",
    "observation",
    "evaluation",
    "attribution",
    "effect",
    "durability",
)
RESOURCE_ROLES = {
    "payload_or_target",
    "support",
    "input_or_fuel",
    "buffer_or_reserve",
    "tool_or_catalyst",
    "carrier",
    "substrate_or_site",
    "output_or_yield",
    "inheritance_or_option",
    "residue_burden_or_liability",
}
RESOURCE_GATES = (
    "exists",
    "detected_or_represented",
    "reachable",
    "accessible",
    "controllable",
    "permitted",
    "mobilizable_or_extractable",
    "processable_or_convertible",
    "deliverable",
    "usable",
    "yield_producing",
)
ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


class RecordError(ValueError):
    pass


def require_object(value: Any, where: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise RecordError(f"{where} must be an object")
    return value


def require_string(value: Any, where: str, *, nonempty: bool = True) -> str:
    if not isinstance(value, str):
        raise RecordError(f"{where} must be a string")
    if nonempty and not value.strip():
        raise RecordError(f"{where} must not be empty")
    return value


def require_id(value: Any, where: str) -> str:
    result = require_string(value, where)
    if not ID_PATTERN.fullmatch(result):
        raise RecordError(f"{where} has invalid identifier syntax")
    return result


def require_list(value: Any, where: str) -> list[Any]:
    if not isinstance(value, list):
        raise RecordError(f"{where} must be an array")
    return value


def require_string_list(value: Any, where: str, *, nonempty: bool = False) -> list[str]:
    items = require_list(value, where)
    if nonempty and not items:
        raise RecordError(f"{where} must not be empty")
    for index, item in enumerate(items):
        require_string(item, f"{where}[{index}]")
    return items


def require_id_list(value: Any, where: str, *, nonempty: bool = False) -> list[str]:
    items = require_list(value, where)
    if nonempty and not items:
        raise RecordError(f"{where} must not be empty")
    for index, item in enumerate(items):
        require_id(item, f"{where}[{index}]")
    return items


def _only_keys(value: dict[str, Any], allowed: set[str], where: str) -> None:
    extra = sorted(set(value) - allowed)
    if extra:
        raise RecordError(f"{where} contains unknown fields: {', '.join(extra)}")


def validate_run_spec(value: Any) -> dict[str, Any]:
    obj = require_object(value, "RunSpec")
    allowed = {
        "schema_version", "kind", "run_id", "request", "formation_mode",
        "return_contract", "basis", "allowed_tools", "budget", "metadata",
        "requested_output_form", "stakes", "authority", "lineage",
        "unavoidable_policy_ids", "firewall_waivers",
        "formation_context_attestation",
    }
    _only_keys(obj, allowed, "RunSpec")
    if obj.get("schema_version") != SCHEMA_VERSION:
        raise RecordError(f"RunSpec.schema_version must be {SCHEMA_VERSION!r}")
    if obj.get("kind") != "RunSpec":
        raise RecordError("RunSpec.kind must be 'RunSpec'")
    require_id(obj.get("run_id"), "RunSpec.run_id")
    require_string(obj.get("request"), "RunSpec.request")
    mode = obj.get("formation_mode", "NATIVE")
    if mode not in {"NATIVE", "GUIDED"}:
        raise RecordError("RunSpec.formation_mode must be 'NATIVE' or 'GUIDED'")
    contract = require_object(obj.get("return_contract"), "RunSpec.return_contract")
    _only_keys(contract, {"fields", "use", "horizon", "protected", "standing"}, "return_contract")
    fields = require_list(contract.get("fields"), "return_contract.fields")
    if not fields:
        raise RecordError("return_contract.fields must contain at least one field")
    seen: set[str] = set()
    for index, field in enumerate(fields):
        fobj = require_object(field, f"return_contract.fields[{index}]")
        _only_keys(fobj, {"id", "description", "required", "acceptance", "risk_tier"}, f"return field {index}")
        fid = require_id(fobj.get("id"), f"return field {index}.id")
        if fid in seen:
            raise RecordError(f"duplicate return field id: {fid}")
        seen.add(fid)
        require_string(fobj.get("description"), f"return field {fid}.description")
        if "required" in fobj and not isinstance(fobj["required"], bool):
            raise RecordError(f"return field {fid}.required must be boolean")
        if "acceptance" in fobj:
            require_string(fobj["acceptance"], f"return field {fid}.acceptance", nonempty=False)
        if fobj.get("risk_tier", "normal") not in {"low", "normal", "high", "critical"}:
            raise RecordError(f"return field {fid}.risk_tier is invalid")
    require_string(contract.get("use"), "return_contract.use")
    require_string(contract.get("horizon"), "return_contract.horizon")
    protected = require_list(contract.get("protected", []), "return_contract.protected")
    for index, item in enumerate(protected):
        require_string(item, f"return_contract.protected[{index}]")
    if "standing" in contract:
        require_string(contract["standing"], "return_contract.standing", nonempty=False)
    basis = require_list(obj.get("basis", []), "RunSpec.basis")
    basis_ids: set[str] = set()
    for index, item in enumerate(basis):
        bobj = require_object(item, f"basis[{index}]")
        _only_keys(bobj, {"id", "kind", "content", "reference", "expose_to_free", "status"}, f"basis[{index}]")
        bid = require_id(bobj.get("id"), f"basis[{index}].id")
        if bid in basis_ids:
            raise RecordError(f"duplicate basis id: {bid}")
        basis_ids.add(bid)
        require_string(bobj.get("kind"), f"basis[{index}].kind")
        if ("content" in bobj) == ("reference" in bobj):
            raise RecordError(f"basis[{index}] requires exactly one of content or reference")
        if "reference" in bobj:
            require_string(bobj["reference"], f"basis[{index}].reference")
        if "expose_to_free" in bobj and not isinstance(bobj["expose_to_free"], bool):
            raise RecordError(f"basis[{index}].expose_to_free must be boolean")
        if "status" in bobj:
            require_string(bobj["status"], f"basis[{index}].status", nonempty=False)
    tools = require_list(obj.get("allowed_tools", []), "RunSpec.allowed_tools")
    for index, tool in enumerate(tools):
        require_string(tool, f"allowed_tools[{index}]")
    require_string(obj.get("requested_output_form", "best form for the request"), "RunSpec.requested_output_form")
    policy_ids = require_list(obj.get("unavoidable_policy_ids", []), "RunSpec.unavoidable_policy_ids")
    for index, policy_id in enumerate(policy_ids):
        require_id(policy_id, f"unavoidable_policy_ids[{index}]")
    waivers = require_list(obj.get("firewall_waivers", []), "RunSpec.firewall_waivers")
    for index, waiver in enumerate(waivers):
        wobj = require_object(waiver, f"firewall_waivers[{index}]")
        _only_keys(wobj, {"partition", "reason", "authority_ref", "scope"}, f"firewall_waivers[{index}]")
        for key in ("partition", "reason", "authority_ref", "scope"):
            require_string(wobj.get(key), f"firewall_waivers[{index}].{key}")
    if mode == "NATIVE" and waivers:
        raise RecordError("NATIVE formation forbids firewall_waivers")
    if mode == "GUIDED" and not waivers:
        raise RecordError("GUIDED formation requires at least one recorded firewall_waiver")
    if mode == "GUIDED":
        partitions = {waiver["partition"] for waiver in waivers}
        expected = {"GUIDED_TEMPLATE", "RETURN_CONTRACT", "ALL_BASIS"}
        if partitions != expected:
            raise RecordError("GUIDED firewall_waivers must exactly cover GUIDED_TEMPLATE, RETURN_CONTRACT, and ALL_BASIS")
    if "lineage" in obj:
        require_object(obj["lineage"], "RunSpec.lineage")
    if "metadata" in obj:
        require_object(obj["metadata"], "RunSpec.metadata")
    if "formation_context_attestation" in obj:
        attestation = require_object(obj["formation_context_attestation"], "RunSpec.formation_context_attestation")
        _only_keys(attestation, {"outcome", "controller", "scope", "witness_refs", "limits"}, "formation_context_attestation")
        if attestation.get("outcome") not in OUTCOMES:
            raise RecordError("formation_context_attestation.outcome is invalid")
        require_string(attestation.get("controller"), "formation_context_attestation.controller")
        require_string(attestation.get("scope"), "formation_context_attestation.scope")
        require_id_list(attestation.get("witness_refs"), "formation_context_attestation.witness_refs")
        require_string_list(attestation.get("limits"), "formation_context_attestation.limits")
        basis_ids = {item["id"] for item in obj.get("basis", [])}
        unknown_witnesses = sorted(set(attestation.get("witness_refs", [])) - basis_ids)
        if unknown_witnesses:
            raise RecordError(f"formation_context_attestation has unknown witness_refs: {', '.join(unknown_witnesses)}")
        if attestation["outcome"] == "EARNED" and not attestation["witness_refs"]:
            raise RecordError("EARNED formation_context_attestation requires nonempty witness_refs")
    budget = require_object(obj.get("budget", {}), "RunSpec.budget")
    _only_keys(budget, {"max_moves", "max_field_terms", "max_prompt_chars"}, "budget")
    for key in budget:
        if isinstance(budget[key], bool) or not isinstance(budget[key], int) or budget[key] <= 0:
            raise RecordError(f"budget.{key} must be a positive integer")
    return obj


def validate_hinge_set(value: Any, return_ids: set[str]) -> None:
    obj = require_object(value, "HingeSet")
    _only_keys(obj, {"kind", "hinges"}, "HingeSet")
    if obj.get("kind") != "HingeSet":
        raise RecordError("hinge_set artifact.kind must be 'HingeSet'")
    hinges = require_list(obj.get("hinges"), "HingeSet.hinges")
    seen: set[str] = set()
    for index, hinge in enumerate(hinges):
        hobj = require_object(hinge, f"hinges[{index}]")
        _only_keys(hobj, {"hinge_id", "candidate", "rival", "affected_fields", "consequence_split", "basis_refs", "assumptions", "discriminator", "move", "cost", "risk", "contraindications", "status", "expiry_or_reopen"}, f"hinges[{index}]")
        hid = require_id(hobj.get("hinge_id"), f"hinges[{index}].hinge_id")
        if hid in seen:
            raise RecordError(f"duplicate hinge_id: {hid}")
        seen.add(hid)
        candidate = require_string(hobj.get("candidate"), f"hinge {hid}.candidate")
        rival = require_string(hobj.get("rival"), f"hinge {hid}.rival")
        if candidate.strip().casefold() == rival.strip().casefold():
            raise RecordError(f"hinge {hid} candidate and rival must differ")
        changes = require_id_list(hobj.get("affected_fields"), f"hinge {hid}.affected_fields", nonempty=True)
        unknown = sorted(set(changes) - return_ids)
        if unknown:
            raise RecordError(f"hinge {hid} names unknown return fields: {', '.join(unknown)}")
        split = require_object(hobj.get("consequence_split"), f"hinge {hid}.consequence_split")
        _only_keys(split, {"candidate", "rival"}, f"hinge {hid}.consequence_split")
        candidate_consequence = require_string(split.get("candidate"), f"hinge {hid}.consequence_split.candidate")
        rival_consequence = require_string(split.get("rival"), f"hinge {hid}.consequence_split.rival")
        if candidate_consequence.strip().casefold() == rival_consequence.strip().casefold():
            raise RecordError(f"hinge {hid} consequence split must differ")
        require_id_list(hobj.get("basis_refs"), f"hinge {hid}.basis_refs")
        require_string_list(hobj.get("assumptions"), f"hinge {hid}.assumptions")
        require_string(hobj.get("discriminator"), f"hinge {hid}.discriminator")
        require_string(hobj.get("move"), f"hinge {hid}.move")
        require_string(hobj.get("cost"), f"hinge {hid}.cost")
        require_string(hobj.get("risk"), f"hinge {hid}.risk")
        require_string_list(hobj.get("contraindications"), f"hinge {hid}.contraindications")
        if hobj.get("status") not in {"CANDIDATE", "ADMITTED", "REJECTED", "OPEN", "RETIRED"}:
            raise RecordError(f"hinge {hid}.status is invalid")
        if not isinstance(hobj.get("expiry_or_reopen"), (str, dict, list)):
            raise RecordError(f"hinge {hid}.expiry_or_reopen must be a string, object, or array")


def validate_return_envelope(value: Any, return_ids: set[str]) -> None:
    obj = require_object(value, "ReturnEnvelope")
    _only_keys(obj, {"kind", "components", "reverse_trace", "assumptions", "residuals", "stop_basis"}, "ReturnEnvelope")
    if obj.get("kind") != "ReturnEnvelope":
        raise RecordError("return_envelope artifact.kind must be 'ReturnEnvelope'")
    components = require_list(obj.get("components"), "ReturnEnvelope.components")
    seen: set[str] = set()
    for index, component in enumerate(components):
        cobj = require_object(component, f"components[{index}]")
        _only_keys(cobj, {"field_id", "native_return", "outcome", "domain_disposition", "completion", "basis_refs", "binding_refs", "dependency_refs", "depends_on_fields", "counterwitness_refs", "assumptions", "support_ceiling", "residual", "reentry", "limits", "open_certificate"}, f"components[{index}]")
        field_id = require_id(cobj.get("field_id"), f"components[{index}].field_id")
        if field_id not in return_ids:
            raise RecordError(f"return component names unknown field: {field_id}")
        if field_id in seen:
            raise RecordError(f"duplicate return component: {field_id}")
        seen.add(field_id)
        if cobj.get("outcome") not in OUTCOMES:
            raise RecordError(f"component {field_id}.outcome must be EARNED, REJECTED, or OPEN")
        for key in ("native_return", "domain_disposition", "completion", "assumptions", "support_ceiling", "residual", "reentry"):
            if key not in cobj:
                raise RecordError(f"component {field_id} lacks {key}")
        if cobj["domain_disposition"] not in DOMAIN_DISPOSITIONS:
            raise RecordError(f"component {field_id}.domain_disposition is invalid")
        if cobj["completion"] not in COMPLETIONS:
            raise RecordError(f"component {field_id}.completion is invalid")
        require_list(cobj["assumptions"], f"component {field_id}.assumptions")
        require_string(cobj["support_ceiling"], f"component {field_id}.support_ceiling")
        require_list(cobj["residual"], f"component {field_id}.residual")
        if not isinstance(cobj["reentry"], (str, dict, list)):
            raise RecordError(f"component {field_id}.reentry must be a string, object, or array")
        for key in ("basis_refs", "binding_refs", "dependency_refs", "depends_on_fields"):
            if key not in cobj:
                raise RecordError(f"component {field_id} lacks {key}")
            require_id_list(cobj[key], f"component {field_id}.{key}")
        if not (cobj["basis_refs"] or cobj["binding_refs"] or cobj["dependency_refs"]):
            raise RecordError(f"component {field_id} requires at least one reverse reference")
        counterwitnesses = require_id_list(cobj.get("counterwitness_refs", []), f"component {field_id}.counterwitness_refs")
        if cobj["outcome"] == "REJECTED" and not counterwitnesses:
            raise RecordError(f"REJECTED component {field_id} requires counterwitness_refs")
        unknown_fields = sorted(set(cobj.get("depends_on_fields", [])) - return_ids)
        if unknown_fields:
            raise RecordError(f"component {field_id} depends on unknown fields: {', '.join(unknown_fields)}")
        if "limits" in cobj:
            require_string_list(cobj["limits"], f"component {field_id}.limits")
        if cobj.get("outcome") == "OPEN":
            cert = require_object(cobj.get("open_certificate"), f"component {field_id}.open_certificate")
            _only_keys(cert, {"first_exact_break", "deepest_supported_prefix", "affected_fields", "unaffected_fields", "remaining_obligations", "needed", "reverse_evidence", "assumptions", "support_ceiling", "earliest_useful_reentry", "artifact_fingerprint", "unexamined_scope"}, f"component {field_id}.open_certificate")
            for key in (
                "first_exact_break", "deepest_supported_prefix", "affected_fields", "unaffected_fields",
                "remaining_obligations", "needed", "reverse_evidence", "assumptions",
                "support_ceiling", "earliest_useful_reentry", "artifact_fingerprint", "unexamined_scope",
            ):
                if key not in cert:
                    raise RecordError(f"OPEN component {field_id} lacks {key}")
            require_string(cert["first_exact_break"], f"component {field_id}.first_exact_break", nonempty=False)
            require_string(cert["support_ceiling"], f"component {field_id}.support_ceiling", nonempty=False)
            if not isinstance(cert["earliest_useful_reentry"], (str, dict, list)):
                raise RecordError(f"component {field_id}.earliest_useful_reentry must be a string, object, or array")
            if not isinstance(cert["unexamined_scope"], (str, dict, list)):
                raise RecordError(f"component {field_id}.unexamined_scope must be a string, object, or array")
            affected = set(require_id_list(cert["affected_fields"], f"component {field_id}.affected_fields"))
            unaffected = set(require_id_list(cert["unaffected_fields"], f"component {field_id}.unaffected_fields"))
            if field_id not in affected:
                raise RecordError(f"OPEN component {field_id} must list itself in affected_fields")
            if affected & unaffected:
                raise RecordError(f"OPEN component {field_id} overlaps affected and unaffected fields")
            if (affected | unaffected) != return_ids:
                raise RecordError(f"OPEN component {field_id} must partition all declared return fields")
            needed = require_object(cert["needed"], f"component {field_id}.needed")
            _only_keys(needed, {"evidence", "event", "permission", "choice", "capability"}, f"component {field_id}.needed")
            for need in ("evidence", "event", "permission", "choice", "capability"):
                require_list(needed.get(need), f"component {field_id}.needed.{need}")
            require_list(cert["remaining_obligations"], f"component {field_id}.remaining_obligations")
            require_id_list(cert["reverse_evidence"], f"component {field_id}.reverse_evidence")
            require_list(cert["assumptions"], f"component {field_id}.assumptions")
            fingerprint = require_string(cert["artifact_fingerprint"], f"component {field_id}.artifact_fingerprint")
            if not re.fullmatch(r"sha256:[0-9a-f]{64}", fingerprint):
                raise RecordError(f"component {field_id}.artifact_fingerprint must be sha256:<64 lowercase hex>")
            from .canonical import digest_json
            expected = "sha256:" + digest_json({key: item for key, item in cert.items() if key != "artifact_fingerprint"})
            if fingerprint != expected:
                raise RecordError(f"component {field_id}.artifact_fingerprint mismatch")
    missing = sorted(return_ids - seen)
    if missing:
        raise RecordError(f"ReturnEnvelope omits return fields: {', '.join(missing)}")
    require_list(obj.get("assumptions"), "ReturnEnvelope.assumptions")
    require_list(obj.get("residuals"), "ReturnEnvelope.residuals")
    reverse_trace = require_object(obj.get("reverse_trace"), "ReturnEnvelope.reverse_trace")
    if set(reverse_trace) != return_ids:
        raise RecordError("ReturnEnvelope.reverse_trace must contain exactly every declared return field")
    for field_id, refs in reverse_trace.items():
        require_id_list(refs, f"ReturnEnvelope.reverse_trace.{field_id}")
        if not refs:
            raise RecordError(f"ReturnEnvelope.reverse_trace.{field_id} must not be empty")
        component = next(item for item in components if item["field_id"] == field_id)
        declared = set(component["basis_refs"]) | set(component["binding_refs"]) | set(component["dependency_refs"])
        if not set(refs).issubset(declared):
            raise RecordError(f"ReturnEnvelope.reverse_trace.{field_id} contains undeclared refs")
    validate_stop_basis(obj.get("stop_basis"))


def validate_outcome_receipt(value: Any) -> None:
    obj = require_object(value, "OutcomeReceipt")
    _only_keys(obj, {"kind", "stages", "successor_signature", "attribution_limits", "learning_updates", "reopen_triggers"}, "OutcomeReceipt")
    if obj.get("kind") != "OutcomeReceipt":
        raise RecordError("outcome_receipt artifact.kind must be 'OutcomeReceipt'")
    stages = require_object(obj.get("stages"), "OutcomeReceipt.stages")
    unknown = sorted(set(stages) - set(STAGES))
    if unknown:
        raise RecordError(f"OutcomeReceipt has unknown stages: {', '.join(unknown)}")
    missing = sorted(set(STAGES) - set(stages))
    if missing:
        raise RecordError(f"OutcomeReceipt is missing stages: {', '.join(missing)}")
    runtime_open_stages = set(STAGES[1:])
    for stage, record in stages.items():
        robj = require_object(record, f"OutcomeReceipt.stages.{stage}")
        _only_keys(robj, {"actor", "time", "basis_refs", "evidence_refs", "outcome", "disposition", "native_result", "limits"}, f"OutcomeReceipt.stages.{stage}")
        require_string(robj.get("actor"), f"OutcomeReceipt.stages.{stage}.actor")
        require_string(robj.get("time"), f"OutcomeReceipt.stages.{stage}.time")
        basis = require_id_list(robj.get("basis_refs"), f"OutcomeReceipt.stages.{stage}.basis_refs")
        evidence = require_id_list(robj.get("evidence_refs"), f"OutcomeReceipt.stages.{stage}.evidence_refs")
        if robj.get("outcome") not in OUTCOMES:
            raise RecordError(f"OutcomeReceipt stage {stage}.outcome is invalid")
        if robj.get("disposition") not in DOMAIN_DISPOSITIONS:
            raise RecordError(f"OutcomeReceipt stage {stage}.disposition is invalid")
        if stage in runtime_open_stages and (
            robj["outcome"] != "OPEN" or robj["disposition"] not in {"UNKNOWN", "NOT_APPLICABLE"}
        ):
            raise RecordError(
                f"OutcomeReceipt stage {stage} requires OPEN with UNKNOWN or NOT_APPLICABLE; "
                "0.1 has no typed external stage profile"
            )
        if "native_result" not in robj:
            raise RecordError(f"OutcomeReceipt stage {stage} lacks native_result")
        limits = require_string_list(robj.get("limits"), f"OutcomeReceipt.stages.{stage}.limits")
        if robj["disposition"] not in {"UNKNOWN", "NOT_APPLICABLE"} and not evidence:
            raise RecordError(f"OutcomeReceipt stage {stage} requires evidence_refs or explicit UNKNOWN/NOT_APPLICABLE")
        if robj["disposition"] in {"UNKNOWN", "NOT_APPLICABLE"} and not limits:
            raise RecordError(f"OutcomeReceipt stage {stage} must explain explicit {robj['disposition']}")
    successor = require_object(obj.get("successor_signature"), "OutcomeReceipt.successor_signature")
    _only_keys(
        successor,
        {"outcome", "opened", "closed", "preserved", "redirected", "basis_refs", "support_ceiling", "unknowns"},
        "OutcomeReceipt.successor_signature",
    )
    if successor.get("outcome") != "OPEN":
        raise RecordError("OutcomeReceipt.successor_signature must remain OPEN in the 0.1 reference runtime")
    for key in ("opened", "closed", "preserved", "redirected"):
        if successor.get(key) != "OPEN":
            raise RecordError(f"OutcomeReceipt.successor_signature.{key} must be OPEN")
    require_id_list(successor.get("basis_refs"), "OutcomeReceipt.successor_signature.basis_refs")
    require_string(successor.get("support_ceiling"), "OutcomeReceipt.successor_signature.support_ceiling")
    require_string_list(successor.get("unknowns"), "OutcomeReceipt.successor_signature.unknowns", nonempty=True)
    require_string_list(obj.get("attribution_limits"), "OutcomeReceipt.attribution_limits")
    learning = require_list(obj.get("learning_updates"), "OutcomeReceipt.learning_updates")
    if learning:
        raise RecordError("OutcomeReceipt.learning_updates must be empty until a typed external consequence profile exists")
    triggers = require_list(obj.get("reopen_triggers"), "OutcomeReceipt.reopen_triggers")
    for index, trigger in enumerate(triggers):
        tobj = require_object(trigger, f"OutcomeReceipt.reopen_triggers[{index}]")
        _only_keys(tobj, {"trigger", "action", "affected_stages", "needed_refs"}, f"OutcomeReceipt.reopen_triggers[{index}]")
        require_string(tobj.get("trigger"), f"OutcomeReceipt.reopen_triggers[{index}].trigger")
        require_string(tobj.get("action"), f"OutcomeReceipt.reopen_triggers[{index}].action")
        affected = require_string_list(tobj.get("affected_stages"), f"OutcomeReceipt.reopen_triggers[{index}].affected_stages", nonempty=True)
        unknown_stages = sorted(set(affected) - set(STAGES))
        if unknown_stages:
            raise RecordError(f"OutcomeReceipt.reopen_triggers[{index}] has unknown stages: {', '.join(unknown_stages)}")
        require_id_list(tobj.get("needed_refs"), f"OutcomeReceipt.reopen_triggers[{index}].needed_refs")


def validate_binding_set(value: Any, return_ids: set[str]) -> None:
    obj = require_object(value, "BindingSet")
    _only_keys(obj, {"kind", "bindings"}, "BindingSet")
    if obj.get("kind") != "BindingSet":
        raise RecordError("binding_set artifact.kind must be 'BindingSet'")
    bindings = require_list(obj.get("bindings"), "BindingSet.bindings")
    seen: set[str] = set()
    for index, binding in enumerate(bindings):
        bobj = require_object(binding, f"bindings[{index}]")
        _only_keys(bobj, {"binding_id", "binding_type", "statement", "status", "scope", "affected_fields", "hinge_refs", "trial_refs", "basis_refs", "dependencies", "warrant", "cost", "contraindications", "expiry", "reopen_conditions"}, f"bindings[{index}]")
        bid = require_id(bobj.get("binding_id"), f"bindings[{index}].binding_id")
        if bid in seen:
            raise RecordError(f"duplicate binding_id: {bid}")
        seen.add(bid)
        require_string(bobj.get("binding_type"), f"binding {bid}.binding_type")
        require_string(bobj.get("statement"), f"binding {bid}.statement")
        require_string(bobj.get("scope"), f"binding {bid}.scope")
        if bobj.get("status") not in {"ADMITTED", "REJECTED", "OPEN"}:
            raise RecordError(f"binding {bid}.status must be ADMITTED, REJECTED, or OPEN")
        fields = require_id_list(bobj.get("affected_fields"), f"binding {bid}.affected_fields", nonempty=True)
        unknown = sorted(set(fields) - return_ids)
        if unknown:
            raise RecordError(f"binding {bid} names unknown fields: {', '.join(unknown)}")
        for key in ("hinge_refs", "trial_refs", "basis_refs", "dependencies"):
            require_id_list(bobj.get(key), f"binding {bid}.{key}")
        for key in ("contraindications", "reopen_conditions"):
            require_string_list(bobj.get(key), f"binding {bid}.{key}")
        warrant = require_object(bobj.get("warrant"), f"binding {bid}.warrant")
        _only_keys(warrant, {"rule", "verifier", "scope", "standing_ceiling", "status", "witness_refs"}, f"binding {bid}.warrant")
        for key in ("rule", "verifier", "scope", "standing_ceiling"):
            require_string(warrant.get(key), f"binding {bid}.warrant.{key}")
        if warrant.get("status") not in {"SUPPORTED", "OPEN", "REJECTED"}:
            raise RecordError(f"binding {bid}.warrant.status is invalid")
        witnesses = require_id_list(warrant.get("witness_refs"), f"binding {bid}.warrant.witness_refs")
        expected_warrant = {"ADMITTED": "SUPPORTED", "OPEN": "OPEN", "REJECTED": "REJECTED"}[bobj["status"]]
        if warrant["status"] != expected_warrant:
            raise RecordError(f"binding {bid} status and warrant.status disagree")
        if bobj["status"] == "ADMITTED" and not witnesses:
            raise RecordError(f"admitted binding {bid} requires warrant witness_refs")
        if bobj["status"] == "REJECTED" and not witnesses:
            raise RecordError(f"rejected binding {bid} requires counterwitness refs in its warrant")
        if bobj["status"] == "ADMITTED" and (not bobj.get("contraindications") or not bobj.get("reopen_conditions")):
            raise RecordError(f"admitted binding {bid} requires contraindications and reopen_conditions")
        require_string(bobj.get("cost"), f"binding {bid}.cost")
        if not isinstance(bobj.get("expiry"), (str, dict, list)):
            raise RecordError(f"binding {bid}.expiry must be a string, object, or array")


def validate_trial_set(value: Any, return_ids: set[str]) -> None:
    obj = require_object(value, "TrialSet")
    _only_keys(obj, {"kind", "trials"}, "TrialSet")
    if obj.get("kind") != "TrialSet":
        raise RecordError("trial artifact.kind must be 'TrialSet'")
    trials = require_list(obj.get("trials"), "TrialSet.trials")
    seen: set[str] = set()
    for index, trial in enumerate(trials):
        tobj = require_object(trial, f"trials[{index}]")
        _only_keys(tobj, {"trial_id", "hinge_id", "candidate", "rival", "shared_criteria", "discriminator", "move", "execution_status", "matched_budget", "matched_tools", "observations", "evidence_refs", "uncertainty", "limitations", "result", "declared_update", "changed_return_fields"}, f"trials[{index}]")
        trial_id = require_id(tobj.get("trial_id"), f"trials[{index}].trial_id")
        if trial_id in seen:
            raise RecordError(f"duplicate trial_id: {trial_id}")
        seen.add(trial_id)
        require_id(tobj.get("hinge_id"), f"trial {trial_id}.hinge_id")
        candidate = require_string(tobj.get("candidate"), f"trial {trial_id}.candidate")
        rival = require_string(tobj.get("rival"), f"trial {trial_id}.rival")
        if candidate.strip().casefold() == rival.strip().casefold():
            raise RecordError(f"trial {trial_id} candidate and rival must differ")
        require_string_list(tobj.get("shared_criteria"), f"trial {trial_id}.shared_criteria", nonempty=True)
        require_string(tobj.get("discriminator"), f"trial {trial_id}.discriminator")
        require_string(tobj.get("move"), f"trial {trial_id}.move")
        execution_status = tobj.get("execution_status")
        if execution_status not in {"DESIGNED", "EXECUTED"}:
            raise RecordError(f"trial {trial_id}.execution_status is invalid")
        budget = require_object(tobj.get("matched_budget"), f"trial {trial_id}.matched_budget")
        _only_keys(budget, {"candidate", "rival", "unit", "matched", "unmatched_reason"}, f"trial {trial_id}.matched_budget")
        for key in ("candidate", "rival"):
            if isinstance(budget.get(key), bool) or not isinstance(budget.get(key), int) or budget[key] < 0:
                raise RecordError(f"trial {trial_id}.matched_budget.{key} must be a nonnegative integer")
        require_string(budget.get("unit"), f"trial {trial_id}.matched_budget.unit")
        if not isinstance(budget.get("matched"), bool):
            raise RecordError(f"trial {trial_id}.matched_budget.matched must be boolean")
        if budget["matched"] and budget["candidate"] != budget["rival"]:
            raise RecordError(f"trial {trial_id} declares unequal budget as matched")
        if not budget["matched"]:
            require_string(budget.get("unmatched_reason"), f"trial {trial_id}.matched_budget.unmatched_reason")
        tools = require_object(tobj.get("matched_tools"), f"trial {trial_id}.matched_tools")
        _only_keys(tools, {"candidate", "rival", "matched", "unmatched_reason"}, f"trial {trial_id}.matched_tools")
        candidate_tools = require_string_list(tools.get("candidate"), f"trial {trial_id}.matched_tools.candidate")
        rival_tools = require_string_list(tools.get("rival"), f"trial {trial_id}.matched_tools.rival")
        if not isinstance(tools.get("matched"), bool):
            raise RecordError(f"trial {trial_id}.matched_tools.matched must be boolean")
        tools_equal = sorted(set(candidate_tools)) == sorted(set(rival_tools))
        if tools["matched"] != tools_equal:
            raise RecordError(f"trial {trial_id}.matched_tools.matched disagrees with declared access")
        if not tools["matched"]:
            require_string(tools.get("unmatched_reason"), f"trial {trial_id}.matched_tools.unmatched_reason")
        require_string_list(tobj.get("observations"), f"trial {trial_id}.observations")
        require_id_list(tobj.get("evidence_refs"), f"trial {trial_id}.evidence_refs")
        require_string_list(tobj.get("uncertainty"), f"trial {trial_id}.uncertainty")
        require_string_list(tobj.get("limitations"), f"trial {trial_id}.limitations")
        if tobj.get("result") not in {"SUPPORTS_A", "SUPPORTS_B", "INCOMPARABLE", "REJECTED", "OPEN"}:
            raise RecordError(f"trial {trial_id}.result is invalid")
        if execution_status == "DESIGNED" and (tobj["result"] != "OPEN" or tobj.get("observations") or tobj.get("evidence_refs")):
            raise RecordError(f"DESIGNED trial {trial_id} must remain OPEN with no observations or evidence_refs")
        if execution_status == "EXECUTED" and (not tobj.get("observations") or not tobj.get("evidence_refs")):
            raise RecordError(f"EXECUTED trial {trial_id} requires observations and evidence_refs")
        if (not budget["matched"] or not tools["matched"]) and tobj["result"] not in {"INCOMPARABLE", "OPEN"}:
            raise RecordError(f"unmatched trial {trial_id} must return INCOMPARABLE or OPEN")
        changed = require_id_list(tobj.get("changed_return_fields"), f"trial {trial_id}.changed_return_fields")
        unknown = sorted(set(changed) - return_ids)
        if unknown:
            raise RecordError(f"trial {trial_id} changes unknown fields: {', '.join(unknown)}")
        if tobj["result"] in {"SUPPORTS_A", "SUPPORTS_B"} and not changed:
            raise RecordError(f"trial {trial_id} supports a rival but changes no Return field")
        require_string(tobj.get("declared_update"), f"trial {trial_id}.declared_update")


def validate_sweep(kind: str, value: Any) -> None:
    obj = require_object(value, f"{kind} sweep")
    if kind == "backward_sweep":
        allowed = {"kind", "observations", "candidate_hinges", "unsupported_links", "open"}
        expected_kind = "BackwardSweep"
        required_lists = ("observations", "candidate_hinges", "unsupported_links", "open")
    else:
        allowed = {"kind", "observations", "candidate_hinges", "proposed_moves", "open"}
        expected_kind = "ForwardSweep"
        required_lists = ("observations", "candidate_hinges", "proposed_moves", "open")
    _only_keys(obj, allowed, expected_kind)
    if obj.get("kind") != expected_kind:
        raise RecordError(f"{kind} artifact.kind must be {expected_kind!r}")
    for key in required_lists:
        require_list(obj.get(key), f"{expected_kind}.{key}")
    if not obj["observations"]:
        raise RecordError(f"{expected_kind}.observations must not be empty")
    if not (obj["candidate_hinges"] or obj["open"]):
        raise RecordError(f"{expected_kind} must return a candidate hinge or exact OPEN item")


def validate_seal(value: Any) -> None:
    obj = require_object(value, "Seal")
    _only_keys(obj, {"kind", "seal_id", "run_spec_hash", "sealed_head_hash", "artifact_hashes", "binding_set_hash", "admitted_bindings", "represented_operations", "budgets", "open_obligations", "boundary"}, "Seal")
    if obj.get("kind") != "Seal":
        raise RecordError("seal artifact.kind must be 'Seal'")
    require_id(obj.get("seal_id"), "Seal.seal_id")
    for key in ("run_spec_hash", "sealed_head_hash", "binding_set_hash"):
        require_string(obj.get(key), f"Seal.{key}")
    require_object(obj.get("artifact_hashes"), "Seal.artifact_hashes")
    require_id_list(obj.get("admitted_bindings"), "Seal.admitted_bindings")
    for key in ("represented_operations", "open_obligations"):
        require_string_list(obj.get(key), f"Seal.{key}")
    require_object(obj.get("budgets"), "Seal.budgets")
    if "boundary" in obj:
        require_string(obj["boundary"], "Seal.boundary", nonempty=False)


def validate_reentry(value: Any, return_ids: set[str]) -> None:
    obj = require_object(value, "Reentry")
    _only_keys(obj, {"kind", "parent_run_id", "parent_head_hash", "changed_refs", "affected_fields", "carried_fields", "carry_proof", "first_exact_break", "remaining_obligations", "earliest_useful_reentry", "child_run_spec", "child_run_spec_hash"}, "Reentry")
    if obj.get("kind") != "Reentry":
        raise RecordError("reentry artifact.kind must be 'Reentry'")
    require_id(obj.get("parent_run_id"), "Reentry.parent_run_id")
    require_string(obj.get("parent_head_hash"), "Reentry.parent_head_hash")
    require_id_list(obj.get("changed_refs"), "Reentry.changed_refs")
    affected = set(require_id_list(obj.get("affected_fields"), "Reentry.affected_fields"))
    carried = set(require_id_list(obj.get("carried_fields"), "Reentry.carried_fields"))
    if affected & carried or affected | carried != return_ids:
        raise RecordError("Reentry affected_fields and carried_fields must be a complete disjoint partition")
    proof = require_object(obj.get("carry_proof"), "Reentry.carry_proof")
    if set(proof) != carried:
        raise RecordError("Reentry carry_proof must contain exactly every carried field")
    for field_id, record in proof.items():
        robj = require_object(record, f"Reentry.carry_proof.{field_id}")
        _only_keys(robj, {"source_return_hash", "dependency_refs", "equivalence_witness", "support_ceiling"}, f"Reentry.carry_proof.{field_id}")
        for key in ("source_return_hash", "equivalence_witness", "support_ceiling"):
            require_string(robj.get(key), f"Reentry.carry_proof.{field_id}.{key}")
        require_id_list(robj.get("dependency_refs"), f"Reentry.carry_proof.{field_id}.dependency_refs")
    require_string(obj.get("first_exact_break"), "Reentry.first_exact_break")
    require_list(obj.get("remaining_obligations"), "Reentry.remaining_obligations")
    if not isinstance(obj.get("earliest_useful_reentry"), (str, dict, list)):
        raise RecordError("Reentry.earliest_useful_reentry must be a string, object, or array")
    child = require_object(obj.get("child_run_spec"), "Reentry.child_run_spec")
    validate_run_spec(child)
    from .canonical import digest_json
    if obj.get("child_run_spec_hash") != digest_json(child):
        raise RecordError("Reentry.child_run_spec_hash mismatch")


def validate_stop_basis(value: Any) -> None:
    obj = require_object(value, "ReturnEnvelope.stop_basis")
    _only_keys(obj, {"thin", "missing_frame_scout", "move_budget", "closure"}, "ReturnEnvelope.stop_basis")
    thin = require_object(obj.get("thin"), "stop_basis.thin")
    scout = require_object(obj.get("missing_frame_scout"), "stop_basis.missing_frame_scout")
    move = require_object(obj.get("move_budget"), "stop_basis.move_budget")
    for name, item in (("thin", thin), ("missing_frame_scout", scout)):
        _only_keys(item, {"outcome", "method", "result", "open_reason"}, f"stop_basis.{name}")
        if item.get("outcome") not in OUTCOMES:
            raise RecordError(f"stop_basis.{name}.outcome is invalid")
        require_string(item.get("method"), f"stop_basis.{name}.method")
        require_string(item.get("result"), f"stop_basis.{name}.result")
        if item["outcome"] == "OPEN":
            require_string(item.get("open_reason"), f"stop_basis.{name}.open_reason")
    _only_keys(move, {"used", "maximum", "remaining", "outcome", "basis"}, "stop_basis.move_budget")
    for key in ("used", "maximum", "remaining"):
        if isinstance(move.get(key), bool) or not isinstance(move.get(key), int) or move[key] < 0:
            raise RecordError(f"stop_basis.move_budget.{key} must be a nonnegative integer")
    if move["used"] + move["remaining"] != move["maximum"]:
        raise RecordError("stop_basis.move_budget does not balance")
    if move.get("outcome") not in OUTCOMES:
        raise RecordError("stop_basis.move_budget.outcome is invalid")
    require_string(move.get("basis"), "stop_basis.move_budget.basis")
    require_string(obj.get("closure"), "stop_basis.closure")


def validate_passage_model(value: Any) -> None:
    obj = require_object(value, "PassageModel")
    _only_keys(obj, {"schema_version", "kind", "model_id", "model_version", "regime", "scope", "empirical_standing", "domain", "bearer", "target", "regard", "demand", "horizon", "current_configuration", "initial_configuration", "configuration_schema", "qualification_dimensions", "transition_rules", "consequence_rules", "comparison_relation", "configurations", "passages", "basis_refs", "assumptions", "evidence_refs", "verifiers", "resource_accounts", "protected_conditions", "omitted_effects", "uncertainty"}, "PassageModel")
    if obj.get("schema_version") != SCHEMA_VERSION:
        raise RecordError(f"PassageModel.schema_version must be {SCHEMA_VERSION!r}")
    if obj.get("kind") != "PassageModel":
        raise RecordError("passage_model artifact.kind must be 'PassageModel'")
    require_id(obj.get("model_id"), "PassageModel.model_id")
    for key in ("model_version", "regime", "scope", "empirical_standing", "domain", "bearer", "target", "regard", "demand", "horizon"):
        require_string(obj.get(key), f"PassageModel.{key}")
    require_object(obj.get("configuration_schema"), "PassageModel.configuration_schema")
    for key in ("qualification_dimensions", "transition_rules", "consequence_rules", "assumptions", "verifiers", "protected_conditions", "omitted_effects"):
        require_string_list(obj.get(key), f"PassageModel.{key}")
    require_id_list(obj.get("evidence_refs"), "PassageModel.evidence_refs")
    resource_accounts = require_list(obj.get("resource_accounts"), "PassageModel.resource_accounts")
    for index, account in enumerate(resource_accounts):
        aobj = require_object(account, f"PassageModel.resource_accounts[{index}]")
        _only_keys(aobj, {"resource_id", "component", "passage_id", "demand", "roles", "gate_status", "blockers", "basis_refs", "uncertainty", "status"}, f"PassageModel.resource_accounts[{index}]")
        require_id(aobj.get("resource_id"), f"PassageModel.resource_accounts[{index}].resource_id")
        require_string(aobj.get("component"), f"PassageModel.resource_accounts[{index}].component")
        require_id(aobj.get("passage_id"), f"PassageModel.resource_accounts[{index}].passage_id")
        require_string(aobj.get("demand"), f"PassageModel.resource_accounts[{index}].demand")
        roles = require_string_list(aobj.get("roles"), f"PassageModel.resource_accounts[{index}].roles", nonempty=True)
        unknown_roles = sorted(set(roles) - RESOURCE_ROLES)
        if unknown_roles:
            raise RecordError(f"PassageModel.resource_accounts[{index}] has unknown roles: {', '.join(unknown_roles)}")
        gates = require_object(aobj.get("gate_status"), f"PassageModel.resource_accounts[{index}].gate_status")
        _only_keys(gates, set(RESOURCE_GATES), f"PassageModel.resource_accounts[{index}].gate_status")
        if set(gates) != set(RESOURCE_GATES):
            raise RecordError(f"PassageModel.resource_accounts[{index}].gate_status must name every diagnostic gate")
        for gate, status in gates.items():
            if status not in {"EARNED", "REJECTED", "OPEN", "NOT_APPLICABLE"}:
                raise RecordError(f"PassageModel.resource_accounts[{index}].gate_status.{gate} is invalid")
        require_string_list(aobj.get("blockers"), f"PassageModel.resource_accounts[{index}].blockers")
        require_id_list(aobj.get("basis_refs"), f"PassageModel.resource_accounts[{index}].basis_refs")
        require_string_list(aobj.get("uncertainty"), f"PassageModel.resource_accounts[{index}].uncertainty")
        if aobj.get("status") not in {"RESOURCE", "RESOURCE_CANDIDATE", "STOCK", "CONSTRAINT", "OPEN"}:
            raise RecordError(f"PassageModel.resource_accounts[{index}].status is invalid")
    configurations = require_list(obj.get("configurations"), "PassageModel.configurations")
    states: set[str] = set()
    for index, configuration in enumerate(configurations):
        cobj = require_object(configuration, f"configurations[{index}]")
        _only_keys(cobj, {"id", "description", "features"}, f"configurations[{index}]")
        state_id = require_id(cobj.get("id"), f"configurations[{index}].id")
        if state_id in states:
            raise RecordError(f"duplicate configuration id: {state_id}")
        states.add(state_id)
        require_string(cobj.get("description"), f"configuration {state_id}.description")
        if "features" in cobj:
            require_object(cobj["features"], f"configuration {state_id}.features")
    if not states:
        raise RecordError("PassageModel requires at least one configuration")
    passages = require_list(obj.get("passages"), "PassageModel.passages")
    passage_ids: set[str] = set()
    for index, passage in enumerate(passages):
        pobj = require_object(passage, f"passages[{index}]")
        _only_keys(pobj, {"id", "source", "target", "qualification", "conditions", "bottlenecks", "basis_refs", "resource_roles", "transformation", "consequences"}, f"passages[{index}]")
        passage_id = require_id(pobj.get("id"), f"passages[{index}].id")
        if passage_id in passage_ids:
            raise RecordError(f"duplicate passage id: {passage_id}")
        passage_ids.add(passage_id)
        if pobj.get("source") not in states or pobj.get("target") not in states:
            raise RecordError(f"passage {passage_id} references an unknown configuration")
        if pobj.get("qualification") not in PASSAGE_QUALIFICATIONS:
            raise RecordError(f"passage {passage_id}.qualification is invalid")
        require_string_list(pobj.get("conditions"), f"passage {passage_id}.conditions")
        require_id_list(pobj.get("basis_refs"), f"passage {passage_id}.basis_refs")
        resource_roles = require_list(pobj.get("resource_roles"), f"passage {passage_id}.resource_roles")
        require_string_list(pobj.get("consequences"), f"passage {passage_id}.consequences")
        if "bottlenecks" in pobj:
            require_string_list(pobj["bottlenecks"], f"passage {passage_id}.bottlenecks")
        if "transformation" in pobj:
            require_string(pobj["transformation"], f"passage {passage_id}.transformation", nonempty=False)
        for role_index, role in enumerate(resource_roles):
            robj = require_object(role, f"passage {passage_id}.resource_roles[{role_index}]")
            _only_keys(robj, {"component", "role", "quantity", "unit", "status"}, f"passage {passage_id}.resource_roles[{role_index}]")
            require_string(robj.get("component"), f"passage {passage_id}.resource role component")
            if robj.get("role") not in RESOURCE_ROLES:
                raise RecordError(f"passage {passage_id} has invalid resource role")
            for key in ("unit", "status"):
                if key in robj:
                    require_string(robj[key], f"passage {passage_id}.resource role {key}", nonempty=False)
    initial = obj.get("initial_configuration")
    if initial not in states:
        raise RecordError("PassageModel.initial_configuration must reference a configuration")
    if obj.get("current_configuration") not in states:
        raise RecordError("PassageModel.current_configuration must reference a configuration")
    require_id_list(obj.get("basis_refs"), "PassageModel.basis_refs")
    unknown_account_passages = sorted({account["passage_id"] for account in resource_accounts} - passage_ids)
    if unknown_account_passages:
        raise RecordError(f"PassageModel resource accounts reference unknown passages: {', '.join(unknown_account_passages)}")
    if "comparison_relation" in obj:
        relation = require_object(obj["comparison_relation"], "PassageModel.comparison_relation")
        _only_keys(relation, {"id", "type", "domain", "guarantee", "verifier", "validity_boundary"}, "PassageModel.comparison_relation")
        require_id(relation.get("id"), "PassageModel.comparison_relation.id")
        for key in ("type", "guarantee", "verifier", "validity_boundary"):
            require_string(relation.get(key), f"PassageModel.comparison_relation.{key}")
        domain = require_id_list(relation.get("domain"), "PassageModel.comparison_relation.domain", nonempty=True)
        unknown_domain = sorted(set(domain) - passage_ids)
        if unknown_domain:
            raise RecordError(f"PassageModel.comparison_relation.domain has unknown passage IDs: {', '.join(unknown_domain)}")
        if relation["type"] != "PASSAGE_IDENTITY":
            raise RecordError("0.1 executes only PASSAGE_IDENTITY; explicit correspondence comparison remains OPEN")
    uncertainty = require_list(obj.get("uncertainty"), "PassageModel.uncertainty")
    for index, item in enumerate(uncertainty):
        require_string(item, f"PassageModel.uncertainty[{index}]")


def validate_artifact(kind: str, value: Any, return_ids: set[str]) -> None:
    from .canonical import validate_finite
    validate_finite(value)
    if kind not in KINDS:
        raise RecordError(f"unknown artifact kind: {kind}")
    if kind == "hinge_set":
        validate_hinge_set(value, return_ids)
    elif kind == "return_envelope":
        validate_return_envelope(value, return_ids)
    elif kind == "outcome_receipt":
        validate_outcome_receipt(value)
    elif kind == "passage_model":
        validate_passage_model(value)
    elif kind == "binding_set":
        validate_binding_set(value, return_ids)
    elif kind == "seal":
        validate_seal(value)
    elif kind == "trial":
        validate_trial_set(value, return_ids)
    elif kind in {"backward_sweep", "forward_sweep"}:
        validate_sweep(kind, value)
    elif kind == "reentry":
        validate_reentry(value, return_ids)


def return_field_ids(run_spec: dict[str, Any]) -> set[str]:
    return {field["id"] for field in run_spec["return_contract"]["fields"]}
