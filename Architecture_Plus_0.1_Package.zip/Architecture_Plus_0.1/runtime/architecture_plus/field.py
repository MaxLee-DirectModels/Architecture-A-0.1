"""Small, deterministic retrieval from the dormant nonnormative term reserve."""

from __future__ import annotations

import re
import unicodedata
from pathlib import Path
from typing import Any

from .canonical import load_strict


TOKEN = re.compile(r"[\w'-]+", re.UNICODE)
STOPWORDS = {
    "a", "about", "an", "and", "answer", "are", "as", "at", "be", "by", "for", "from",
    "good", "in", "is", "it", "make", "need", "of", "on", "or", "problem", "something", "stuff",
    "that", "the", "things", "think", "this", "to", "was", "we", "were", "with",
}


def tokenize(text: str) -> list[str]:
    return [token for match in TOKEN.finditer(text) if (token := unicodedata.normalize("NFC", match.group(0)).casefold()) not in STOPWORDS]


def validate_operator_reserve(data: Any) -> None:
    if not isinstance(data, dict):
        raise ValueError("operator reserve must be an object")
    if data.get("schema_version") != "architecture-plus.operators/0.1":
        raise ValueError("operator reserve schema_version is invalid")
    if data.get("authority") != "NONNORMATIVE_DORMANT_OPERATOR_RESERVE":
        raise ValueError("operator reserve authority is invalid")
    if not isinstance(data.get("policy"), dict):
        raise ValueError("operator reserve policy must be an object")
    operators = data.get("operators")
    if not isinstance(operators, list):
        raise ValueError("operator reserve operators must be an array")
    required = {
        "id", "name", "trigger", "requirements", "intervention",
        "expected_changed_fields", "falsifier", "cost", "contraindications",
        "scope", "evidence", "lease",
    }
    seen: set[str] = set()
    for index, operator in enumerate(operators):
        if not isinstance(operator, dict):
            raise ValueError(f"operator {index} must be an object")
        missing = sorted(required - set(operator))
        if missing:
            raise ValueError(f"operator {index} lacks: {', '.join(missing)}")
        operator_id = operator["id"]
        if not isinstance(operator_id, str) or not operator_id:
            raise ValueError(f"operator {index}.id must be a nonempty string")
        if operator_id in seen:
            raise ValueError(f"duplicate operator id: {operator_id}")
        seen.add(operator_id)
        for key in ("requirements", "expected_changed_fields", "contraindications"):
            if not isinstance(operator[key], list):
                raise ValueError(f"operator {operator_id}.{key} must be an array")
        for key in ("name", "trigger", "intervention", "falsifier", "cost", "scope"):
            if not isinstance(operator[key], str) or not operator[key].strip():
                raise ValueError(f"operator {operator_id}.{key} must be a nonempty string")
        for key in ("evidence", "lease"):
            if not isinstance(operator[key], dict):
                raise ValueError(f"operator {operator_id}.{key} must be an object")


def _operators(root: Path, query: str, *, limit: int) -> tuple[list[dict[str, Any]], str | None]:
    path = root / "reserve" / "operators.json"
    if not path.exists():
        return [], "reserve/operators.json is absent"
    data = load_strict(path)
    validate_operator_reserve(data)
    query_tokens = set(tokenize(query))
    ranked: list[tuple[float, str, dict[str, Any], list[str]]] = []
    for operator in data.get("operators", []):
        if str(operator.get("status", "")).upper() in {"RETIRED", "SUPERSEDED"}:
            continue
        fields = " ".join([
            str(operator.get("name", "")),
            str(operator.get("trigger", "")),
            str(operator.get("intervention", "")),
            " ".join(str(item) for item in operator.get("expected_changed_fields", [])),
            " ".join(str(item) for item in operator.get("requirements", [])),
        ])
        tokens = set(tokenize(fields))
        overlap = sorted(query_tokens & tokens)
        exact_name = str(operator.get("name", "")).casefold() in query.casefold()
        if not exact_name and len(overlap) < 2:
            continue
        name_tokens = set(tokenize(str(operator.get("name", ""))))
        score = 2 * len(query_tokens & name_tokens) + len(overlap)
        ranked.append((score, str(operator.get("name", "")).casefold(), operator, overlap))
    ranked.sort(key=lambda row: (-row[0], row[1], str(row[2].get("id", ""))))
    selected = []
    for score, _, operator, overlap in ranked[:limit]:
        selected.append({
            "id": operator.get("id"),
            "name": operator.get("name"),
            "trigger": operator.get("trigger"),
            "requirements": operator.get("requirements", []),
            "intervention": operator.get("intervention"),
            "expected_changed_fields": operator.get("expected_changed_fields", []),
            "falsifier": operator.get("falsifier"),
            "cost": operator.get("cost"),
            "contraindications": operator.get("contraindications", []),
            "scope": operator.get("scope"),
            "evidence": operator.get("evidence"),
            "lease": operator.get("lease"),
            "score": score,
            "activation_reason": f"matched live query tokens: {', '.join(overlap)}",
        })
    return selected, None


def activate(
    root: Path,
    query: str,
    *,
    limit: int = 12,
    operator_limit: int = 4,
    context: str = "exploration",
    context_ref: str | None = None,
    predicted_changed_field: str | None = None,
    cost: str | None = None,
    falsifier: str | None = None,
) -> dict[str, Any]:
    if limit < 1 or limit > 50:
        raise ValueError("field retrieval limit must be between 1 and 50")
    if operator_limit < 0 or operator_limit > 12:
        raise ValueError("operator retrieval limit must be between 0 and 12")
    if context not in {"exploration", "hinge", "return"}:
        raise ValueError("activation context must be exploration, hinge, or return")
    if context in {"hinge", "return"}:
        missing = [name for name, value in (("context_ref", context_ref), ("predicted_changed_field", predicted_changed_field), ("cost", cost), ("falsifier", falsifier)) if not isinstance(value, str) or not value.strip()]
        if missing:
            raise ValueError(f"bound retrieval requires: {', '.join(missing)}")
    query_tokens = set(tokenize(query))
    if not query_tokens:
        return {
            "status": "OPEN",
            "reason": "query contains no addressable terms",
            "authority": "nonnormative_dormant_reserve",
            "terms": [],
            "operators": [],
        }
    path = root / "reserve" / "lexicon.json"
    lexicon_open: str | None = None
    data: dict[str, Any]
    if path.exists():
        data = load_strict(path)
    else:
        data = {"neighborhoods": [], "terms": []}
        lexicon_open = "reserve/lexicon.json is absent"
    neighborhoods = {item["id"]: item for item in data.get("neighborhoods", [])}
    ranked: list[tuple[float, str, dict[str, Any], list[str]]] = []
    for term in data.get("terms", []):
        if str(term.get("status", "")).upper() in {"RETIRED", "SUPERSEDED"} or str(term.get("maturity", "")).upper() in {"RETIRED", "SUPERSEDED"}:
            continue
        label = str(term.get("label", ""))
        aliases = [str(value) for value in term.get("aliases", [])]
        neighborhood = str(term.get("neighborhood", ""))
        ntokens = set(tokenize(label + " " + " ".join(aliases) + " " + neighborhood))
        overlap = sorted(query_tokens & ntokens)
        phrase = label.casefold() in query.casefold() or any(alias.casefold() in query.casefold() for alias in aliases if alias)
        if not phrase and len(overlap) < 2:
            continue
        label_tokens = set(tokenize(label))
        score = 2 * len(query_tokens & label_tokens) + len(overlap)
        if phrase:
            score += 4
        ranked.append((score, label.casefold(), term, overlap))
    ranked.sort(key=lambda row: (-row[0], row[1], str(row[2].get("id", ""))))
    terms: list[dict[str, Any]] = []
    included_neighborhoods: set[str] = set()
    for score, _, term, overlap in ranked[:limit]:
        neighborhood = str(term.get("neighborhood", ""))
        included_neighborhoods.add(neighborhood)
        terms.append({
            "id": term.get("id"),
            "label": term.get("label"),
            "aliases": term.get("aliases", []),
            "neighborhood": neighborhood,
            "role": term.get("role"),
            "maturity": term.get("maturity"),
            "score": score,
            "matched_tokens": overlap,
        })
    probes = []
    for neighborhood in sorted(included_neighborhoods):
        item = neighborhoods.get(neighborhood, {})
        probes.extend({"neighborhood": neighborhood, "probe": probe} for probe in item.get("probes", []))
    operators, operator_open = _operators(root, query, limit=operator_limit)
    return {
        "status": ("LOOKUP" if context == "exploration" else "ACTIVATION_CANDIDATE") if terms or operators else "OPEN",
        "query": query,
        "activation_context": context,
        "activation_binding": None if context == "exploration" else {
            "context_ref": context_ref,
            "predicted_changed_field": predicted_changed_field,
            "cost": cost,
            "falsifier": falsifier,
            "term_cap": limit,
            "operator_cap": operator_limit,
        },
        "authority": "nonnormative_dormant_reserve",
        "policy": "Retrieval proposes words, probes, and dormant operator cards. LOOKUP is not activation. ACTIVATION_CANDIDATE is a bound proposal, not an activated theory, fact, requirement, authority, applicability, safety, value, or Standing.",
        "terms": terms,
        "probes": probes,
        "lexicon_open": lexicon_open,
        "operators": operators,
        "operator_open": operator_open,
    }
