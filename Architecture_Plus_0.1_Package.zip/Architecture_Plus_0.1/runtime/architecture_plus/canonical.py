"""Strict, deterministic JSON and hashing helpers."""

from __future__ import annotations

import hashlib
import json
import math
import os
import tempfile
import unicodedata
from pathlib import Path
from typing import Any


class CanonicalError(ValueError):
    pass


MAX_INPUT_BYTES = 4 * 1024 * 1024
MAX_STRING_CHARS = 1_000_000
MAX_TOTAL_NODES = 200_000


def _pairs_no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    normalized: set[str] = set()
    for key, value in pairs:
        if not isinstance(key, str):
            raise CanonicalError("JSON object keys must be strings")
        nkey = unicodedata.normalize("NFC", key)
        if nkey in normalized:
            raise CanonicalError(f"duplicate or NFC-colliding key: {key!r}")
        normalized.add(nkey)
        out[nkey] = value
    return out


def loads_strict(text: str) -> Any:
    def bad_constant(value: str) -> None:
        raise CanonicalError(f"non-finite number is not allowed: {value}")

    value = json.loads(
        text,
        object_pairs_hook=_pairs_no_duplicates,
        parse_constant=bad_constant,
    )
    validate_finite(value)
    return normalize(value)


def load_strict(path: Path) -> Any:
    size = path.stat().st_size
    if size > MAX_INPUT_BYTES:
        raise CanonicalError(f"JSON input exceeds {MAX_INPUT_BYTES} bytes")
    return loads_strict(path.read_text(encoding="utf-8"))


def normalize(value: Any) -> Any:
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        raise CanonicalError("binary floating-point numbers are not allowed; use an integer or exact decimal string")
    if isinstance(value, list):
        return [normalize(item) for item in value]
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise CanonicalError("JSON object keys must be strings")
            nkey = unicodedata.normalize("NFC", key)
            if nkey in out:
                raise CanonicalError(f"duplicate or NFC-colliding key: {key!r}")
            out[nkey] = normalize(item)
        return out
    raise CanonicalError(f"unsupported value type: {type(value).__name__}")


def validate_finite(value: Any, *, depth: int = 0, _counter: list[int] | None = None) -> None:
    if _counter is None:
        _counter = [0]
    _counter[0] += 1
    if _counter[0] > MAX_TOTAL_NODES:
        raise CanonicalError(f"JSON value exceeds {MAX_TOTAL_NODES} total nodes")
    if depth > 40:
        raise CanonicalError("JSON nesting exceeds 40 levels")
    if isinstance(value, str) and len(value) > MAX_STRING_CHARS:
        raise CanonicalError(f"JSON string exceeds {MAX_STRING_CHARS} characters")
    if isinstance(value, float):
        raise CanonicalError("binary floating-point numbers are not allowed; use an integer or exact decimal string")
    if isinstance(value, list):
        if len(value) > 10000:
            raise CanonicalError("JSON array exceeds 10,000 elements")
        for item in value:
            validate_finite(item, depth=depth + 1, _counter=_counter)
    elif isinstance(value, dict):
        if len(value) > 10000:
            raise CanonicalError("JSON object exceeds 10,000 members")
        for item in value.values():
            validate_finite(item, depth=depth + 1, _counter=_counter)


def dumps_canonical(value: Any) -> str:
    normalized = normalize(value)
    validate_finite(normalized)
    return json.dumps(
        normalized,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_json(value: Any) -> str:
    return digest_bytes(dumps_canonical(value).encode("utf-8"))


def digest_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def atomic_write_text(path: Path, text: str) -> None:
    atomic_write(path, text.encode("utf-8"))
