"""Packet manifest creation and verification."""

from __future__ import annotations

import json
import re
from pathlib import Path
from pathlib import PurePosixPath
from typing import Any

from .canonical import atomic_write_text, digest_file, digest_json, dumps_canonical, load_strict
from .field import validate_operator_reserve


MANIFEST_NAME = "MANIFEST.json"
MANIFEST_SCHEMA_VERSION = "architecture-plus.manifest/0.1"
MANIFEST_RELEASE = "Architecture+ 0.1"
MANIFEST_PROFILE = "executable_reference"
MANIFEST_BOUNDARY = "Hashes detect packet drift. They do not prove authorship, trusted time, authenticity, truth, authority, safety, external value, or world effects."
READABLE_DOCUMENT = "docs/README_Plus_0.1.docx"
EXCLUDED_PATHS = {"tools/build_readme_plus_docx.py"}
MANIFEST_FIELDS = {
    "schema_version", "release", "profile", "files", "file_count",
    "content_fingerprint", "boundary",
}
FILE_ROW_FIELDS = {"path", "bytes", "sha256"}
SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
IGNORED_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", "docs", "dist"}
IGNORED_SUFFIXES = {".pyc", ".pyo", ".tmp", ".zip", ".docx", ".pdf", ".png"}


def _included(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    relative_name = relative.as_posix()
    if relative_name == MANIFEST_NAME or relative_name in EXCLUDED_PATHS:
        return False
    if relative_name == READABLE_DOCUMENT:
        return path.is_file()
    if any(part in IGNORED_PARTS or part.startswith(".") for part in relative.parts):
        return False
    if path.suffix in IGNORED_SUFFIXES:
        return False
    return path.is_file()


def file_inventory(root: Path) -> list[dict[str, Any]]:
    rows = []
    paths = (path for path in root.rglob("*") if _included(path, root))
    for path in sorted(paths, key=lambda item: item.relative_to(root).as_posix()):
        rows.append({
            "path": path.relative_to(root).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": digest_file(path),
        })
    return rows


def _safe_manifest_path(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value or "\x00" in value or "\\" in value:
        raise ValueError(f"{where} must be a nonempty normalized POSIX relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or path.as_posix() != value or value == "." or re.match(r"^[A-Za-z]:", value):
        raise ValueError(f"{where} must be a normalized relative path")
    if any(part in {"", ".", ".."} for part in value.split("/")):
        raise ValueError(f"{where} contains an unsafe path segment")
    return value


def _validate_manifest(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError("manifest must be an object")
    if set(value) != MANIFEST_FIELDS:
        missing = sorted(MANIFEST_FIELDS - set(value))
        unknown = sorted(set(value) - MANIFEST_FIELDS)
        detail = []
        if missing:
            detail.append(f"missing {', '.join(missing)}")
        if unknown:
            detail.append(f"unknown {', '.join(unknown)}")
        raise ValueError(f"manifest has invalid fields: {'; '.join(detail)}")
    constants = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "release": MANIFEST_RELEASE,
        "profile": MANIFEST_PROFILE,
        "boundary": MANIFEST_BOUNDARY,
    }
    for field, expected in constants.items():
        if value[field] != expected:
            raise ValueError(f"manifest {field} must be {expected!r}")
    rows = value["files"]
    if not isinstance(rows, list):
        raise ValueError("manifest files must be an array")
    paths: list[str] = []
    for index, row in enumerate(rows):
        where = f"manifest files[{index}]"
        if not isinstance(row, dict) or set(row) != FILE_ROW_FIELDS:
            raise ValueError(f"{where} must contain exactly path, bytes, and sha256")
        paths.append(_safe_manifest_path(row["path"], f"{where}.path"))
        size = row["bytes"]
        if isinstance(size, bool) or not isinstance(size, int) or size < 0:
            raise ValueError(f"{where}.bytes must be a nonnegative integer")
        if not isinstance(row["sha256"], str) or SHA256_PATTERN.fullmatch(row["sha256"]) is None:
            raise ValueError(f"{where}.sha256 must be 64 lowercase hexadecimal characters")
    if len(paths) != len(set(paths)):
        raise ValueError("manifest file paths must be unique")
    if paths != sorted(paths):
        raise ValueError("manifest file rows must be sorted canonically by path")
    file_count = value["file_count"]
    if isinstance(file_count, bool) or not isinstance(file_count, int) or file_count != len(rows):
        raise ValueError("manifest file_count must equal the number of file rows")
    fingerprint = value["content_fingerprint"]
    if not isinstance(fingerprint, str) or SHA256_PATTERN.fullmatch(fingerprint) is None:
        raise ValueError("manifest content_fingerprint must be 64 lowercase hexadecimal characters")
    if fingerprint != digest_json(rows):
        raise ValueError("manifest content_fingerprint mismatch")
    return value


def freeze(root: Path) -> dict[str, Any]:
    rows = file_inventory(root)
    manifest = {
        "schema_version": MANIFEST_SCHEMA_VERSION,
        "release": MANIFEST_RELEASE,
        "profile": MANIFEST_PROFILE,
        "files": rows,
        "file_count": len(rows),
        "content_fingerprint": digest_json(rows),
        "boundary": MANIFEST_BOUNDARY,
    }
    _validate_manifest(manifest)
    atomic_write_text(root / MANIFEST_NAME, dumps_canonical(manifest) + "\n")
    return manifest


def verify(root: Path) -> dict[str, Any]:
    failures: list[str] = []
    required = [
        "runtime/architecture_plus/__init__.py",
        "runtime/architecture_plus/__main__.py",
        "runtime/architecture_plus/canonical.py",
        "runtime/architecture_plus/cli.py",
        "runtime/architecture_plus/field.py",
        "runtime/architecture_plus/package.py",
        "runtime/architecture_plus/passage.py",
        "runtime/architecture_plus/prompts.py",
        "runtime/architecture_plus/records.py",
        "runtime/architecture_plus/store.py",
        "README.md",
        READABLE_DOCUMENT,
        "spec/system.json",
        "theory/passage.json",
        "schemas/records.schema.json",
        "prompts/free.txt",
        "prompts/guided.txt",
        "prompts/backward.txt",
        "prompts/forward.txt",
        "prompts/hinge.txt",
        "prompts/trial.txt",
        "prompts/binding.txt",
        "prompts/return.txt",
        "prompts/outcome.txt",
        "reserve/lexicon.json",
        "reserve/operators.json",
        "reserve/anomalies.jsonl",
        "qualification/evidence.json",
        "qualification/golden_fixtures.json",
        "qualification/coverage.json",
        "tests/test_architecture_plus.py",
        "tests/test_release_coverage.py",
        "tests/test_store_hardening.py",
        "tests/test_manifest_integrity.py",
        "tests/test_prompt_substitution.py",
        "tests/test_semantic_barriers.py",
        "tests/test_field_noise.py",
        "tests/test_activation_binding.py",
        "tests/test_input_bounds.py",
        "tests/test_outcome_successor_barrier.py",
        "tests/test_store_release_barriers.py",
        "tools/audit_spec.py",
        "tools/audit_coverage.py",
        "tools/build_spec.py",
        "tools/build_operators.py",
        "examples/mine/run_spec.json",
        "examples/mine/candidate.txt",
        "examples/mine/backward.json",
        "examples/mine/forward.json",
        "examples/mine/hinges.json",
        "examples/mine/trials.json",
        "examples/mine/bindings.json",
        "examples/mine/passage_model.json",
        "examples/mine/return.json",
        "examples/mine/outcome.json",
    ]
    for relative in required:
        if not (root / relative).is_file():
            failures.append(f"missing required file: {relative}")
    for relative in ("schemas/records.schema.json", "reserve/lexicon.json", "reserve/operators.json", "qualification/evidence.json", "qualification/golden_fixtures.json", "qualification/coverage.json", "spec/system.json", "theory/passage.json"):
        path = root / relative
        if path.exists():
            try:
                load_strict(path)
            except (OSError, ValueError) as exc:
                failures.append(f"invalid strict JSON in {relative}: {exc}")
    operators_path = root / "reserve" / "operators.json"
    if operators_path.exists():
        try:
            validate_operator_reserve(load_strict(operators_path))
        except (OSError, ValueError) as exc:
            failures.append(f"invalid operator reserve: {exc}")
    anomaly_path = root / "reserve" / "anomalies.jsonl"
    if anomaly_path.exists():
        for line_number, line in enumerate(anomaly_path.read_text(encoding="utf-8").splitlines(), start=1):
            if line.strip():
                try:
                    json.loads(line)
                except json.JSONDecodeError as exc:
                    failures.append(f"invalid anomalies.jsonl line {line_number}: {exc}")
    try:
        system = load_strict(root / "spec" / "system.json")
        theory = load_strict(root / "theory" / "passage.json")
        for key in ("passage_theory", "passage_model_contract", "resource_account", "successor_signature"):
            if theory.get(key) != system.get(key):
                failures.append(f"theory projection drift: {key}")
        if load_strict(root / "qualification" / "evidence.json") != system.get("qualification"):
            failures.append("qualification evidence projection drift")
    except (OSError, ValueError) as exc:
        failures.append(f"projection verification failed: {exc}")
    manifest_path = root / MANIFEST_NAME
    manifest_status = "NOT_FROZEN"
    manifest_fingerprint = None
    if manifest_path.exists():
        manifest_status = "PASS"
        manifest_failure_count = len(failures)
        try:
            manifest = _validate_manifest(load_strict(manifest_path))
            expected_rows = manifest["files"]
            actual_rows = file_inventory(root)
            expected = {row["path"]: row for row in expected_rows}
            actual = {row["path"]: row for row in actual_rows}
            if set(expected) != set(actual):
                missing = sorted(set(expected) - set(actual))
                added = sorted(set(actual) - set(expected))
                if missing:
                    failures.append(f"manifest files missing: {', '.join(missing)}")
                if added:
                    failures.append(f"unmanifested files: {', '.join(added)}")
            for path in sorted(set(expected) & set(actual)):
                if expected[path] != actual[path]:
                    failures.append(f"manifest mismatch: {path}")
            if expected_rows != actual_rows and set(expected) == set(actual):
                failures.append("manifest inventory does not exactly match actual inventory")
            manifest_fingerprint = manifest["content_fingerprint"]
        except (OSError, ValueError) as exc:
            failures.append(f"invalid manifest: {exc}")
        if len(failures) != manifest_failure_count:
            manifest_status = "FAIL"
    return {
        "status": "PASS" if not failures else "FAIL",
        "release": "Architecture+ 0.1",
        "manifest": manifest_status,
        "content_fingerprint": manifest_fingerprint,
        "failures": failures,
        "boundary": "PASS establishes packet presence, strict finite parsing where checked, and manifest integrity when frozen. It does not establish semantic truth, external correctness, authority, safety, completeness, or comparative value.",
    }
