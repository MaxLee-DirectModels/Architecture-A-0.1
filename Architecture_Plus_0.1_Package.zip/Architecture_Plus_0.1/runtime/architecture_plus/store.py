"""Append-only run store with a deterministic hash-chained event log."""

from __future__ import annotations

import os
import re
import shutil
import tempfile
from pathlib import Path
from typing import Any

from .canonical import atomic_write, atomic_write_text, digest_bytes, digest_file, digest_json, dumps_canonical, load_strict, loads_strict
from .prompts import render_prompt
from .passage import assess as assess_passage
from .records import KINDS, RecordError, return_field_ids, validate_artifact, validate_reentry, validate_run_spec


ZERO_HASH = "0" * 64
HASH_PATTERN = re.compile(r"^[0-9a-f]{64}$")
ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
EVENT_ID_PATTERN = re.compile(r"^E-[0-9]{6}$")
ARTIFACT_ID_PATTERN = re.compile(r"^A-[0-9]{6}$")
EVENT_FIELDS = {
    "schema_version", "sequence", "event_id", "prior_hash", "event_type",
    "kind", "artifact_id", "artifact_path", "artifact_hash", "payload_hash",
    "dependencies", "record_hash",
}
WRAPPER_FIELDS = {
    "schema_version", "artifact_id", "run_id", "kind", "payload_hash",
    "dependencies", "payload",
}
FORMATION_MANIFEST_FIELDS = {
    "formation_mode", "raw_request_hash", "supplied_basis_hashes",
    "unavoidable_policy_ids", "declared_tools", "requested_output_form",
    "model_or_agent_identity_if_known", "forbidden_scaffold_classes",
    "firewall_waivers", "formation_prompt_hash", "formation_template_hash",
    "formation_context_attestation_or_OPEN", "output_hash",
}
PHASE_DEPENDENCY_KINDS: dict[str, tuple[str, ...]] = {
    "backward_sweep": ("candidate",),
    "forward_sweep": ("candidate",),
    "hinge_set": ("candidate", "backward_sweep", "forward_sweep"),
    "trial": ("hinge_set",),
    "binding_set": ("hinge_set", "trial"),
}
LIVE_HINGE_STATUSES = {"CANDIDATE", "ADMITTED", "OPEN"}
CARRY_WITNESS = "Declared support slice is disjoint from the reverse dependency closure of changed_refs within the parent interface."


def _is_identifier(value: Any) -> bool:
    return isinstance(value, str) and ID_PATTERN.fullmatch(value) is not None


def _is_hash(value: Any) -> bool:
    return isinstance(value, str) and HASH_PATTERN.fullmatch(value) is not None


def _validate_ref_list(value: Any, where: str) -> list[str]:
    if not isinstance(value, list) or any(not _is_identifier(item) for item in value):
        raise RecordError(f"{where} must be an array of identifiers")
    if value != sorted(set(value)):
        raise RecordError(f"{where} must be sorted and unique")
    return value


def _validate_event_record(value: Any, line_number: int | None = None) -> dict[str, Any]:
    where = f"event line {line_number}" if line_number is not None else "event"
    if not isinstance(value, dict):
        raise RecordError(f"{where} must be an object")
    if set(value) != EVENT_FIELDS:
        missing = sorted(EVENT_FIELDS - set(value))
        unknown = sorted(set(value) - EVENT_FIELDS)
        detail = []
        if missing:
            detail.append(f"missing {', '.join(missing)}")
        if unknown:
            detail.append(f"unknown {', '.join(unknown)}")
        raise RecordError(f"{where} has invalid fields: {'; '.join(detail)}")
    if value["schema_version"] != "architecture-plus.event/0.1":
        raise RecordError(f"{where} has invalid schema_version")
    sequence = value["sequence"]
    if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 1:
        raise RecordError(f"{where}.sequence must be a positive integer")
    if not isinstance(value["event_id"], str) or not EVENT_ID_PATTERN.fullmatch(value["event_id"]):
        raise RecordError(f"{where}.event_id is invalid")
    if value["event_id"] != f"E-{sequence:06d}":
        raise RecordError(f"{where}.event_id does not match sequence")
    for key in ("prior_hash", "artifact_hash", "payload_hash", "record_hash"):
        if not _is_hash(value[key]):
            raise RecordError(f"{where}.{key} must be 64 lowercase hex characters")
    if value["event_type"] not in {"RUN_INITIALIZED", "ARTIFACT_RECORDED"}:
        raise RecordError(f"{where}.event_type is invalid")
    _validate_ref_list(value["dependencies"], f"{where}.dependencies")
    path = value["artifact_path"]
    if not isinstance(path, str) or not path or path.startswith("/") or ".." in Path(path).parts:
        raise RecordError(f"{where}.artifact_path is unsafe")
    if value["event_type"] == "RUN_INITIALIZED":
        if sequence != 1 or value["kind"] != "run_spec" or value["artifact_id"] != "RUNSPEC" or path != "run.json" or value["dependencies"]:
            raise RecordError(f"{where} has an invalid RUN_INITIALIZED contract")
    else:
        if value["kind"] not in KINDS:
            raise RecordError(f"{where}.kind is invalid")
        if not isinstance(value["artifact_id"], str) or not ARTIFACT_ID_PATTERN.fullmatch(value["artifact_id"]):
            raise RecordError(f"{where}.artifact_id is invalid")
        expected = f"artifacts/{value['artifact_id']}-{value['kind']}-{value['payload_hash'][:12]}.json"
        if path != expected:
            raise RecordError(f"{where}.artifact_path does not match its identifiers and hash")
    return value


def _validate_formation_manifest(value: Any) -> None:
    if not isinstance(value, dict) or set(value) != FORMATION_MANIFEST_FIELDS:
        raise RecordError("candidate formation_manifest has invalid fields")
    if value["formation_mode"] not in {"NATIVE", "GUIDED"}:
        raise RecordError("formation_manifest.formation_mode is invalid")
    for key in ("raw_request_hash", "formation_prompt_hash", "formation_template_hash", "output_hash"):
        if not _is_hash(value[key]):
            raise RecordError(f"formation_manifest.{key} is invalid")
    hashes = value["supplied_basis_hashes"]
    if not isinstance(hashes, dict) or any(not _is_identifier(key) or not _is_hash(item) for key, item in hashes.items()):
        raise RecordError("formation_manifest.supplied_basis_hashes is invalid")
    for key in ("unavoidable_policy_ids", "declared_tools", "forbidden_scaffold_classes"):
        if not isinstance(value[key], list) or any(not isinstance(item, str) for item in value[key]):
            raise RecordError(f"formation_manifest.{key} must be an array of strings")
    if not isinstance(value["requested_output_form"], str) or not isinstance(value["model_or_agent_identity_if_known"], str):
        raise RecordError("formation_manifest string fields are invalid")
    if not isinstance(value["firewall_waivers"], list) or not isinstance(value["formation_context_attestation_or_OPEN"], dict):
        raise RecordError("formation_manifest waiver or attestation field is invalid")


def _validate_artifact_wrapper(value: Any, *, event: dict[str, Any] | None = None) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise RecordError("artifact wrapper must be an object")
    allowed = WRAPPER_FIELDS | ({"formation_manifest"} if value.get("kind") == "candidate" else set())
    if set(value) != allowed:
        missing = sorted(allowed - set(value))
        unknown = sorted(set(value) - allowed)
        detail = []
        if missing:
            detail.append(f"missing {', '.join(missing)}")
        if unknown:
            detail.append(f"unknown {', '.join(unknown)}")
        raise RecordError(f"artifact wrapper has invalid fields: {'; '.join(detail)}")
    if value["schema_version"] != "architecture-plus.artifact/0.1":
        raise RecordError("artifact wrapper has invalid schema_version")
    if not isinstance(value["artifact_id"], str) or not ARTIFACT_ID_PATTERN.fullmatch(value["artifact_id"]):
        raise RecordError("artifact wrapper artifact_id is invalid")
    if not _is_identifier(value["run_id"]):
        raise RecordError("artifact wrapper run_id is invalid")
    if value["kind"] not in KINDS:
        raise RecordError("artifact wrapper kind is invalid")
    if not _is_hash(value["payload_hash"]):
        raise RecordError("artifact wrapper payload_hash is invalid")
    _validate_ref_list(value["dependencies"], "artifact wrapper dependencies")
    if value["payload_hash"] != digest_json(value["payload"]):
        raise RecordError("artifact wrapper payload_hash mismatch")
    if value["kind"] == "candidate":
        _validate_formation_manifest(value["formation_manifest"])
    if event is not None:
        for key in ("artifact_id", "kind", "payload_hash", "dependencies"):
            if value[key] != event[key]:
                raise RecordError(f"artifact wrapper {key} does not match event")
    return value


def _tokens(value: str) -> set[str]:
    return {token for token in re.findall(r"[A-Za-z0-9]+", value.casefold()) if len(token) > 2}


def _orientation_matches(trial_text: str, own_text: str, rival_text: str) -> bool:
    if trial_text.strip().casefold() == own_text.split(" ", 1)[0].strip().casefold() or trial_text.strip().casefold() == own_text.strip().casefold():
        return True
    trial = _tokens(trial_text)
    if not trial:
        return False
    own = len(trial & _tokens(own_text))
    rival = len(trial & _tokens(rival_text))
    return own > 0 and own >= rival


def _binding_coverage_failures(
    binding_set: dict[str, Any],
    hinge_set: dict[str, Any],
    trial_set: dict[str, Any],
) -> list[str]:
    failures: list[str] = []
    hinges = {item["hinge_id"]: item for item in hinge_set.get("hinges", [])}
    trials = {item["trial_id"]: item for item in trial_set.get("trials", [])}
    live_hinges = {
        hinge_id for hinge_id, hinge in hinges.items()
        if hinge.get("status") in LIVE_HINGE_STATUSES
    }
    referenced_hinges: set[str] = set()
    referenced_trials: set[str] = set()
    for binding in binding_set.get("bindings", []):
        binding_id = binding.get("binding_id")
        hinge_refs = set(binding.get("hinge_refs", []))
        trial_refs = set(binding.get("trial_refs", []))
        referenced_hinges |= hinge_refs
        referenced_trials |= trial_refs
        required_fields: set[str] = set()
        for ref in hinge_refs:
            required_fields |= set(hinges.get(ref, {}).get("affected_fields", []))
        for ref in trial_refs:
            required_fields |= set(trials.get(ref, {}).get("changed_return_fields", []))
        fields = set(binding.get("affected_fields", []))
        missing_fields = sorted(required_fields - fields)
        extra_fields = sorted(fields - required_fields) if required_fields else []
        if missing_fields:
            failures.append(
                f"Binding {binding_id} affected_fields omit referenced Hinge/Trial fields: {', '.join(missing_fields)}"
            )
        if extra_fields:
            failures.append(
                f"Binding {binding_id} affected_fields exceed referenced Hinge/Trial fields: {', '.join(extra_fields)}"
            )
    missing_hinges = sorted(live_hinges - referenced_hinges)
    missing_trials = sorted(set(trials) - referenced_trials)
    if missing_hinges:
        failures.append(f"BindingSet does not cover live Hinges: {', '.join(missing_hinges)}")
    if missing_trials:
        failures.append(f"BindingSet does not cover current Trials: {', '.join(missing_trials)}")
    return failures


def _latest_phase_chain_failures(
    history: list[tuple[dict[str, Any], dict[str, Any]]],
) -> list[str]:
    latest: dict[str, dict[str, Any]] = {}
    for event, _ in history:
        latest[event["kind"]] = event
    failures: list[str] = []
    for kind, required_kinds in PHASE_DEPENDENCY_KINDS.items():
        event = latest.get(kind)
        if event is None:
            continue
        missing_kinds = [required for required in required_kinds if required not in latest]
        if missing_kinds:
            failures.append(f"current {kind} lacks current prerequisite kinds: {', '.join(missing_kinds)}")
            continue
        expected = {latest[required]["artifact_id"] for required in required_kinds}
        missing = sorted(expected - set(event.get("dependencies", [])))
        if missing:
            failures.append(
                f"current {kind} is stale; dependencies omit latest phase artifacts: {', '.join(missing)}"
            )
    return failures


def _child_spec_failures(
    parent_spec: dict[str, Any],
    child_spec: dict[str, Any],
    changed_refs: list[str],
    parent_head_hash: str,
    history: list[tuple[dict[str, Any], dict[str, Any]]],
) -> list[str]:
    failures: list[str] = []
    changed = sorted(set(changed_refs))
    if not changed or changed_refs != changed:
        failures.append("changed_refs must be a nonempty sorted unique list")
    prior_run_ids = {parent_spec["run_id"]}
    prior_run_ids |= {
        wrapper["payload"].get("child_run_spec", {}).get("run_id")
        for event, wrapper in history
        if event["kind"] == "reentry"
    }
    if child_spec.get("run_id") in prior_run_ids:
        failures.append("child RunSpec.run_id must be new and distinct from parent and prior child runs")
    if return_field_ids(child_spec) != return_field_ids(parent_spec):
        failures.append("child RunSpec must preserve the parent Return field IDs for this Reentry partition")
    lineage = child_spec.get("lineage")
    reentry = lineage.get("reentry") if isinstance(lineage, dict) else None
    required_reentry_fields = {"parent_run_id", "parent_head_hash", "changed_material"}
    if not isinstance(reentry, dict) or set(reentry) != required_reentry_fields:
        failures.append(
            "child RunSpec.lineage.reentry must contain exactly parent_run_id, parent_head_hash, and changed_material"
        )
        return failures
    if reentry.get("parent_run_id") != parent_spec.get("run_id"):
        failures.append("child RunSpec lineage parent_run_id does not match parent")
    if reentry.get("parent_head_hash") != parent_head_hash:
        failures.append("child RunSpec lineage parent_head_hash does not match the live parent head")
    material = reentry.get("changed_material")
    if not isinstance(material, list):
        failures.append("child RunSpec lineage changed_material must be an array")
        return failures
    mapping: dict[str, str] = {}
    for index, item in enumerate(material):
        if not isinstance(item, dict) or set(item) != {"changed_ref", "basis_ref"}:
            failures.append(f"child changed_material[{index}] must contain exactly changed_ref and basis_ref")
            continue
        changed_ref = item.get("changed_ref")
        basis_ref = item.get("basis_ref")
        if not _is_identifier(changed_ref) or not _is_identifier(basis_ref):
            failures.append(f"child changed_material[{index}] values must be identifiers")
            continue
        if changed_ref in mapping:
            failures.append(f"child changed_material repeats changed_ref {changed_ref}")
        mapping[changed_ref] = basis_ref
    if sorted(mapping) != changed:
        failures.append("child changed_material must account for every and only changed_refs")
    child_basis = {item["id"]: item for item in child_spec.get("basis", [])}
    parent_basis = {item["id"]: item for item in parent_spec.get("basis", [])}
    for changed_ref, basis_ref in mapping.items():
        item = child_basis.get(basis_ref)
        if item is None:
            failures.append(f"child changed material for {changed_ref} cites absent Basis {basis_ref}")
        elif basis_ref in parent_basis and item == parent_basis[basis_ref]:
            failures.append(f"child changed material for {changed_ref} reuses unchanged parent Basis {basis_ref}")
    return failures


class RunStore:
    def __init__(self, path: Path):
        self.path = path.resolve()
        self.run_path = self.path / "run.json"
        self.events_path = self.path / "events.jsonl"
        self.artifacts_path = self.path / "artifacts"

    @property
    def exists(self) -> bool:
        return self.run_path.exists() and self.events_path.exists()

    def create(self, run_spec: dict[str, Any]) -> dict[str, Any]:
        validate_run_spec(run_spec)
        if self.path.exists() and any(self.path.iterdir()):
            raise RecordError(f"run directory is not empty: {self.path}")
        self.artifacts_path.mkdir(parents=True, exist_ok=True)
        atomic_write_text(self.run_path, dumps_canonical(run_spec) + "\n")
        event = self._event(
            sequence=1,
            prior_hash=ZERO_HASH,
            event_type="RUN_INITIALIZED",
            kind="run_spec",
            artifact_id="RUNSPEC",
            artifact_path="run.json",
            artifact_hash=digest_file(self.run_path),
            payload_hash=digest_json(run_spec),
            dependencies=[],
        )
        atomic_write_text(self.events_path, dumps_canonical(event) + "\n")
        return event

    def run_spec(self) -> dict[str, Any]:
        if not self.run_path.exists():
            raise RecordError(f"missing run.json in {self.path}")
        value = load_strict(self.run_path)
        validate_run_spec(value)
        return value

    def events(self) -> list[dict[str, Any]]:
        if not self.events_path.exists():
            raise RecordError(f"missing events.jsonl in {self.path}")
        events: list[dict[str, Any]] = []
        prior_hash = ZERO_HASH
        for line_number, line in enumerate(self.events_path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line:
                raise RecordError(f"empty event line {line_number} is not allowed")
            try:
                value = loads_strict(line)
            except ValueError as exc:
                raise RecordError(f"invalid event JSON on line {line_number}: {exc}") from exc
            if line != dumps_canonical(value):
                raise RecordError(f"event line {line_number} is not canonical JSON")
            event = _validate_event_record(value, line_number)
            if event["sequence"] != line_number:
                raise RecordError(f"event line {line_number} sequence is not contiguous")
            if event["prior_hash"] != prior_hash:
                raise RecordError(f"event line {line_number} prior_hash mismatch")
            body = {key: item for key, item in event.items() if key != "record_hash"}
            if event["record_hash"] != digest_json(body):
                raise RecordError(f"event line {line_number} record_hash mismatch")
            events.append(event)
            prior_hash = event["record_hash"]
        return events

    def _read_wrapper(self, event: dict[str, Any]) -> dict[str, Any]:
        path = self.path / event["artifact_path"]
        text = path.read_text(encoding="utf-8")
        value = loads_strict(text)
        if text != dumps_canonical(value) + "\n":
            raise RecordError(f"artifact {event['artifact_path']} is not canonical JSON")
        return _validate_artifact_wrapper(value, event=event)

    def _history(self, events: list[dict[str, Any]]) -> list[tuple[dict[str, Any], dict[str, Any]]]:
        history: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for event in events:
            if event["event_type"] == "ARTIFACT_RECORDED":
                history.append((event, self._read_wrapper(event)))
        return history

    def _event(
        self,
        *,
        sequence: int,
        prior_hash: str,
        event_type: str,
        kind: str,
        artifact_id: str,
        artifact_path: str,
        artifact_hash: str,
        payload_hash: str,
        dependencies: list[str],
    ) -> dict[str, Any]:
        body = {
            "schema_version": "architecture-plus.event/0.1",
            "sequence": sequence,
            "event_id": f"E-{sequence:06d}",
            "prior_hash": prior_hash,
            "event_type": event_type,
            "kind": kind,
            "artifact_id": artifact_id,
            "artifact_path": artifact_path,
            "artifact_hash": artifact_hash,
            "payload_hash": payload_hash,
            "dependencies": sorted(set(dependencies)),
        }
        return {**body, "record_hash": digest_json(body)}

    def _artifact_index(self) -> dict[str, dict[str, Any]]:
        return {
            event["artifact_id"]: event
            for event in self.events()
            if event.get("event_type") == "ARTIFACT_RECORDED"
        }

    def latest(self, kind: str) -> Any | None:
        for event in reversed(self.events()):
            if event.get("kind") == kind and event.get("event_type") == "ARTIFACT_RECORDED":
                wrapper = self._read_wrapper(event)
                return wrapper["payload"]
        return None

    def latest_artifacts(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for event in self.events():
            if event.get("event_type") == "ARTIFACT_RECORDED":
                wrapper = self._read_wrapper(event)
                out[event["kind"]] = wrapper["payload"]
        return out

    def seal(self, *, represented_operations: list[str] | None = None, open_obligations: list[str] | None = None) -> dict[str, Any]:
        run_spec = self.run_spec()
        events = self.events()
        required = ("candidate", "backward_sweep", "forward_sweep", "hinge_set", "trial", "binding_set")
        latest_events: dict[str, dict[str, Any]] = {}
        latest_payloads: dict[str, Any] = {}
        for event in events:
            if event.get("event_type") == "ARTIFACT_RECORDED":
                latest_events[event["kind"]] = event
                latest_payloads[event["kind"]] = self._read_wrapper(event)["payload"]
        missing = [kind for kind in required if kind not in latest_events]
        if missing:
            raise RecordError(f"Seal requires: {', '.join(missing)}")
        chain_failures = _latest_phase_chain_failures(self._history(events))
        if chain_failures:
            raise RecordError("Seal refuses stale phase snapshot: " + "; ".join(chain_failures))
        binding_set = latest_payloads["binding_set"]
        coverage_failures = _binding_coverage_failures(
            binding_set,
            latest_payloads["hinge_set"],
            latest_payloads["trial"],
        )
        if coverage_failures:
            raise RecordError("Seal refuses incomplete BindingSet: " + "; ".join(coverage_failures))
        admitted = sorted(binding["binding_id"] for binding in binding_set["bindings"] if binding["status"] == "ADMITTED")
        derived_open = [
            f"{binding['binding_id']}: {binding['statement']}"
            for binding in binding_set["bindings"]
            if binding["status"] == "OPEN"
        ]
        obligations = sorted(set(derived_open + (open_obligations or [])))
        head_hash = events[-1]["record_hash"]
        payload = {
            "kind": "Seal",
            "seal_id": f"S-{head_hash[:16]}",
            "run_spec_hash": digest_json(run_spec),
            "sealed_head_hash": head_hash,
            "artifact_hashes": {kind: latest_events[kind]["payload_hash"] for kind in required},
            "binding_set_hash": latest_events["binding_set"]["payload_hash"],
            "admitted_bindings": admitted,
            "represented_operations": sorted(set(represented_operations or [])),
            "budgets": run_spec.get("budget", {}),
            "open_obligations": obligations,
            "boundary": "The Seal freezes records of this declared run prefix. represented_operations are data, not permissions or executions. This reference runtime has no world-execution adapter and grants no authority, safety, truth, effect, or durability.",
        }
        dependencies = [latest_events[kind]["artifact_id"] for kind in required]
        return self._record("seal", payload, dependencies=dependencies, derived=True)

    def _cross_record_failures(
        self,
        kind: str,
        payload: Any,
        dependencies: list[str],
        run_spec: dict[str, Any],
        history: list[tuple[dict[str, Any], dict[str, Any]]],
    ) -> list[str]:
        failures: list[str] = []
        basis_ids = {item["id"] for item in run_spec.get("basis", [])}
        artifact_ids = {event["artifact_id"] for event, _ in history}
        latest_events: dict[str, dict[str, Any]] = {}
        latest_payloads: dict[str, Any] = {}
        hinges: dict[str, dict[str, Any]] = {}
        trials: dict[str, dict[str, Any]] = {}
        all_bindings: dict[str, dict[str, Any]] = {}
        cumulative_moves = 0
        for event, wrapper in history:
            prior_kind = event["kind"]
            prior_payload = wrapper["payload"]
            latest_events[prior_kind] = event
            latest_payloads[prior_kind] = prior_payload
            if prior_kind == "hinge_set":
                hinges.update({item["hinge_id"]: item for item in prior_payload.get("hinges", [])})
            elif prior_kind == "trial":
                cumulative_moves += len(prior_payload.get("trials", []))
                trials.update({item["trial_id"]: item for item in prior_payload.get("trials", [])})
            elif prior_kind == "binding_set":
                all_bindings.update({item["binding_id"]: item for item in prior_payload.get("bindings", [])})
        known_refs = basis_ids | artifact_ids | set(hinges) | set(trials) | set(all_bindings)

        phase_requirements = PHASE_DEPENDENCY_KINDS.get(kind, ())
        unavailable = [required_kind for required_kind in phase_requirements if required_kind not in latest_events]
        if unavailable:
            failures.append(f"{kind} requires prior phases: {', '.join(unavailable)}")
        else:
            required_ids = {latest_events[required_kind]["artifact_id"] for required_kind in phase_requirements}
            missing_phase_dependencies = sorted(required_ids - set(dependencies))
            if missing_phase_dependencies:
                failures.append(
                    f"{kind} dependencies omit latest required phase artifacts: {', '.join(missing_phase_dependencies)}"
                )

        current_hinges = {
            item["hinge_id"]: item
            for item in latest_payloads.get("hinge_set", {}).get("hinges", [])
        }
        current_trials = {
            item["trial_id"]: item
            for item in latest_payloads.get("trial", {}).get("trials", [])
        }

        if kind == "hinge_set":
            for hinge in payload.get("hinges", []):
                unknown = sorted(set(hinge.get("basis_refs", [])) - basis_ids)
                if unknown:
                    failures.append(f"Hinge {hinge.get('hinge_id')} has unknown basis_refs: {', '.join(unknown)}")

        elif kind == "trial":
            maximum = run_spec.get("budget", {}).get("max_moves")
            new_moves = len(payload.get("trials", []))
            if maximum is not None and cumulative_moves + new_moves > maximum:
                failures.append(f"cumulative Trial moves {cumulative_moves + new_moves} exceed max_moves {maximum}")
            for trial in payload.get("trials", []):
                trial_id = trial.get("trial_id")
                hinge = current_hinges.get(trial.get("hinge_id"))
                if hinge is None:
                    failures.append(f"Trial {trial_id} has unknown hinge_id {trial.get('hinge_id')}")
                    continue
                unknown = sorted(set(trial.get("evidence_refs", [])) - known_refs)
                if unknown:
                    failures.append(f"Trial {trial_id} has unknown evidence_refs: {', '.join(unknown)}")
                consequence = hinge.get("consequence_split", {})
                candidate_source = f"{hinge.get('candidate', '')} {consequence.get('candidate', '')}"
                rival_source = f"{hinge.get('rival', '')} {consequence.get('rival', '')}"
                if not _orientation_matches(trial.get("candidate", ""), candidate_source, rival_source):
                    failures.append(f"Trial {trial_id} candidate does not match Hinge {hinge.get('hinge_id')} candidate orientation")
                if not _orientation_matches(trial.get("rival", ""), rival_source, candidate_source):
                    failures.append(f"Trial {trial_id} rival does not match Hinge {hinge.get('hinge_id')} rival orientation")
                if set(trial.get("changed_return_fields", [])) != set(hinge.get("affected_fields", [])):
                    failures.append(f"Trial {trial_id} changed_return_fields mismatch Hinge {hinge.get('hinge_id')}")

        elif kind == "binding_set":
            for binding in payload.get("bindings", []):
                binding_id = binding.get("binding_id")
                checks = (
                    ("hinge_refs", set(current_hinges)),
                    ("trial_refs", set(current_trials)),
                    ("basis_refs", basis_ids),
                    ("dependencies", known_refs),
                    ("warrant witness_refs", known_refs),
                )
                for label, available in checks:
                    values = binding.get("warrant", {}).get("witness_refs", []) if label == "warrant witness_refs" else binding.get(label, [])
                    unknown = sorted(set(values) - available)
                    if unknown:
                        failures.append(f"Binding {binding_id} has unknown {label}: {', '.join(unknown)}")
                referenced_fields: set[str] = set()
                for ref in binding.get("hinge_refs", []):
                    referenced_fields |= set(current_hinges.get(ref, {}).get("affected_fields", []))
                for ref in binding.get("trial_refs", []):
                    referenced_fields |= set(current_trials.get(ref, {}).get("changed_return_fields", []))
            if "hinge_set" in latest_payloads and "trial" in latest_payloads:
                failures.extend(_binding_coverage_failures(
                    payload,
                    latest_payloads["hinge_set"],
                    latest_payloads["trial"],
                ))

        elif kind == "seal":
            failures.extend(_latest_phase_chain_failures(history))
            if "hinge_set" in latest_payloads and "trial" in latest_payloads and "binding_set" in latest_payloads:
                failures.extend(_binding_coverage_failures(
                    latest_payloads["binding_set"],
                    latest_payloads["hinge_set"],
                    latest_payloads["trial"],
                ))

        elif kind == "passage_model":
            refs = set(payload.get("basis_refs", [])) | set(payload.get("evidence_refs", []))
            for passage in payload.get("passages", []):
                refs |= set(passage.get("basis_refs", []))
            unknown = sorted(refs - basis_ids)
            if unknown:
                failures.append(f"PassageModel has unknown basis/evidence refs: {', '.join(unknown)}")

        elif kind == "passage_assessment":
            if len(dependencies) != 1:
                failures.append("PassageAssessment must have exactly one PassageModel dependency")
            elif not isinstance(payload, dict):
                failures.append("PassageAssessment must be an object produced by deterministic recomputation")
            else:
                dependency = next(
                    (
                        wrapper["payload"]
                        for event, wrapper in history
                        if event["artifact_id"] == dependencies[0] and event["kind"] == "passage_model"
                    ),
                    None,
                )
                if dependency is None:
                    failures.append("PassageAssessment sole dependency is not a prior PassageModel")
                else:
                    try:
                        expected = assess_passage(
                            dependency,
                            payload.get("configuration"),
                            payload.get("successor"),
                        )
                        if payload != expected:
                            failures.append("PassageAssessment does not exactly match deterministic recomputation")
                    except (TypeError, ValueError) as exc:
                        failures.append(f"PassageAssessment cannot be recomputed: {exc}")

        elif kind == "return_envelope":
            prior_artifacts = [event for event, _ in history]
            current_seal = latest_events.get("seal")
            current_binding_event = latest_events.get("binding_set")
            current_bindings = {
                item["binding_id"]: item
                for item in latest_payloads.get("binding_set", {}).get("bindings", [])
            }
            if not prior_artifacts or prior_artifacts[-1].get("kind") != "seal" or current_seal != prior_artifacts[-1]:
                failures.append("ReturnEnvelope requires the current Seal as the immediately preceding artifact")
            required_dependencies = {
                event["artifact_id"] for event in (current_seal, current_binding_event) if event is not None
            }
            missing = sorted(required_dependencies - set(dependencies))
            if missing:
                failures.append(f"ReturnEnvelope dependencies omit current Seal or BindingSet: {', '.join(missing)}")
            return_known = known_refs | set(current_bindings)
            for component in payload.get("components", []):
                field_id = component.get("field_id")
                binding_refs = set(component.get("binding_refs", []))
                unknown_bindings = sorted(binding_refs - set(current_bindings))
                if unknown_bindings:
                    failures.append(f"Return component {field_id} has unknown binding_refs: {', '.join(unknown_bindings)}")
                uncovered_bindings = sorted(
                    ref for ref in binding_refs
                    if ref in current_bindings and field_id not in set(current_bindings[ref].get("affected_fields", []))
                )
                if uncovered_bindings:
                    failures.append(
                        f"Return component {field_id} cites Bindings that do not cover the field: {', '.join(uncovered_bindings)}"
                    )
                support_refs = (
                    set(component.get("basis_refs", []))
                    | set(component.get("dependency_refs", []))
                    | set(component.get("counterwitness_refs", []))
                    | set(component.get("open_certificate", {}).get("reverse_evidence", []))
                )
                unknown_support = sorted(support_refs - return_known)
                if unknown_support:
                    failures.append(f"Return component {field_id} has unknown support refs: {', '.join(unknown_support)}")
                trace_unknown = sorted(set(payload.get("reverse_trace", {}).get(field_id, [])) - return_known)
                if trace_unknown:
                    failures.append(f"Return component {field_id} has unknown reverse_trace refs: {', '.join(trace_unknown)}")
                if component.get("outcome") == "EARNED":
                    if not binding_refs:
                        failures.append(f"EARNED Return component {field_id} has no binding_refs")
                    earned_support = any(
                        binding is not None
                        and field_id in set(binding.get("affected_fields", []))
                        and binding.get("status") == "ADMITTED"
                        and binding.get("warrant", {}).get("status") == "SUPPORTED"
                        and bool(binding.get("warrant", {}).get("witness_refs"))
                        for binding in (current_bindings.get(ref) for ref in binding_refs)
                    )
                    if not earned_support:
                        failures.append(
                            f"EARNED Return component {field_id} lacks an ADMITTED, SUPPORTED, witnessed Binding covering the field"
                        )
                if component.get("outcome") == "REJECTED" and not component.get("counterwitness_refs"):
                    failures.append(f"REJECTED Return component {field_id} lacks counterwitness_refs")
            stop = payload.get("stop_basis", {}).get("move_budget", {})
            maximum = run_spec.get("budget", {}).get("max_moves")
            if maximum is not None:
                if stop.get("maximum") != maximum:
                    failures.append("Return stop move budget maximum does not match RunSpec")
                if stop.get("used") != cumulative_moves:
                    failures.append(f"Return stop move budget used {stop.get('used')} does not match cumulative Trial moves {cumulative_moves}")
                if stop.get("remaining") != maximum - cumulative_moves:
                    failures.append("Return stop move budget remaining does not match RunSpec minus cumulative Trial moves")

        elif kind == "outcome_receipt":
            current_return = latest_events.get("return_envelope")
            if current_return is None or current_return["artifact_id"] not in set(dependencies):
                failures.append("OutcomeReceipt must depend on the current ReturnEnvelope")
            outcome_known = known_refs | set(all_bindings)
            for stage, record in payload.get("stages", {}).items():
                unknown_basis = sorted(set(record.get("basis_refs", [])) - basis_ids)
                unknown_evidence = sorted(set(record.get("evidence_refs", [])) - outcome_known)
                if unknown_basis:
                    failures.append(f"Outcome stage {stage} has unknown basis_refs: {', '.join(unknown_basis)}")
                if unknown_evidence:
                    failures.append(f"Outcome stage {stage} has unknown evidence_refs: {', '.join(unknown_evidence)}")

        elif kind == "reentry":
            current_return = latest_events.get("return_envelope")
            expected_dependencies = [current_return["artifact_id"]] if current_return is not None else []
            if dependencies != expected_dependencies:
                failures.append("Reentry must depend only on the current ReturnEnvelope")
            if payload.get("parent_run_id") != run_spec.get("run_id"):
                failures.append("Reentry parent_run_id does not match the parent RunSpec")
            expected_head = history[-1][0]["record_hash"] if history else None
            if payload.get("parent_head_hash") != expected_head:
                failures.append("Reentry parent_head_hash does not match the live parent head")
            child_spec = payload.get("child_run_spec")
            if isinstance(child_spec, dict) and isinstance(expected_head, str):
                failures.extend(_child_spec_failures(
                    run_spec,
                    child_spec,
                    payload.get("changed_refs", []),
                    expected_head,
                    history,
                ))
            if current_return is not None:
                assessment = self._reopen_from_history(
                    run_spec,
                    history,
                    set(payload.get("changed_refs", [])),
                )
                if payload.get("affected_fields") != assessment.get("affected_fields"):
                    failures.append("Reentry affected_fields do not match dependency reassessment")
                if payload.get("carried_fields") != assessment.get("unchanged_fields"):
                    failures.append("Reentry carried_fields do not match dependency reassessment")
                envelope = latest_payloads["return_envelope"]
                expected_proof = self._carry_proof(envelope, payload.get("carried_fields", []))
                if payload.get("carry_proof") != expected_proof:
                    failures.append("Reentry carry_proof does not match the current ReturnEnvelope")
        return failures

    def record(self, kind: str, payload: Any, *, dependencies: list[str] | None = None) -> dict[str, Any]:
        return self._record(kind, payload, dependencies=dependencies, derived=False)

    def _record(
        self,
        kind: str,
        payload: Any,
        *,
        dependencies: list[str] | None = None,
        derived: bool,
    ) -> dict[str, Any]:
        run_spec = self.run_spec()
        dependencies = dependencies or []
        events = self.events()
        history = self._history(events)
        if kind in {"seal", "reentry", "passage_assessment"} and not derived:
            raise RecordError(f"{kind} is a derived record; use its dedicated command")
        if kind == "candidate" and any(event.get("kind") == "candidate" for event in events):
            raise RecordError("P0 is frozen: a run may record exactly one candidate")
        if kind == "candidate":
            basis = run_spec.get("basis", [])
            visible = basis if run_spec.get("formation_mode") == "GUIDED" else [item for item in basis if item.get("expose_to_free", False)]
            exposed = {item["id"] for item in visible}
            forbidden = sorted(set(dependencies) - exposed)
            if forbidden:
                raise RecordError(f"formation firewall forbids P0 dependencies: {', '.join(forbidden)}")
            dependencies = sorted(exposed)
        if kind == "return_envelope":
            prior_artifacts = [event for event in events if event.get("event_type") == "ARTIFACT_RECORDED"]
            if not prior_artifacts or prior_artifacts[-1].get("kind") != "seal":
                raise RecordError("ReturnEnvelope requires a current Seal as the immediately preceding artifact")
            latest_binding = next((event for event in reversed(prior_artifacts) if event.get("kind") == "binding_set"), None)
            if latest_binding is None:
                raise RecordError("ReturnEnvelope requires a BindingSet")
            required_refs = {prior_artifacts[-1]["artifact_id"], latest_binding["artifact_id"]}
            missing_refs = sorted(required_refs - set(dependencies))
            if missing_refs:
                raise RecordError(f"ReturnEnvelope dependencies omit current Seal or BindingSet: {', '.join(missing_refs)}")
        if kind == "return_envelope":
            for component in payload.get("components", []) if isinstance(payload, dict) else []:
                certificate = component.get("open_certificate")
                if isinstance(certificate, dict) and certificate.get("artifact_fingerprint") == "DERIVE":
                    certificate["artifact_fingerprint"] = "sha256:" + digest_json({
                        key: value for key, value in certificate.items() if key != "artifact_fingerprint"
                    })
        validate_artifact(kind, payload, return_field_ids(run_spec))
        known = {"RUNSPEC"} | {event["artifact_id"] for event, _ in history} | {item["id"] for item in run_spec.get("basis", [])}
        unknown = sorted(set(dependencies) - known)
        if unknown:
            raise RecordError(f"unknown dependencies: {', '.join(unknown)}")
        cross_failures = self._cross_record_failures(kind, payload, dependencies, run_spec, history)
        if cross_failures:
            raise RecordError("; ".join(cross_failures))
        sequence = len(events) + 1
        artifact_id = f"A-{sequence:06d}"
        payload_hash = digest_json(payload)
        wrapper = {
            "schema_version": "architecture-plus.artifact/0.1",
            "artifact_id": artifact_id,
            "run_id": run_spec["run_id"],
            "kind": kind,
            "payload_hash": payload_hash,
            "dependencies": sorted(set(dependencies)),
            "payload": payload,
        }
        if kind == "candidate":
            basis = run_spec.get("basis", [])
            visible_basis = basis if run_spec.get("formation_mode") == "GUIDED" else [item for item in basis if item.get("expose_to_free", False)]
            packet = Path(__file__).resolve().parents[2]
            prompt_text = render_prompt(packet, "free", run_spec, {})
            template_name = "guided.txt" if run_spec.get("formation_mode") == "GUIDED" else "free.txt"
            attestation = run_spec.get("formation_context_attestation") or {
                "outcome": "OPEN",
                "first_exact_break": "The runtime can fingerprint its projected prompt but received no controlled-host attestation for the full effective model context.",
                "support_ceiling": "Prompt projection and declared dependencies only",
                "reentry": "Run under a controlled host that attests the full effective context and invocation boundary.",
            }
            wrapper["formation_manifest"] = {
                "formation_mode": run_spec.get("formation_mode", "NATIVE"),
                "raw_request_hash": digest_json(run_spec["request"]),
                "supplied_basis_hashes": {item["id"]: digest_json(item) for item in visible_basis},
                "unavoidable_policy_ids": sorted(run_spec.get("unavoidable_policy_ids", [])),
                "declared_tools": run_spec.get("allowed_tools", []),
                "requested_output_form": run_spec.get("requested_output_form", "best form for the request"),
                "model_or_agent_identity_if_known": run_spec.get("metadata", {}).get("model_or_agent_identity", "UNKNOWN"),
                "forbidden_scaffold_classes": [] if run_spec.get("formation_mode") == "GUIDED" else [
                    "Architecture+ lexicon",
                    "Passage Theory vocabulary",
                    "architecture-generated interpretation",
                    "architecture-generated rival",
                    "expected answer",
                    "prior branch output",
                    "old-project authority",
                ],
                "firewall_waivers": run_spec.get("firewall_waivers", []),
                "formation_prompt_hash": digest_bytes(prompt_text.encode("utf-8")),
                "formation_template_hash": digest_file(packet / "prompts" / template_name),
                "formation_context_attestation_or_OPEN": attestation,
                "output_hash": payload_hash,
            }
        suffix = payload_hash[:12]
        relative = Path("artifacts") / f"{artifact_id}-{kind}-{suffix}.json"
        target = self.path / relative
        atomic_write_text(target, dumps_canonical(wrapper) + "\n")
        event = self._event(
            sequence=sequence,
            prior_hash=events[-1]["record_hash"],
            event_type="ARTIFACT_RECORDED",
            kind=kind,
            artifact_id=artifact_id,
            artifact_path=relative.as_posix(),
            artifact_hash=digest_file(target),
            payload_hash=payload_hash,
            dependencies=dependencies,
        )
        with self.events_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(dumps_canonical(event) + "\n")
            handle.flush()
        return event

    def assess_passage(self, *, state: str, successor: str | None = None) -> dict[str, Any]:
        """Derive and append an assessment from the current recorded PassageModel."""
        events = self.events()
        model_event = next(
            (
                event for event in reversed(events)
                if event.get("event_type") == "ARTIFACT_RECORDED" and event.get("kind") == "passage_model"
            ),
            None,
        )
        if model_event is None:
            raise RecordError("PassageAssessment requires a recorded PassageModel")
        model = self._read_wrapper(model_event)["payload"]
        payload = assess_passage(model, state, successor)
        return self._record(
            "passage_assessment",
            payload,
            dependencies=[model_event["artifact_id"]],
            derived=True,
        )

    def audit(self) -> dict[str, Any]:
        failures: list[str] = []
        try:
            run_spec = self.run_spec()
        except (OSError, ValueError) as exc:
            return {"status": "FAIL", "failures": [str(exc)]}
        try:
            events = self.events()
        except (OSError, ValueError) as exc:
            return {"status": "FAIL", "failures": [str(exc)]}
        prior = ZERO_HASH
        artifact_ids: set[str] = {"RUNSPEC"}
        basis_ids = {item["id"] for item in run_spec.get("basis", [])}
        prior_kind_events: dict[str, dict[str, Any]] = {}
        prior_kind_payloads: dict[str, Any] = {}
        audit_history: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for index, event in enumerate(events, start=1):
            if event.get("sequence") != index:
                failures.append(f"event {index}: sequence mismatch")
            if event.get("event_id") != f"E-{index:06d}":
                failures.append(f"event {index}: event_id mismatch")
            if event.get("prior_hash") != prior:
                failures.append(f"event {index}: prior_hash mismatch")
            body = {key: value for key, value in event.items() if key != "record_hash"}
            expected_hash = digest_json(body)
            if event.get("record_hash") != expected_hash:
                failures.append(f"event {index}: record_hash mismatch")
            relative = event.get("artifact_path")
            if not isinstance(relative, str) or relative.startswith("/") or ".." in Path(relative).parts:
                failures.append(f"event {index}: unsafe artifact_path")
            else:
                path = self.path / relative
                if not path.exists():
                    failures.append(f"event {index}: missing artifact {relative}")
                elif digest_file(path) != event.get("artifact_hash"):
                    failures.append(f"event {index}: artifact_hash mismatch")
                elif event.get("event_type") == "ARTIFACT_RECORDED":
                    try:
                        wrapper = self._read_wrapper(event)
                        if wrapper.get("payload_hash") != digest_json(wrapper.get("payload")):
                            failures.append(f"event {index}: wrapper payload_hash mismatch")
                        if wrapper.get("payload_hash") != event.get("payload_hash"):
                            failures.append(f"event {index}: event payload_hash mismatch")
                        if event.get("kind") == "candidate":
                            basis = run_spec.get("basis", [])
                            visible_basis = basis if run_spec.get("formation_mode") == "GUIDED" else [item for item in basis if item.get("expose_to_free", False)]
                            packet = Path(__file__).resolve().parents[2]
                            prompt_text = render_prompt(packet, "free", run_spec, {})
                            template_name = "guided.txt" if run_spec.get("formation_mode") == "GUIDED" else "free.txt"
                            attestation = run_spec.get("formation_context_attestation") or {
                                "outcome": "OPEN",
                                "first_exact_break": "The runtime can fingerprint its projected prompt but received no controlled-host attestation for the full effective model context.",
                                "support_ceiling": "Prompt projection and declared dependencies only",
                                "reentry": "Run under a controlled host that attests the full effective context and invocation boundary.",
                            }
                            expected_manifest = {
                                "formation_mode": run_spec.get("formation_mode", "NATIVE"),
                                "raw_request_hash": digest_json(run_spec["request"]),
                                "supplied_basis_hashes": {item["id"]: digest_json(item) for item in visible_basis},
                                "unavoidable_policy_ids": sorted(run_spec.get("unavoidable_policy_ids", [])),
                                "declared_tools": run_spec.get("allowed_tools", []),
                                "requested_output_form": run_spec.get("requested_output_form", "best form for the request"),
                                "model_or_agent_identity_if_known": run_spec.get("metadata", {}).get("model_or_agent_identity", "UNKNOWN"),
                                "forbidden_scaffold_classes": [] if run_spec.get("formation_mode") == "GUIDED" else [
                                    "Architecture+ lexicon",
                                    "Passage Theory vocabulary",
                                    "architecture-generated interpretation",
                                    "architecture-generated rival",
                                    "expected answer",
                                    "prior branch output",
                                    "old-project authority",
                                ],
                                "firewall_waivers": run_spec.get("firewall_waivers", []),
                                "formation_prompt_hash": digest_bytes(prompt_text.encode("utf-8")),
                                "formation_template_hash": digest_file(packet / "prompts" / template_name),
                                "formation_context_attestation_or_OPEN": attestation,
                                "output_hash": wrapper.get("payload_hash"),
                            }
                            if wrapper.get("formation_manifest") != expected_manifest:
                                failures.append(f"event {index}: formation_manifest mismatch")
                            expected_dependencies = sorted(item["id"] for item in visible_basis)
                            if event.get("dependencies") != expected_dependencies:
                                failures.append(f"event {index}: formation firewall dependency mismatch")
                        validate_artifact(event.get("kind", ""), wrapper.get("payload"), return_field_ids(run_spec))
                        for failure in self._cross_record_failures(
                            event["kind"], wrapper["payload"], event["dependencies"], run_spec, audit_history
                        ):
                            failures.append(f"event {index}: {failure}")
                        if event.get("kind") == "seal":
                            seal = wrapper["payload"]
                            required = ("candidate", "backward_sweep", "forward_sweep", "hinge_set", "trial", "binding_set")
                            missing_kinds = [kind for kind in required if kind not in prior_kind_events]
                            if missing_kinds:
                                failures.append(f"event {index}: Seal lacks prior artifacts: {', '.join(missing_kinds)}")
                            else:
                                expected_hashes = {kind: prior_kind_events[kind]["payload_hash"] for kind in required}
                                if seal.get("artifact_hashes") != expected_hashes:
                                    failures.append(f"event {index}: Seal artifact_hashes mismatch")
                                if seal.get("sealed_head_hash") != prior:
                                    failures.append(f"event {index}: Seal sealed_head_hash mismatch")
                                if seal.get("run_spec_hash") != digest_json(run_spec):
                                    failures.append(f"event {index}: Seal run_spec_hash mismatch")
                                if seal.get("binding_set_hash") != prior_kind_events["binding_set"]["payload_hash"]:
                                    failures.append(f"event {index}: Seal binding_set_hash mismatch")
                                bindings = prior_kind_payloads["binding_set"]["bindings"]
                                expected_admitted = sorted(binding["binding_id"] for binding in bindings if binding["status"] == "ADMITTED")
                                if seal.get("admitted_bindings") != expected_admitted:
                                    failures.append(f"event {index}: Seal admitted_bindings mismatch")
                                required_open = {f"{binding['binding_id']}: {binding['statement']}" for binding in bindings if binding["status"] == "OPEN"}
                                if not required_open.issubset(set(seal.get("open_obligations", []))):
                                    failures.append(f"event {index}: Seal omits open Binding obligations")
                        if event.get("kind") == "binding_set":
                            if "hinge_set" not in prior_kind_payloads or "trial" not in prior_kind_payloads:
                                failures.append(f"event {index}: BindingSet lacks prior HingeSet or TrialSet")
                            else:
                                hinge_ids = {hinge["hinge_id"] for hinge in prior_kind_payloads["hinge_set"].get("hinges", [])}
                                trial_ids = {trial["trial_id"] for trial in prior_kind_payloads["trial"].get("trials", [])}
                                available_refs = artifact_ids | basis_ids
                                for binding in wrapper["payload"].get("bindings", []):
                                    bid = binding.get("binding_id")
                                    unknown_hinges = sorted(set(binding.get("hinge_refs", [])) - hinge_ids)
                                    unknown_trials = sorted(set(binding.get("trial_refs", [])) - trial_ids)
                                    unknown_basis = sorted(set(binding.get("basis_refs", [])) - basis_ids)
                                    unknown_dependencies = sorted(set(binding.get("dependencies", [])) - available_refs)
                                    unknown_witnesses = sorted(set(binding.get("warrant", {}).get("witness_refs", [])) - available_refs)
                                    if unknown_hinges:
                                        failures.append(f"event {index}: Binding {bid} has unknown hinge_refs: {', '.join(unknown_hinges)}")
                                    if unknown_trials:
                                        failures.append(f"event {index}: Binding {bid} has unknown trial_refs: {', '.join(unknown_trials)}")
                                    if unknown_basis:
                                        failures.append(f"event {index}: Binding {bid} has unknown basis_refs: {', '.join(unknown_basis)}")
                                    if unknown_dependencies:
                                        failures.append(f"event {index}: Binding {bid} has unknown dependencies: {', '.join(unknown_dependencies)}")
                                    if unknown_witnesses:
                                        failures.append(f"event {index}: Binding {bid} has unknown witness_refs: {', '.join(unknown_witnesses)}")
                        if event.get("kind") == "hinge_set":
                            for hinge in wrapper["payload"].get("hinges", []):
                                unknown_refs = sorted(set(hinge.get("basis_refs", [])) - basis_ids)
                                if unknown_refs:
                                    failures.append(f"event {index}: Hinge {hinge.get('hinge_id')} has unknown basis_refs: {', '.join(unknown_refs)}")
                        if event.get("kind") == "trial":
                            hinge_ids = {hinge["hinge_id"] for hinge in prior_kind_payloads.get("hinge_set", {}).get("hinges", [])}
                            known_refs = artifact_ids | basis_ids
                            for trial in wrapper["payload"].get("trials", []):
                                if trial.get("hinge_id") not in hinge_ids:
                                    failures.append(f"event {index}: Trial {trial.get('trial_id')} has unknown hinge_id {trial.get('hinge_id')}")
                                unknown_refs = sorted(set(trial.get("evidence_refs", [])) - known_refs)
                                if unknown_refs:
                                    failures.append(f"event {index}: Trial {trial.get('trial_id')} has unknown evidence_refs: {', '.join(unknown_refs)}")
                        if event.get("kind") == "passage_model":
                            model = wrapper["payload"]
                            refs = set(model.get("basis_refs", []))
                            for passage in model.get("passages", []):
                                refs |= set(passage.get("basis_refs", []))
                            unknown_refs = sorted(refs - basis_ids)
                            if unknown_refs:
                                failures.append(f"event {index}: PassageModel has unknown basis_refs: {', '.join(unknown_refs)}")
                        if event.get("kind") == "return_envelope":
                            if "seal" not in prior_kind_events or "binding_set" not in prior_kind_events:
                                failures.append(f"event {index}: ReturnEnvelope lacks prior Seal or BindingSet")
                            else:
                                required_deps = {prior_kind_events["seal"]["artifact_id"], prior_kind_events["binding_set"]["artifact_id"]}
                                if not required_deps.issubset(set(event.get("dependencies", []))):
                                    failures.append(f"event {index}: ReturnEnvelope dependencies omit current Seal or BindingSet")
                                binding_ids = {binding["binding_id"] for binding in prior_kind_payloads["binding_set"]["bindings"]}
                                binding_map = {binding["binding_id"]: binding for binding in prior_kind_payloads["binding_set"]["bindings"]}
                                for component in wrapper["payload"].get("components", []):
                                    unknown_binding_refs = sorted(set(component.get("binding_refs", [])) - binding_ids)
                                    if unknown_binding_refs:
                                        failures.append(f"event {index}: Return component {component.get('field_id')} has unknown binding_refs: {', '.join(unknown_binding_refs)}")
                                    uncovered_binding_refs = sorted(
                                        ref for ref in component.get("binding_refs", [])
                                        if ref in binding_map and component.get("field_id") not in set(binding_map[ref].get("affected_fields", []))
                                    )
                                    if uncovered_binding_refs:
                                        failures.append(
                                            f"event {index}: Return component {component.get('field_id')} cites Bindings that do not cover the field: {', '.join(uncovered_binding_refs)}"
                                        )
                                    known_dependency_refs = artifact_ids | basis_ids | binding_ids
                                    unknown_refs = sorted(set(component.get("basis_refs", []) + component.get("dependency_refs", [])) - known_dependency_refs)
                                    if unknown_refs:
                                        failures.append(f"event {index}: Return component {component.get('field_id')} has unknown reverse refs: {', '.join(unknown_refs)}")
                                    if component.get("outcome") == "EARNED":
                                        refs = component.get("binding_refs", [])
                                        if not refs:
                                            failures.append(f"event {index}: EARNED Return component {component.get('field_id')} has no binding_refs")
                                        earned_support = any(
                                            binding is not None
                                            and component.get("field_id") in set(binding.get("affected_fields", []))
                                            and binding.get("status") == "ADMITTED"
                                            and binding.get("warrant", {}).get("status") == "SUPPORTED"
                                            and bool(binding.get("warrant", {}).get("witness_refs"))
                                            for binding in (binding_map.get(ref) for ref in refs)
                                        )
                                        if not earned_support:
                                            failures.append(
                                                f"event {index}: EARNED Return component {component.get('field_id')} lacks an ADMITTED, SUPPORTED, witnessed Binding covering the field"
                                            )
                                    counter_unknown = sorted(set(component.get("counterwitness_refs", [])) - known_dependency_refs)
                                    if counter_unknown:
                                        failures.append(f"event {index}: Return component {component.get('field_id')} has unknown counterwitness_refs: {', '.join(counter_unknown)}")
                                stop_budget = wrapper["payload"].get("stop_basis", {}).get("move_budget", {})
                                declared_max = run_spec.get("budget", {}).get("max_moves")
                                if declared_max is not None and stop_budget.get("maximum") != declared_max:
                                    failures.append(f"event {index}: stop move budget maximum does not match RunSpec")
                        if event.get("kind") == "outcome_receipt":
                            current_return = prior_kind_events.get("return_envelope")
                            if current_return is None or current_return["artifact_id"] not in set(event.get("dependencies", [])):
                                failures.append(f"event {index}: OutcomeReceipt does not depend on the current ReturnEnvelope")
                            binding_ids = {binding["binding_id"] for binding in prior_kind_payloads.get("binding_set", {}).get("bindings", [])}
                            known_refs = artifact_ids | basis_ids | binding_ids
                            for stage, record in wrapper["payload"].get("stages", {}).items():
                                unknown_basis = sorted(set(record.get("basis_refs", [])) - basis_ids)
                                unknown_evidence = sorted(set(record.get("evidence_refs", [])) - known_refs)
                                if unknown_basis:
                                    failures.append(f"event {index}: Outcome stage {stage} has unknown basis_refs: {', '.join(unknown_basis)}")
                                if unknown_evidence:
                                    failures.append(f"event {index}: Outcome stage {stage} has unknown evidence_refs: {', '.join(unknown_evidence)}")
                    except (OSError, ValueError) as exc:
                        failures.append(f"event {index}: invalid artifact: {exc}")
            dependencies = event.get("dependencies", [])
            if not isinstance(dependencies, list):
                failures.append(f"event {index}: dependencies must be an array")
            else:
                unknown = sorted(set(dependencies) - artifact_ids - basis_ids)
                if unknown:
                    failures.append(f"event {index}: dependencies not yet available: {', '.join(unknown)}")
            artifact_id = event.get("artifact_id")
            if artifact_id in artifact_ids and artifact_id != "RUNSPEC":
                failures.append(f"event {index}: duplicate artifact_id {artifact_id}")
            if isinstance(artifact_id, str):
                artifact_ids.add(artifact_id)
            if event.get("event_type") == "ARTIFACT_RECORDED" and isinstance(relative, str) and (self.path / relative).exists():
                try:
                    prior_kind_events[event["kind"]] = event
                    current_wrapper = self._read_wrapper(event)
                    prior_kind_payloads[event["kind"]] = current_wrapper["payload"]
                    audit_history.append((event, current_wrapper))
                except (OSError, ValueError):
                    pass
            prior = event.get("record_hash", "")
        candidate_count = sum(1 for event in events if event.get("kind") == "candidate")
        if candidate_count > 1:
            failures.append("formation firewall: more than one P0 candidate exists")
        for failure in _latest_phase_chain_failures(audit_history):
            failures.append(f"current phase snapshot: {failure}")
        return {
            "status": "PASS" if not failures else "FAIL",
            "run_id": run_spec["run_id"],
            "events": len(events),
            "artifacts": max(0, len(events) - 1),
            "head_hash": events[-1]["record_hash"] if events else None,
            "failures": failures,
            "boundary": "PASS certifies local format, references, hashes, append order, and declared structural contracts; it does not certify truth, authenticity, authority, world effects, causation, or completeness outside declared dependencies.",
        }

    def _dependency_graph_from_history(
        self,
        history: list[tuple[dict[str, Any], dict[str, Any]]],
    ) -> dict[str, set[str]]:
        graph: dict[str, set[str]] = {}
        for event, wrapper in history:
            artifact_id = event["artifact_id"]
            payload = wrapper["payload"]
            graph[artifact_id] = {"RUNSPEC"} | set(event["dependencies"])
            if event["kind"] == "hinge_set":
                for hinge in payload.get("hinges", []):
                    graph.setdefault(hinge["hinge_id"], set()).update(
                        {artifact_id} | set(hinge.get("basis_refs", []))
                    )
            elif event["kind"] == "trial":
                for trial in payload.get("trials", []):
                    graph.setdefault(trial["trial_id"], set()).update(
                        {artifact_id, trial["hinge_id"]} | set(trial.get("evidence_refs", []))
                    )
            elif event["kind"] == "binding_set":
                for binding in payload.get("bindings", []):
                    graph.setdefault(binding["binding_id"], set()).update(
                        {artifact_id}
                        | set(binding.get("hinge_refs", []))
                        | set(binding.get("trial_refs", []))
                        | set(binding.get("basis_refs", []))
                        | set(binding.get("dependencies", []))
                        | set(binding.get("warrant", {}).get("witness_refs", []))
                    )
        return graph

    def dependency_graph(self) -> dict[str, set[str]]:
        return self._dependency_graph_from_history(self._history(self.events()))

    def _reverse_dependency_closure_from_history(
        self,
        history: list[tuple[dict[str, Any], dict[str, Any]]],
        changed_refs: set[str],
    ) -> tuple[set[str], set[str]]:
        graph = self._dependency_graph_from_history(history)
        known_refs = {"RUNSPEC"} | set(graph)
        reverse: dict[str, set[str]] = {}
        for dependent, dependencies in graph.items():
            known_refs.update(dependencies)
            for dependency in dependencies:
                reverse.setdefault(dependency, set()).add(dependent)
        reached = set(changed_refs)
        frontier = list(changed_refs)
        while frontier:
            dependency = frontier.pop()
            for dependent in reverse.get(dependency, set()):
                if dependent not in reached:
                    reached.add(dependent)
                    frontier.append(dependent)
        return reached, known_refs

    @staticmethod
    def _component_support_refs(envelope: dict[str, Any], component: dict[str, Any]) -> set[str]:
        refs = (
            set(component.get("basis_refs", []))
            | set(component.get("binding_refs", []))
            | set(component.get("dependency_refs", []))
            | set(component.get("counterwitness_refs", []))
            | set(envelope.get("reverse_trace", {}).get(component["field_id"], []))
        )
        certificate = component.get("open_certificate")
        if isinstance(certificate, dict):
            refs |= set(certificate.get("reverse_evidence", []))
        return refs

    def _reopen_from_history(
        self,
        run_spec: dict[str, Any],
        history: list[tuple[dict[str, Any], dict[str, Any]]],
        changed_refs: set[str],
    ) -> dict[str, Any]:
        return_ids = return_field_ids(run_spec)
        latest_events: dict[str, dict[str, Any]] = {}
        latest_payloads: dict[str, Any] = {}
        for event, wrapper in history:
            latest_events[event["kind"]] = event
            latest_payloads[event["kind"]] = wrapper["payload"]
        envelope = latest_payloads.get("return_envelope")
        reached_refs, known_refs = self._reverse_dependency_closure_from_history(history, changed_refs)
        known_refs |= {item["id"] for item in run_spec.get("basis", [])}
        unknown_refs = sorted(changed_refs - known_refs)
        if envelope is None:
            return {
                "outcome": "OPEN",
                "reason": "no ReturnEnvelope has been recorded",
                "affected_fields": sorted(return_ids),
                "unchanged_fields": [],
                "unknown_refs": unknown_refs,
                "reentry": "compile a ReturnEnvelope, then reassess the changed dependencies",
            }
        current_boundary_artifacts = {
            event["artifact_id"]
            for kind in ("seal", "return_envelope")
            for event in [latest_events.get(kind)]
            if event is not None
        }
        affected: set[str] = set()
        if changed_refs & current_boundary_artifacts:
            affected |= return_ids
        for component in envelope.get("components", []):
            if self._component_support_refs(envelope, component) & reached_refs:
                affected.add(component["field_id"])
        changed = True
        while changed:
            changed = False
            for component in envelope.get("components", []):
                if component["field_id"] not in affected and set(component.get("depends_on_fields", [])) & affected:
                    affected.add(component["field_id"])
                    changed = True
        if unknown_refs:
            affected |= return_ids
        return {
            "outcome": "OPEN" if affected else "EARNED",
            "scope": "declared dependency interface only",
            "changed_refs": sorted(changed_refs),
            "unknown_refs": unknown_refs,
            "affected_fields": sorted(affected),
            "unchanged_fields": sorted(return_ids - affected),
            "reentry": {
                "trigger": "changed dependency is available",
                "action": "rerun only the affected return fields and every downstream artifact that declares them",
                "standing_ceiling": "no prior Standing survives for affected fields until locally re-earned",
            },
        }

    def _carry_proof(self, envelope: dict[str, Any], carried: list[str]) -> dict[str, Any]:
        component_map = {component["field_id"]: component for component in envelope["components"]}
        return {
            field_id: {
                "source_return_hash": digest_json(component_map[field_id]),
                "dependency_refs": sorted(self._component_support_refs(envelope, component_map[field_id])),
                "equivalence_witness": CARRY_WITNESS,
                "support_ceiling": component_map[field_id]["support_ceiling"],
            }
            for field_id in carried
        }

    def reopen(self, changed_refs: list[str]) -> dict[str, Any]:
        run_spec = self.run_spec()
        return self._reopen_from_history(
            run_spec,
            self._history(self.events()),
            set(changed_refs),
        )

    def create_child(
        self,
        changed_refs: list[str],
        child_path: Path,
        *,
        child_spec: dict[str, Any],
    ) -> dict[str, Any]:
        child_store = RunStore(child_path)
        if child_store.path.exists():
            if not child_store.path.is_dir() or any(child_store.path.iterdir()):
                raise RecordError(f"child run target is not empty: {child_store.path}")
            raise RecordError(f"child run target already exists: {child_store.path}")
        validate_run_spec(child_spec)
        parent_spec = self.run_spec()
        events = self.events()
        history = self._history(events)
        parent_head_hash = events[-1]["record_hash"]
        normalized_changed_refs = sorted(set(changed_refs))
        child_failures = _child_spec_failures(
            parent_spec,
            child_spec,
            normalized_changed_refs,
            parent_head_hash,
            history,
        )
        if child_failures:
            raise RecordError("invalid child RunSpec: " + "; ".join(child_failures))
        assessment = self._reopen_from_history(parent_spec, history, set(normalized_changed_refs))
        if assessment.get("unknown_refs"):
            first_break = f"Changed reference is outside the declared parent dependency interface: {assessment['unknown_refs'][0]}"
        elif assessment.get("affected_fields"):
            first_break = f"Parent support first reopens at Return field {assessment['affected_fields'][0]}"
        else:
            first_break = "No declared parent Return field is affected by the supplied changed references."
        parent_return = next(
            (
                wrapper["payload"]
                for event, wrapper in reversed(history)
                if event["kind"] == "return_envelope"
            ),
            None,
        )
        if parent_return is None:
            raise RecordError("create-child requires a parent ReturnEnvelope")
        carried = assessment.get("unchanged_fields", [])
        proof = self._carry_proof(parent_return, carried)
        record = {
            "kind": "Reentry",
            "parent_run_id": parent_spec["run_id"],
            "parent_head_hash": parent_head_hash,
            "changed_refs": normalized_changed_refs,
            "affected_fields": assessment.get("affected_fields", []),
            "carried_fields": carried,
            "carry_proof": proof,
            "first_exact_break": first_break,
            "remaining_obligations": ["re-earn every affected Return field under the child Basis"],
            "earliest_useful_reentry": assessment.get("reentry"),
            "child_run_spec": child_spec,
            "child_run_spec_hash": digest_json(child_spec),
        }
        validate_reentry(record, return_field_ids(parent_spec))
        dependencies = [
            next(
                event["artifact_id"]
                for event in reversed(events)
                if event.get("kind") == "return_envelope"
            )
        ]
        result = {
            "status": "PASS",
            "reentry": record,
            "child_run": str(child_store.path),
            "child_state": "EMPTY_REASSESSMENT_SHELL",
            "child_artifacts": [],
            "boundary": "The child uses the supplied validated RunSpec but contains no candidate, assessment, Binding, Seal, or Return; all affected support must be locally re-earned.",
        }
        child_parent = child_store.path.parent
        child_parent.mkdir(parents=True, exist_ok=True)
        parent_events_before = self.events_path.read_bytes()
        parent_artifacts_before = {
            path.name for path in self.artifacts_path.iterdir() if path.is_file()
        }
        staging_path = Path(tempfile.mkdtemp(prefix=f".{child_store.path.name}.stage-", dir=child_parent))

        def rollback_parent() -> None:
            atomic_write(self.events_path, parent_events_before)
            for path in self.artifacts_path.iterdir():
                if path.is_file() and path.name not in parent_artifacts_before:
                    path.unlink()

        try:
            staged_store = RunStore(staging_path)
            staged_store.create(child_spec)
            if staged_store.run_spec() != child_spec or len(staged_store.events()) != 1:
                raise RecordError("staged child RunSpec failed exact materialization verification")
            if child_store.path.exists():
                raise RecordError(f"child run target appeared during staging: {child_store.path}")
            try:
                self._record("reentry", record, dependencies=dependencies, derived=True)
                os.replace(staging_path, child_store.path)
            except BaseException:
                rollback_parent()
                raise
            return result
        finally:
            if staging_path.exists():
                shutil.rmtree(staging_path)
