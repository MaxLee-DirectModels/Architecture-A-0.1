"""Architecture+ 0.1 command-line interface."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .canonical import MAX_INPUT_BYTES, MAX_STRING_CHARS, MAX_TOTAL_NODES, digest_json, load_strict, loads_strict
from .field import activate
from .package import freeze, verify
from .passage import assess
from .prompts import PHASE_REQUIREMENTS, render_prompt
from .records import KINDS, RecordError
from .store import RunStore


def packet_root() -> Path:
    return Path(__file__).resolve().parents[2]


def emit(value: Any, output: str | None = None) -> None:
    if isinstance(value, str):
        text = value
    else:
        text = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    if output:
        Path(output).write_text(text, encoding="utf-8", newline="\n")
    else:
        sys.stdout.write(text)


def read_payload(path: Path, kind: str) -> Any:
    if path.stat().st_size > MAX_INPUT_BYTES:
        raise RecordError(f"artifact input exceeds {MAX_INPUT_BYTES} bytes")
    text = path.read_text(encoding="utf-8")
    if kind in {"candidate", "note", "external_evidence"}:
        try:
            return loads_strict(text)
        except (json.JSONDecodeError, ValueError):
            if not text.strip():
                raise RecordError(f"{kind} input must not be empty")
            return text.rstrip()
    return loads_strict(text)


def command_init(args: argparse.Namespace) -> int:
    spec = load_strict(Path(args.spec))
    event = RunStore(Path(args.run)).create(spec)
    emit({"status": "PASS", "run": str(Path(args.run).resolve()), "event": event}, args.output)
    return 0


def command_prompt(args: argparse.Namespace) -> int:
    root = packet_root()
    store = RunStore(Path(args.run))
    artifacts = store.latest_artifacts()
    prompt = render_prompt(root, args.phase, store.run_spec(), artifacts)
    emit(prompt, args.output)
    return 0


def command_record(args: argparse.Namespace) -> int:
    store = RunStore(Path(args.run))
    payload = read_payload(Path(args.input), args.kind)
    event = store.record(args.kind, payload, dependencies=args.depends or [])
    emit({"status": "PASS", "event": event}, args.output)
    return 0


def command_activate(args: argparse.Namespace) -> int:
    limit = args.limit
    if args.context in {"hinge", "return"}:
        if not args.run:
            raise RecordError(f"active {args.context} retrieval requires --run")
        store = RunStore(Path(args.run))
        artifacts = store.latest_artifacts()
        required = "hinge_set" if args.context == "hinge" else "return_envelope"
        if required not in artifacts:
            raise RecordError(f"active {args.context} retrieval requires recorded {required}")
        if args.context == "hinge":
            contexts = {
                item["hinge_id"]: set(item["affected_fields"])
                for item in artifacts["hinge_set"].get("hinges", [])
            }
            if args.context_ref not in contexts:
                raise RecordError("active hinge retrieval requires context_ref to name a current Hinge")
            if args.predicted_changed_field not in contexts[args.context_ref]:
                raise RecordError("predicted_changed_field is not affected by the named Hinge")
        else:
            fields = {item["field_id"] for item in artifacts["return_envelope"].get("components", [])}
            if args.context_ref not in fields:
                raise RecordError("active return retrieval requires context_ref to name a current Return field")
            if args.predicted_changed_field != args.context_ref:
                raise RecordError("return activation must bind predicted_changed_field to context_ref")
        limit = min(limit, store.run_spec().get("budget", {}).get("max_field_terms", limit))
    result = activate(
        packet_root(), args.query, limit=limit, operator_limit=args.operator_limit,
        context=args.context, context_ref=args.context_ref,
        predicted_changed_field=args.predicted_changed_field,
        cost=args.cost, falsifier=args.falsifier,
    )
    result["activation_fingerprint"] = "sha256:" + digest_json(result)
    emit(result, args.output)
    return 0


def command_audit(args: argparse.Namespace) -> int:
    result = RunStore(Path(args.run)).audit()
    emit(result, args.output)
    return 0 if result["status"] == "PASS" else 1


def command_reopen(args: argparse.Namespace) -> int:
    result = RunStore(Path(args.run)).reopen(args.changed)
    emit(result, args.output)
    return 0


def command_create_child(args: argparse.Namespace) -> int:
    child_spec = load_strict(Path(args.child_spec))
    result = RunStore(Path(args.run)).create_child(
        args.changed,
        Path(args.child),
        child_spec=child_spec,
    )
    emit(result, args.output)
    return 0


def command_passage(args: argparse.Namespace) -> int:
    if args.run:
        event = RunStore(Path(args.run)).assess_passage(state=args.state, successor=args.successor)
        result = {"status": "PASS", "event": event}
    else:
        model = load_strict(Path(args.model))
        result = assess(model, args.state, args.successor)
    emit(result, args.output)
    return 0


def command_seal(args: argparse.Namespace) -> int:
    event = RunStore(Path(args.run)).seal(
        represented_operations=args.represent_operation or [],
        open_obligations=args.open_obligation or [],
    )
    emit({"status": "PASS", "event": event}, args.output)
    return 0


def command_inspect(args: argparse.Namespace) -> int:
    specification = load_strict(packet_root() / "spec" / "system.json")
    release = specification["release"]
    release_version = ".".join(release["version"].split(".")[:2])
    result = {
        "release": f"{release['name']} {release_version}",
        "implementation": "Consequence Compiler 0.1",
        "normative_authority": "spec/system.json",
        "descriptor": release["descriptor"],
        "defining_line": release["defining_line"],
        "lower_interface": "Passage Theory supplies conditional predictions through domain-local Passage Models. Architecture+ organizes declared actors' work within their authority.",
        "operating_cycle": [step[0] for step in specification["operating_core"]["outer_sequence"]],
        "adaptive_loop": specification["operating_core"]["adaptive_loop"],
        "formation_firewall": "The default NATIVE formation mode is implemented by the CLI phase alias 'free'. The runtime fingerprints a prompt projection containing only the raw request, explicitly exposed Basis, unavoidable policy IDs, declared tools, and requested form. It cannot prove that an external host exposed no other context unless the full effective invocation is controlled and attested; otherwise that question remains OPEN.",
        "phase_requirements": PHASE_REQUIREMENTS,
        "artifact_kinds": sorted(KINDS),
        "outcomes": ["EARNED", "REJECTED", "OPEN"],
        "finite_input_limits": {
            "max_input_bytes": MAX_INPUT_BYTES,
            "max_string_chars": MAX_STRING_CHARS,
            "max_total_json_nodes": MAX_TOTAL_NODES,
            "max_nesting_depth": 40,
            "max_container_members": 10000,
        },
        "nonclaims": ["objective truth", "open-world completeness", "authority", "permission", "legitimacy", "causation", "world occurrence", "durability", "comparative external value"],
    }
    emit(result, args.output)
    return 0


def command_freeze(args: argparse.Namespace) -> int:
    result = freeze(packet_root())
    emit(result, args.output)
    return 0


def command_verify(args: argparse.Namespace) -> int:
    result = verify(packet_root())
    emit(result, args.output)
    return 0 if result["status"] == "PASS" else 1


def command_demo(args: argparse.Namespace) -> int:
    root = packet_root()
    destination = Path(args.output).resolve()
    if destination.exists():
        if any(destination.iterdir()):
            raise RecordError(f"demo output is not empty: {destination}")
    else:
        destination.mkdir(parents=True)
    store = RunStore(destination)
    spec = load_strict(root / "examples" / "mine" / "run_spec.json")
    store.create(spec)
    ids: dict[str, str] = {}
    sequence = [
        ("candidate", root / "examples" / "mine" / "candidate.txt", ["B-MINE"]),
        ("backward_sweep", root / "examples" / "mine" / "backward.json", []),
        ("forward_sweep", root / "examples" / "mine" / "forward.json", []),
        ("hinge_set", root / "examples" / "mine" / "hinges.json", []),
        ("passage_model", root / "examples" / "mine" / "passage_model.json", ["B-MINE"]),
        ("trial", root / "examples" / "mine" / "trials.json", []),
        ("binding_set", root / "examples" / "mine" / "bindings.json", []),
    ]
    for kind, path, fixed_dependencies in sequence:
        payload = read_payload(path, kind)
        dependencies = list(fixed_dependencies)
        if kind in {"backward_sweep", "forward_sweep"}:
            dependencies.append(ids["candidate"])
        elif kind == "hinge_set":
            dependencies.extend(ids[key] for key in ("candidate", "backward_sweep", "forward_sweep"))
        elif kind == "binding_set":
            dependencies.extend(ids[key] for key in ("hinge_set", "trial"))
        if kind == "trial":
            assessment = store.assess_passage(state="C-ACCESSIBLE", successor="C-COLLAPSED")
            ids["passage_assessment"] = assessment["artifact_id"]
            dependencies = [ids[key] for key in ("hinge_set", "passage_assessment")]
        event = store.record(kind, payload, dependencies=dependencies)
        ids[kind] = event["artifact_id"]
    seal_event = store.seal(represented_operations=[], open_obligations=["No physical action is permitted by this illustrative Seal."])
    ids["seal"] = seal_event["artifact_id"]
    return_event = store.record(
        "return_envelope",
        read_payload(root / "examples" / "mine" / "return.json", "return_envelope"),
        dependencies=[ids[key] for key in ("candidate", "hinge_set", "trial", "binding_set", "seal")] + ["B-MINE", "B-INSPECTION"],
    )
    ids["return_envelope"] = return_event["artifact_id"]
    outcome_event = store.record(
        "outcome_receipt",
        read_payload(root / "examples" / "mine" / "outcome.json", "outcome_receipt"),
        dependencies=[ids["return_envelope"], "B-INSPECTION"],
    )
    ids["outcome_receipt"] = outcome_event["artifact_id"]
    result = store.audit()
    result["run"] = str(destination)
    emit(result)
    return 0 if result["status"] == "PASS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="architecture-plus", description="Architecture+ 0.1 executable reference")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="initialize and freeze a RunSpec")
    init.add_argument("--spec", required=True)
    init.add_argument("--run", required=True)
    init.add_argument("--output")
    init.set_defaults(function=command_init)

    prompt = sub.add_parser("prompt", help="render a phase prompt under its information boundary")
    prompt.add_argument("--run", required=True)
    prompt.add_argument("--phase", choices=sorted(PHASE_REQUIREMENTS), required=True)
    prompt.add_argument("--output")
    prompt.set_defaults(function=command_prompt)

    record = sub.add_parser("record", help="append an artifact to the run")
    record.add_argument("--run", required=True)
    record.add_argument("--kind", choices=sorted(KINDS), required=True)
    record.add_argument("--input", required=True)
    record.add_argument("--depends", action="append", default=[])
    record.add_argument("--output")
    record.set_defaults(function=command_record)

    activation = sub.add_parser("activate", help="retrieve a small nonnormative field slice")
    activation.add_argument("--query", required=True)
    activation.add_argument("--limit", type=int, default=12)
    activation.add_argument("--operator-limit", type=int, default=4)
    activation.add_argument("--context", choices=["exploration", "hinge", "return"], default="exploration")
    activation.add_argument("--run")
    activation.add_argument("--context-ref")
    activation.add_argument("--predicted-changed-field")
    activation.add_argument("--cost")
    activation.add_argument("--falsifier")
    activation.add_argument("--output")
    activation.set_defaults(function=command_activate)

    audit = sub.add_parser("audit", help="verify a run and its hash chain")
    audit.add_argument("--run", required=True)
    audit.add_argument("--output")
    audit.set_defaults(function=command_audit)

    reopen = sub.add_parser("reopen", help="locate fields affected by changed dependencies")
    reopen.add_argument("--run", required=True)
    reopen.add_argument("--changed", action="append", required=True)
    reopen.add_argument("--output")
    reopen.set_defaults(function=command_reopen)

    child = sub.add_parser("create-child", help="create a child reassessment from a complete changed-material RunSpec")
    child.add_argument("--run", required=True)
    child.add_argument("--changed", action="append", required=True)
    child.add_argument("--child", required=True)
    child.add_argument("--child-spec", required=True)
    child.add_argument("--output")
    child.set_defaults(function=command_create_child)

    passage = sub.add_parser("passage", help="assess a supplied or current recorded finite Passage Model")
    passage_source = passage.add_mutually_exclusive_group(required=True)
    passage_source.add_argument("--model")
    passage_source.add_argument("--run")
    passage.add_argument("--state", required=True)
    passage.add_argument("--successor")
    passage.add_argument("--output")
    passage.set_defaults(function=command_passage)

    sealed = sub.add_parser("seal", help="derive and append a Seal over the current run prefix")
    sealed.add_argument("--run", required=True)
    sealed.add_argument("--represent-operation", action="append", default=[])
    sealed.add_argument("--open-obligation", action="append", default=[])
    sealed.add_argument("--output")
    sealed.set_defaults(function=command_seal)

    inspect = sub.add_parser("inspect", help="print the executable contract")
    inspect.add_argument("--output")
    inspect.set_defaults(function=command_inspect)

    frozen = sub.add_parser("freeze", help="write the packet content manifest")
    frozen.add_argument("--output")
    frozen.set_defaults(function=command_freeze)

    verified = sub.add_parser("verify", help="verify packet structure and manifest")
    verified.add_argument("--output")
    verified.set_defaults(function=command_verify)

    demo = sub.add_parser("demo", help="construct and audit the mine example")
    demo.add_argument("--output", required=True)
    demo.set_defaults(function=command_demo)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.function(args))
    except (OSError, ValueError, RecordError) as exc:
        sys.stderr.write(f"ERROR: {exc}\n")
        return 2
