"""Phase prompts with enforced information boundaries."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .canonical import dumps_canonical
from .records import RecordError


PHASE_REQUIREMENTS: dict[str, tuple[str, ...]] = {
    "free": (),
    "backward": ("candidate",),
    "forward": ("candidate",),
    "hinge": ("candidate", "backward_sweep", "forward_sweep"),
    "trial": ("hinge_set",),
    "binding": ("hinge_set", "trial"),
    "return": ("candidate", "hinge_set", "trial", "binding_set", "seal"),
    "outcome": ("return_envelope",),
}

PROMPT_PLACEHOLDERS = (
    "request",
    "return_contract",
    "basis",
    "free_basis",
    "declared_tools",
    "requested_output_form",
    "unavoidable_policy_ids",
    "candidate",
    "backward_sweep",
    "forward_sweep",
    "hinge_set",
    "trial",
    "binding_set",
    "seal",
    "return_envelope",
    "external_evidence",
    "field_slice",
)
_ORIGINAL_PLACEHOLDER = re.compile(r"\{\{[^{}]*\}\}")
_KNOWN_PLACEHOLDER = re.compile(
    "|".join(re.escape("{{" + name + "}}") for name in PROMPT_PLACEHOLDERS)
)


def _pretty(value: Any) -> str:
    if value is None:
        return "(none)"
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)


def _visible_basis(run_spec: dict[str, Any], *, free: bool) -> list[dict[str, Any]]:
    basis = run_spec.get("basis", [])
    if not free:
        return basis
    return [item for item in basis if item.get("expose_to_free", False)]


def _substitute_original_template(template: str, replacements: dict[str, str]) -> str:
    original_tokens = _ORIGINAL_PLACEHOLDER.findall(template)
    unknown = sorted(set(original_tokens) - {"{{" + name + "}}" for name in PROMPT_PLACEHOLDERS})
    marker_remainder = _ORIGINAL_PLACEHOLDER.sub("", template)
    if unknown or "{{" in marker_remainder or "}}" in marker_remainder:
        unresolved = unknown or ["malformed placeholder marker"]
        raise RecordError(f"unresolved original prompt placeholders: {unresolved}")
    return _KNOWN_PLACEHOLDER.sub(
        lambda match: replacements[match.group(0)[2:-2]],
        template,
    )


def render_prompt(
    root: Path,
    phase: str,
    run_spec: dict[str, Any],
    artifacts: dict[str, Any],
) -> str:
    if phase not in PHASE_REQUIREMENTS:
        raise RecordError(f"unknown phase: {phase}")
    missing = [kind for kind in PHASE_REQUIREMENTS[phase] if kind not in artifacts]
    if missing:
        raise RecordError(f"phase {phase} requires: {', '.join(missing)}")

    template_name = "guided.txt" if phase == "free" and run_spec.get("formation_mode") == "GUIDED" else f"{phase}.txt"
    template_path = root / "prompts" / template_name
    if not template_path.exists():
        raise RecordError(f"missing prompt template: {template_path}")
    template = template_path.read_text(encoding="utf-8")
    replacements = {
        "request": run_spec["request"],
        "return_contract": _pretty(run_spec["return_contract"]),
        "basis": _pretty(_visible_basis(run_spec, free=False)),
        "free_basis": _pretty(_visible_basis(run_spec, free=True)),
        "declared_tools": _pretty(run_spec.get("allowed_tools", [])),
        "requested_output_form": run_spec.get("requested_output_form", "best form for the request"),
        "unavoidable_policy_ids": _pretty(run_spec.get("unavoidable_policy_ids", [])),
        "candidate": _pretty(artifacts.get("candidate")),
        "backward_sweep": _pretty(artifacts.get("backward_sweep")),
        "forward_sweep": _pretty(artifacts.get("forward_sweep")),
        "hinge_set": _pretty(artifacts.get("hinge_set")),
        "trial": _pretty(artifacts.get("trial")),
        "binding_set": _pretty(artifacts.get("binding_set")),
        "seal": _pretty(artifacts.get("seal")),
        "return_envelope": _pretty(artifacts.get("return_envelope")),
        "external_evidence": _pretty(artifacts.get("external_evidence")),
        "field_slice": "(none; bound reserve activation is a separate fingerprinted operation)",
    }
    rendered = _substitute_original_template(template, replacements)
    max_chars = run_spec.get("budget", {}).get("max_prompt_chars", 120000)
    if len(rendered) > max_chars:
        raise RecordError(f"prompt size {len(rendered)} exceeds max_prompt_chars {max_chars}")
    return rendered.rstrip() + "\n"


def firewall_projection(run_spec: dict[str, Any]) -> str:
    """Canonical fingerprint input for what the FREE phase is allowed to see."""
    visible = _visible_basis(run_spec, free=False) if run_spec.get("formation_mode") == "GUIDED" else _visible_basis(run_spec, free=True)
    projection = {
        "request": run_spec["request"],
        "basis": visible,
        "formation_mode": run_spec.get("formation_mode", "NATIVE"),
        "unavoidable_policy_ids": run_spec.get("unavoidable_policy_ids", []),
        "declared_tools": run_spec.get("allowed_tools", []),
        "requested_output_form": run_spec.get("requested_output_form", "best form for the request"),
    }
    return dumps_canonical(projection)
