"""Finite Passage Model assessment; the model remains a domain-local input."""

from __future__ import annotations

from typing import Any

from .records import RecordError, validate_passage_model


def _field(model: dict[str, Any], state: str) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = {"possible": [], "impossible": [], "open": []}
    key = {
        "QUALIFIED": "possible",
        "DISQUALIFIED": "impossible",
        "OPEN": "open",
        "NOT_APPLICABLE": "impossible",
    }
    for passage in model["passages"]:
        if passage["source"] != state:
            continue
        groups[key[passage["qualification"]]].append({
            "passage_id": passage["id"],
            "target": passage["target"],
            "conditions": passage.get("conditions", []),
            "bottlenecks": passage.get("bottlenecks", []),
            "resource_roles": passage.get("resource_roles", []),
            "transformation": passage.get("transformation"),
            "consequences": passage.get("consequences", []),
            "basis_refs": passage.get("basis_refs", []),
        })
    for values in groups.values():
        values.sort(key=lambda item: item["passage_id"])
    return groups


def assess(model: dict[str, Any], state: str, successor: str | None = None) -> dict[str, Any]:
    validate_passage_model(model)
    state_ids = {configuration["id"] for configuration in model["configurations"]}
    if state not in state_ids:
        raise RecordError(f"unknown configuration: {state}")
    if successor is not None and successor not in state_ids:
        raise RecordError(f"unknown successor configuration: {successor}")
    before = _field(model, state)
    response: dict[str, Any] = {
        "kind": "PassageAssessment",
        "model_id": model["model_id"],
        "configuration": state,
        "regard": model["regard"],
        "horizon": model["horizon"],
        "field": before,
        "exact_unknowns": model.get("uncertainty", []),
        "boundary": "This is a deterministic reading of a supplied finite Passage Model. Qualification is declared by that model; no world fact, permission, value, authority, or decision is independently established.",
    }
    if successor is not None:
        after = _field(model, successor)
        response["successor"] = successor
        response["successor_field"] = after
        relation = model.get("comparison_relation")
        if not relation:
            response["outcome"] = "OPEN"
            response["domain_disposition"] = "INCOMPARABLE"
            response["comparison_ceiling"] = "No cross-configuration Passage comparison is earned without relation K."
            response["successor_signature"] = {
                "opened": "OPEN",
                "closed": "OPEN",
                "preserved": "OPEN",
                "redirected": "OPEN",
                "reason": "No complete PASSAGE_IDENTITY relation K was supplied across configurations; explicit correspondence remains OPEN in 0.1.",
            }
            return response
        declared_domain = relation.get("domain", [])
        before_ids = {item["passage_id"] for item in before["possible"]}
        after_ids = {item["passage_id"] for item in after["possible"]}
        required_domain = before_ids | after_ids
        missing_identity = sorted(required_domain - set(declared_domain))
        if missing_identity:
            response["outcome"] = "OPEN"
            response["domain_disposition"] = "INCOMPARABLE"
            response["comparison_ceiling"] = "Relation K is incomplete for the compared qualified Passage IDs."
            response["comparison_relation"] = relation
            response["successor_signature"] = {
                "opened": "OPEN",
                "closed": "OPEN",
                "preserved": "OPEN",
                "redirected": "OPEN",
                "reason": f"PASSAGE_IDENTITY relation K omits compared passage IDs: {', '.join(missing_identity)}.",
            }
            return response
        response["outcome"] = "EARNED"
        response["domain_disposition"] = "POSITIVE"
        response["comparison_ceiling"] = (
            "Exact passage_id equality within the supplied model and declared PASSAGE_IDENTITY relation K only. "
            "The 0.1 record shape gives each Passage ID one source configuration, so nonempty preservation or redirection "
            "requires a future explicit correspondence relation."
        )
        response["comparison_relation"] = relation
        response["successor_signature"] = {
            "opened": sorted(after_ids - before_ids),
            "closed": sorted(before_ids - after_ids),
            "preserved": sorted(before_ids & after_ids),
            "redirected": "OPEN; redirection requires an implemented explicit correspondence relation",
            "capacity": "OPEN unless declared in the model",
            "burden_and_residue": "see passage consequences and domain evidence",
            "passage_producing_capacity": "OPEN unless independently modeled",
        }
    return response
