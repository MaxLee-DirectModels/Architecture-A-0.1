#!/usr/bin/env python3
"""Audit Architecture+ 0.1 release-obligation coverage without enlarging it."""

from __future__ import annotations

import ast
import hashlib
import json
import re
import sys
import zipfile
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[1]
MODES = {"executable_enforcement", "structural_projection", "open_nonclaim"}
OPEN_PATTERNS = (
    re.compile(r"\barchitecture\+[^\n]{0,80}\bfull coverage\b", re.I),
    re.compile(r"\b(?:claims?|guarantees?)\s+(?:complete|universal) coverage\b", re.I),
    re.compile(r"\bfully covered\b", re.I),
    re.compile(r"\b100% covered\b", re.I),
)


def strict_object_pairs(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate JSON member: {key}")
        out[key] = value
    return out


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=strict_object_pairs)


def pointer(value, path: str):
    if not path.startswith("/") and path != "":
        raise ValueError(f"invalid JSON pointer: {path}")
    node = value
    for raw in path.split("/")[1:]:
        token = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(node, list):
            node = node[int(token)]
        else:
            node = node[token]
    return node


def source_ids(root: Path, source: dict) -> list[str]:
    data = load_json(root / source["file"])
    node = pointer(data, source["pointer"])
    kind = source["kind"]
    if kind == "ids":
        field = source.get("field", "id")
        if isinstance(field, str) and field.isdigit():
            field = int(field)
        return [str(row[field]) for row in node]
    if kind == "keys":
        return list(node)
    if kind == "indexes":
        prefix = source["prefix"]
        width = int(source.get("width", 2))
        return [f"{prefix}{index:0{width}d}" for index in range(1, len(node) + 1)]
    raise ValueError(f"unknown source kind: {kind}")


def source_fragments(root: Path, source: dict) -> list[tuple[str, object, str]]:
    data = load_json(root / source["file"])
    node = pointer(data, source["pointer"])
    ids = source_ids(root, source)
    kind = source["kind"]
    if kind == "keys":
        values = [node[item] for item in ids]
    elif kind == "ids":
        values = list(node)
    elif kind == "indexes":
        values = list(node)
    else:
        raise ValueError(f"unknown source kind: {kind}")
    return [
        (item, value, hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest())
        for item, value in zip(ids, values)
    ]


def docx_text(path: Path) -> str:
    namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    with zipfile.ZipFile(path) as archive:
        root = ElementTree.fromstring(archive.read("word/document.xml"))
    return "\n".join(
        "".join(item.text or "" for item in paragraph.findall(".//w:t", namespace))
        for paragraph in root.findall(".//w:p", namespace)
    )


def projection_text(root: Path, spec: dict) -> tuple[str, list[str]]:
    failures = []
    parts = []
    for pattern in spec.get("files", []):
        matches = sorted(root.glob(pattern))
        if not matches:
            failures.append(f"projection {spec['id']} has no files for {pattern}")
        for path in matches:
            if path.suffix.lower() == ".docx":
                parts.append(docx_text(path))
            else:
                parts.append(path.read_text(encoding="utf-8"))
    return "\n".join(parts), failures


def discovered_tests(root: Path) -> set[str]:
    tests = set()
    for path in sorted((root / "tests").glob("test_*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                for child in node.body:
                    if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child.name.startswith("test_"):
                        tests.add(f"{path.stem}.{node.name}.{child.name}")
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
                tests.add(f"{path.stem}.{node.name}")
    return tests


def main() -> int:
    failures: list[str] = []
    coverage_path = ROOT / "qualification" / "coverage.json"
    coverage = load_json(coverage_path)
    system = load_json(ROOT / "spec" / "system.json")

    if coverage.get("schema_version") != "architecture-plus.coverage/0.1":
        failures.append("wrong coverage schema version")
    if coverage.get("authority") != "DERIVED_QUALIFICATION_INDEX":
        failures.append("coverage index must be derived and nonnormative")

    projections = {}
    for item in coverage.get("carrier_projections", []):
        pid = item.get("id")
        if not isinstance(pid, str) or pid in projections:
            failures.append(f"duplicate or invalid projection id: {pid!r}")
            continue
        text, local_failures = projection_text(ROOT, item)
        failures.extend(local_failures)
        for term in item.get("must_contain", []):
            if term not in text:
                failures.append(f"projection {pid} omits {term!r}")
        for term in item.get("must_not_contain", []):
            if term in text:
                failures.append(f"projection {pid} contains forbidden {term!r}")
        projections[pid] = item

    sets = {}
    global_items: dict[str, str] = {}
    covered_test_ids = set()
    source_jobs = []
    mode_counts = Counter()
    for item_set in coverage.get("sets", []):
        sid = item_set.get("id")
        if not isinstance(sid, str) or sid in sets:
            failures.append(f"duplicate or invalid set id: {sid!r}")
            continue
        sets[sid] = item_set
        try:
            fragments = source_fragments(ROOT, item_set["source"])
            actual = [item for item, _, _ in fragments]
        except (OSError, ValueError, KeyError, IndexError, TypeError) as exc:
            failures.append(f"set {sid} source failure: {exc}")
            continue
        declared = item_set.get("items", [])
        if actual != declared:
            failures.append(f"set {sid} source drift: expected {actual!r}, declared {declared!r}")
        source_job = (item_set["source"]["file"], item_set["source"]["pointer"])
        source_jobs.append(source_job)
        for oid in declared:
            qualified = f"{sid}/{oid}"
            if qualified in global_items:
                failures.append(f"duplicate obligation id {qualified}")
            global_items[qualified] = sid
        hashes = item_set.get("fragment_hashes")
        actual_hashes = {item: digest for item, _, digest in fragments}
        if hashes != actual_hashes:
            failures.append(f"set {sid} canonical fragment hashes drift")

        assigned = {}
        for mode, block in item_set.get("modes", {}).items():
            if mode not in MODES:
                failures.append(f"set {sid} has unknown mode {mode}")
                continue
            block_items = block.get("items", [])
            for oid in block_items:
                if oid in assigned:
                    failures.append(f"set {sid} item {oid} has two modes")
                assigned[oid] = mode
                mode_counts[mode] += 1
            refs = block.get("projections", [])
            for ref in refs:
                if ref not in projections:
                    failures.append(f"set {sid} references missing projection {ref}")
            if mode == "executable_enforcement":
                tests = block.get("tests", [])
                if block_items and not tests:
                    failures.append(f"set {sid} executable items lack exact tests")
                covered_test_ids.update(tests)
            elif mode == "structural_projection":
                if block_items and not refs:
                    failures.append(f"set {sid} structural items lack a projection check")
            elif mode == "open_nonclaim":
                if block_items and (not block.get("nonclaim") or not block.get("reentry")):
                    failures.append(f"set {sid} OPEN items lack nonclaim or reentry")
        if set(assigned) != set(declared):
            missing = sorted(set(declared) - set(assigned))
            extra = sorted(set(assigned) - set(declared))
            failures.append(f"set {sid} mode partition drift; missing={missing}, extra={extra}")

    duplicates = [job for job, count in Counter(source_jobs).items() if count > 1]
    for file_name, path in duplicates:
        failures.append(f"duplicate semantic source job: {file_name}#{path}")

    accounting = coverage.get("top_level_accounting", {})
    if set(accounting) != set(system):
        failures.append(
            "top-level canonical accounting drift; "
            f"missing={sorted(set(system) - set(accounting))}, extra={sorted(set(accounting) - set(system))}"
        )
    valid_accounts = set(sets) | set(projections)
    for key, references in accounting.items():
        if not isinstance(references, list) or not references:
            failures.append(f"top-level key {key} lacks accounting references")
        elif unknown := sorted(set(references) - valid_accounts):
            failures.append(f"top-level key {key} has missing accounting refs: {unknown}")

    found_tests = discovered_tests(ROOT)
    test_accounting = coverage.get("test_accounting", {})
    if set(test_accounting) != found_tests:
        failures.append(
            "test accounting drift; "
            f"orphan={sorted(found_tests - set(test_accounting))}, missing={sorted(set(test_accounting) - found_tests)}"
        )
    for test_id, refs in test_accounting.items():
        if not isinstance(refs, list) or not refs:
            failures.append(f"test {test_id} has no obligation references")
        elif unknown := sorted(set(refs) - set(global_items)):
            failures.append(f"test {test_id} has unknown obligation refs: {unknown}")
    for item_set in coverage.get("sets", []):
        sid = item_set.get("id")
        block = item_set.get("modes", {}).get("executable_enforcement")
        if not block:
            continue
        for oid in block.get("items", []):
            qualified = f"{sid}/{oid}"
            named_tests = set(block.get("tests", []))
            direct = [test_id for test_id in named_tests if qualified in test_accounting.get(test_id, [])]
            if not direct:
                failures.append(f"executable obligation {qualified} lacks an item-specific accounted test")
    unknown_tests = sorted(covered_test_ids - found_tests)
    if unknown_tests:
        failures.append(f"executable mappings name missing tests: {unknown_tests}")
    unlinked_exec = sorted(covered_test_ids - set(test_accounting))
    if unlinked_exec:
        failures.append(f"executable tests lack accounting: {unlinked_exec}")

    # Sole-source projections must stay byte-for-value equal.
    theory = load_json(ROOT / "theory" / "passage.json")
    for key in ("passage_theory", "passage_model_contract", "resource_account", "successor_signature"):
        if theory.get(key) != system.get(key):
            failures.append(f"theory projection drift: {key}")
    evidence = load_json(ROOT / "qualification" / "evidence.json")
    if evidence != system.get("qualification"):
        failures.append("qualification evidence projection drift")

    # Count every explicit canonical claim surface; silent additions fail top-level accounting.
    required_claim_sets = {
        "BOUNDARY", "EVIDENCE", "FRONTIERS", "REFERENCE_IMPLEMENTED",
        "REFERENCE_OPEN", "ADAPTER", "GOLDEN_FIXTURES",
    }
    missing_claim_sets = sorted(required_claim_sets - set(sets))
    if missing_claim_sets:
        failures.append(f"missing claim-accounting sets: {missing_claim_sets}")

    scan_paths = [ROOT / "README.md", ROOT / "spec" / "system.json", ROOT / "theory" / "passage.json"]
    scan_paths.extend(sorted((ROOT / "prompts").glob("*.txt")))
    scan_paths.extend(sorted((ROOT / "runtime" / "architecture_plus").glob("*.py")))
    scan_text = "\n".join(path.read_text(encoding="utf-8") for path in scan_paths)
    for pattern in OPEN_PATTERNS:
        match = pattern.search(scan_text)
        if match:
            failures.append(f"unsupported coverage claim: {match.group(0)!r}")

    result = {
        "status": "PASS" if not failures else "FAIL",
        "obligations": len(global_items),
        "modes": dict(sorted(mode_counts.items())),
        "sets": len(sets),
        "carrier_projections": len(projections),
        "tests": len(found_tests),
        "failures": failures,
        "boundary": (
            "PASS means every declared 0.1 release obligation has one exact disposition, every executable "
            "disposition names present tests, every structural disposition has a checked carrier, and every "
            "unimplemented claim is bounded with reentry. It does not establish truth, empirical adequacy, "
            "external value, authority, safety, world effect, or open-world completeness."
        ),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
