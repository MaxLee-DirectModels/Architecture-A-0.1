#!/usr/bin/env python3
"""Finite cross-carrier and anti-bloat audit for Architecture+ 0.1."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load(path: Path):
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def audit_builder_authority(failures: list[str]) -> None:
    """Execute a copied projector and prove that its canonical input was not written."""
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary) / "packet"
        for relative in (
            "tools/build_spec.py",
            "spec/system.json",
            "qualification/golden_fixtures.json",
        ):
            source = ROOT / relative
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        spec_path = root / "spec" / "system.json"
        before_bytes = spec_path.read_bytes()
        before_stat = spec_path.stat()
        result = subprocess.run(
            [sys.executable, str(root / "tools" / "build_spec.py"), "--root", str(root)],
            cwd=root,
            text=True,
            capture_output=True,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stdout + result.stderr).strip().replace("\n", " ")
            failures.append(f"build_spec projection guard failed: {detail}")
            return
        if not spec_path.is_file():
            failures.append("build_spec authority violation: projector removed spec/system.json")
            return
        after_bytes = spec_path.read_bytes()
        after_stat = spec_path.stat()
        if after_bytes != before_bytes or after_stat.st_ino != before_stat.st_ino or after_stat.st_mtime_ns != before_stat.st_mtime_ns:
            failures.append("build_spec authority violation: projector wrote spec/system.json")
        allowed_files = {
            "tools/build_spec.py",
            "spec/system.json",
            "qualification/golden_fixtures.json",
            "qualification/evidence.json",
            "theory/passage.json",
        }
        actual_files = {
            path.relative_to(root).as_posix()
            for path in root.rglob("*")
            if path.is_file()
        }
        unexpected = sorted(actual_files - allowed_files)
        if unexpected:
            failures.append(f"build_spec wrote unauthorized files: {', '.join(unexpected)}")


def main() -> int:
    failures: list[str] = []
    system = load(ROOT / "spec" / "system.json")
    passage = load(ROOT / "theory" / "passage.json")
    lexicon = load(ROOT / "reserve" / "lexicon.json")
    operators = load(ROOT / "reserve" / "operators.json")
    evidence = load(ROOT / "qualification" / "evidence.json")

    audit_builder_authority(failures)

    if system.get("schema_version") != "architecture-plus.system/0.1":
        failures.append("wrong system schema version")
    if system.get("normativity", {}).get("authority") != "spec/system.json":
        failures.append("system.json is not declared sole authority")
    required_topology = {"reference_profile", "adapter_contract"}
    if not required_topology.issubset(system):
        failures.append(f"missing canonical topology: {sorted(required_topology - set(system))}")
    if system.get("adapter_contract", {}).get("status_in_reference_runtime") != "NOT_INCLUDED":
        failures.append("reference runtime must not claim an execution adapter")
    if passage.get("passage_theory") != system.get("passage_theory"):
        failures.append("Passage Theory projection drift")
    if passage.get("passage_model_contract") != system.get("passage_model_contract"):
        failures.append("Passage Model projection drift")
    if passage.get("resource_account") != system.get("resource_account"):
        failures.append("Resource Account projection drift")
    if passage.get("successor_signature") != system.get("successor_signature"):
        failures.append("Successor Signature projection drift")
    if evidence != system.get("qualification"):
        failures.append("qualification evidence projection drift")

    constitution = system.get("constitution", [])
    ids = [row.get("id") for row in constitution]
    if len(ids) != 15 or len(set(ids)) != 15:
        failures.append("constitution must contain 15 unique laws")
    if len(system.get("records", [])) != 5:
        failures.append("core must contain exactly five persistent record types")
    if system.get("field_policy", {}).get("default") != "DORMANT":
        failures.append("term field must be dormant by default")

    package_readme = (ROOT / "README.md").read_text(encoding="utf-8")
    for name in ("Architecture+ Operating Core", "Consequence Compiler", "Earned Structure", "README+"):
        if name not in package_readme:
            failures.append(f"package README omits identity: {name}")

    terms = lexicon.get("terms", [])
    term_ids = [term.get("id") for term in terms]
    labels = [str(term.get("label", "")).casefold() for term in terms]
    if len(terms) != 762:
        failures.append(f"lexicon expected 762 terms, found {len(terms)}")
    if len(term_ids) != len(set(term_ids)):
        failures.append("duplicate lexicon IDs")
    if len(labels) != len(set(labels)):
        failures.append("duplicate case-folded lexicon labels")
    neighborhoods = {row["id"]: row for row in lexicon.get("neighborhoods", [])}
    counts = Counter(term.get("neighborhood") for term in terms)
    if set(counts) != set(neighborhoods):
        failures.append("term and neighborhood membership sets differ")
    for nid, row in neighborhoods.items():
        if counts[nid] != row.get("term_count"):
            failures.append(f"neighborhood count mismatch: {nid}")

    if operators.get("schema_version") != "architecture-plus.operators/0.1":
        failures.append("wrong operator-reserve schema version")
    if operators.get("authority") != "NONNORMATIVE_DORMANT_OPERATOR_RESERVE":
        failures.append("operator reserve must be dormant and nonnormative")
    operator_rows = operators.get("operators", [])
    operator_ids = [row.get("id") for row in operator_rows]
    operator_names = [str(row.get("name", "")).casefold() for row in operator_rows]
    if len(operator_rows) != 38:
        failures.append(f"operator reserve expected 38 cards, found {len(operator_rows)}")
    if len(operator_ids) != len(set(operator_ids)):
        failures.append("duplicate operator IDs")
    if len(operator_names) != len(set(operator_names)):
        failures.append("duplicate case-folded operator names")
    required_operator_fields = {
        "id",
        "name",
        "trigger",
        "requirements",
        "intervention",
        "expected_changed_fields",
        "falsifier",
        "cost",
        "contraindications",
        "scope",
        "evidence",
        "lease",
    }
    for row in operator_rows:
        missing = required_operator_fields - set(row)
        if missing:
            failures.append(f"operator {row.get('id')} missing fields: {sorted(missing)}")
        if not row.get("requirements") or not row.get("expected_changed_fields"):
            failures.append(f"operator {row.get('id')} has an empty activation contract")
        if not row.get("contraindications"):
            failures.append(f"operator {row.get('id')} has no contraindication")

    anomalies = []
    for number, line in enumerate((ROOT / "reserve" / "anomalies.jsonl").read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            anomalies.append(json.loads(line))
        except json.JSONDecodeError as exc:
            failures.append(f"anomaly line {number}: {exc}")
    anomaly_ids = [row.get("id") for row in anomalies]
    if len(anomaly_ids) != len(set(anomaly_ids)):
        failures.append("duplicate anomaly IDs")
    required_anomaly_signals = ["23981308", "602 pages", "fabricated experiment", "wrong machine"]
    anomaly_text = json.dumps(anomalies, ensure_ascii=False).casefold()
    for signal in required_anomaly_signals:
        if signal.casefold() not in anomaly_text:
            failures.append(f"missing anomaly signal: {signal}")

    result = {
        "status": "PASS" if not failures else "FAIL",
        "laws": len(constitution),
        "records": len(system.get("records", [])),
        "anti_collapse_families": len(system.get("anti_collapse", [])),
        "passage_laws": len(system.get("passage_theory", {}).get("laws", [])),
        "lexicon_terms": len(terms),
        "lexicon_neighborhoods": len(neighborhoods),
        "operator_cards": len(operator_rows),
        "anomalies": len(anomalies),
        "builder_authority_guard": "PASS" if not any("build_spec" in item for item in failures) else "FAIL",
        "failures": failures,
        "boundary": (
            "PASS establishes finite source/projection identity, uniqueness, declared counts, and required anomaly coverage. "
            "It does not establish semantic truth, external value, empirical validity, authority, or completeness."
        ),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
