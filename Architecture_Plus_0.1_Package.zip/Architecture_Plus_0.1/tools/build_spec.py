#!/usr/bin/env python3
"""Project nonauthoritative carriers from the sole normative system specification."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any


DEFAULT_ROOT = Path(__file__).resolve().parents[1]
THEORY_KEYS = (
    "passage_theory",
    "passage_model_contract",
    "resource_account",
    "successor_signature",
)
EXPECTED_GOLDEN_IDS = tuple(f"GF-{index:02d}" for index in range(1, 13))
GOLDEN_FIXTURE_FINGERPRINT = "8a1414419f1937c1216382becfe0901381a5f31394b9d4b6eb5d525a4ee30b8a"


class ProjectionError(ValueError):
    pass


def _strict_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ProjectionError(f"duplicate JSON member: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_strict_pairs)


def validate_system(system: Any) -> dict[str, Any]:
    if not isinstance(system, dict):
        raise ProjectionError("spec/system.json must contain an object")
    if system.get("schema_version") != "architecture-plus.system/0.1":
        raise ProjectionError("spec/system.json has the wrong schema_version")
    normativity = system.get("normativity")
    if not isinstance(normativity, dict) or normativity.get("authority") != "spec/system.json":
        raise ProjectionError("spec/system.json must declare itself the sole normative authority")
    missing = [key for key in (*THEORY_KEYS, "qualification") if key not in system]
    if missing:
        raise ProjectionError(f"spec/system.json lacks projection sources: {', '.join(missing)}")
    if not isinstance(system["qualification"], dict):
        raise ProjectionError("spec/system.json qualification must be an object")
    return system


def validate_golden_fixtures(value: Any) -> None:
    if not isinstance(value, dict) or set(value) != {"authority", "fixtures"}:
        raise ProjectionError("golden fixture file must contain exactly authority and fixtures")
    if value["authority"] != "DERIVED_TEST_PLAN":
        raise ProjectionError("golden fixture file has the wrong authority boundary")
    fixtures = value["fixtures"]
    if not isinstance(fixtures, list):
        raise ProjectionError("golden fixtures must be an array")
    ids: list[str] = []
    for index, fixture in enumerate(fixtures):
        if not isinstance(fixture, dict) or set(fixture) != {"id", "name", "expected_guard"}:
            raise ProjectionError(f"golden fixture {index} has an invalid shape")
        for field in ("id", "name", "expected_guard"):
            if not isinstance(fixture[field], str) or not fixture[field].strip():
                raise ProjectionError(f"golden fixture {index}.{field} must be a nonempty string")
        ids.append(fixture["id"])
    if tuple(ids) != EXPECTED_GOLDEN_IDS:
        raise ProjectionError("golden fixtures must be the ordered unique GF-01 through GF-12 set")
    fingerprint = hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    if fingerprint != GOLDEN_FIXTURE_FINGERPRINT:
        raise ProjectionError("golden fixture content fingerprint mismatch")


def projections(system: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    theory = {
        "projection_of": "spec/system.json#/passage_theory",
        "authority": "DERIVED_NONAUTHORITATIVE_PROJECTION",
        **{key: system[key] for key in THEORY_KEYS},
    }
    return theory, system["qualification"]


def _write_allowed(root: Path, relative: str, value: Any) -> None:
    allowed = {"theory/passage.json", "qualification/evidence.json"}
    if relative not in allowed:
        raise ProjectionError(f"refusing non-projection write: {relative}")
    target = root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(value, indent=2, ensure_ascii=False) + "\n"
    descriptor, temporary = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(rendered)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def run(root: Path, *, check: bool) -> dict[str, Any]:
    root = root.resolve()
    spec_path = root / "spec" / "system.json"
    spec_before = spec_path.read_bytes()
    system = validate_system(load_json(spec_path))
    validate_golden_fixtures(load_json(root / "qualification" / "golden_fixtures.json"))
    theory, evidence = projections(system)
    expected = {
        "theory/passage.json": theory,
        "qualification/evidence.json": evidence,
    }
    drift: list[str] = []
    for relative, value in expected.items():
        target = root / relative
        if check:
            try:
                if load_json(target) != value:
                    drift.append(relative)
            except (OSError, ValueError, json.JSONDecodeError):
                drift.append(relative)
        else:
            _write_allowed(root, relative, value)
    if spec_path.read_bytes() != spec_before:
        raise ProjectionError("authority violation: projection changed spec/system.json")
    return {
        "status": "PASS" if not drift else "FAIL",
        "authority": "spec/system.json",
        "mode": "CHECK" if check else "PROJECT",
        "projected": sorted(expected),
        "drift": sorted(drift),
        "golden_fixtures": "VALIDATED_STATIC",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--check", action="store_true", help="validate projections without writing them")
    args = parser.parse_args()
    try:
        result = run(args.root, check=args.check)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        result = {"status": "FAIL", "error": str(exc)}
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
