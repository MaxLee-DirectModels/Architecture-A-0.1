from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.prompts import PROMPT_PLACEHOLDERS, render_prompt
from architecture_plus.records import RecordError, SCHEMA_VERSION


def native_spec() -> dict:
    tokens = ["{{" + name + "}}" for name in PROMPT_PLACEHOLDERS]
    return {
        "schema_version": SCHEMA_VERSION,
        "kind": "RunSpec",
        "run_id": "prompt-substitution-test",
        "request": " ".join(f"REQUEST-{index}={token}" for index, token in enumerate(tokens)),
        "formation_mode": "NATIVE",
        "requested_output_form": "plain text",
        "unavoidable_policy_ids": [],
        "firewall_waivers": [],
        "return_contract": {
            "fields": [{"id": "answer", "description": "RETURN-CONTRACT-SECRET", "required": True, "risk_tier": "normal"}],
            "use": "test",
            "horizon": "current run",
            "protected": [],
            "standing": "test only",
        },
        "basis": [
            {
                "id": "B-PUBLIC",
                "kind": "fact",
                "content": " ".join(f"BASIS-{index}={token}" for index, token in enumerate(tokens)),
                "expose_to_free": True,
            },
            {
                "id": "B-HIDDEN",
                "kind": "reserve",
                "content": "HIDDEN-BASIS-SECRET " + " ".join(tokens),
                "expose_to_free": False,
            },
        ],
        "allowed_tools": [],
        "budget": {"max_moves": 1, "max_field_terms": 1, "max_prompt_chars": 100000},
    }


class PromptSubstitutionTests(unittest.TestCase):
    def test_native_request_placeholders_remain_literal_without_leaking_reserves(self) -> None:
        prompt = render_prompt(ROOT, "free", native_spec(), {})
        for index, name in enumerate(PROMPT_PLACEHOLDERS):
            token = "{{" + name + "}}"
            with self.subTest(name=name):
                self.assertIn(f"REQUEST-{index}={token}", prompt)
        self.assertNotIn("HIDDEN-BASIS-SECRET", prompt)
        self.assertNotIn("RETURN-CONTRACT-SECRET", prompt)

    def test_native_exposed_basis_placeholders_remain_literal_without_leaking_reserves(self) -> None:
        prompt = render_prompt(ROOT, "free", native_spec(), {})
        for index, name in enumerate(PROMPT_PLACEHOLDERS):
            token = "{{" + name + "}}"
            with self.subTest(name=name):
                self.assertIn(f"BASIS-{index}={token}", prompt)
        self.assertNotIn("HIDDEN-BASIS-SECRET", prompt)
        self.assertNotIn("RETURN-CONTRACT-SECRET", prompt)

    def test_unknown_original_template_placeholder_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "prompts").mkdir()
            template = (ROOT / "prompts" / "free.txt").read_text(encoding="utf-8")
            (root / "prompts" / "free.txt").write_text(template + "\n{{unknown_original}}\n", encoding="utf-8")
            with self.assertRaisesRegex(RecordError, "unresolved original prompt placeholders"):
                render_prompt(root, "free", native_spec(), {})


if __name__ == "__main__":
    unittest.main()
