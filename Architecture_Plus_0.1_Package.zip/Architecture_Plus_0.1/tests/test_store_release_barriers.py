from __future__ import annotations

import copy
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))
sys.path.insert(0, str(ROOT / "tests"))

from architecture_plus.canonical import digest_file, digest_json, dumps_canonical, load_strict
from architecture_plus.records import RecordError
from architecture_plus.store import RunStore
from test_architecture_plus import (
    child_run_spec,
    run_spec,
    valid_backward,
    valid_bindings,
    valid_forward,
    valid_hinges,
    valid_return,
    valid_trials,
)
from test_store_hardening import replace_refs


def rewrite_artifact(
    store: RunStore,
    artifact_id: str,
    *,
    payload: object | None = None,
    dependencies: list[str] | None = None,
) -> None:
    events = store.events()
    event_index = next(index for index, event in enumerate(events) if event["artifact_id"] == artifact_id)
    event = events[event_index]
    old_path = store.path / event["artifact_path"]
    wrapper = load_strict(old_path)
    if payload is not None:
        wrapper["payload"] = payload
        wrapper["payload_hash"] = digest_json(payload)
        event["payload_hash"] = wrapper["payload_hash"]
        relative = Path("artifacts") / f"{artifact_id}-{event['kind']}-{wrapper['payload_hash'][:12]}.json"
        event["artifact_path"] = relative.as_posix()
        target = store.path / relative
    else:
        target = old_path
    if dependencies is not None:
        wrapper["dependencies"] = sorted(set(dependencies))
        event["dependencies"] = sorted(set(dependencies))
    target.write_text(dumps_canonical(wrapper) + "\n", encoding="utf-8", newline="\n")
    event["artifact_hash"] = digest_file(target)
    prior = events[event_index - 1]["record_hash"]
    for current in events[event_index:]:
        current["prior_hash"] = prior
        current["record_hash"] = digest_json({key: value for key, value in current.items() if key != "record_hash"})
        prior = current["record_hash"]
    store.events_path.write_text(
        "\n".join(dumps_canonical(item) for item in events) + "\n",
        encoding="utf-8",
        newline="\n",
    )


class ReleaseBarrierHarness(unittest.TestCase):
    def make_store(self) -> RunStore:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        store = RunStore(Path(temporary.name) / "run")
        store.create(run_spec())
        return store

    def through_trial(self, store: RunStore):
        candidate = store.record("candidate", "P0")
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        hinge = store.record(
            "hinge_set",
            valid_hinges(),
            dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]],
        )
        trial = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        return candidate, backward, forward, hinge, trial

    def through_seal(self, store: RunStore, bindings: dict | None = None):
        candidate, backward, forward, hinge, trial = self.through_trial(store)
        binding = store.record(
            "binding_set",
            bindings or valid_bindings(),
            dependencies=[hinge["artifact_id"], trial["artifact_id"]],
        )
        seal = store.seal()
        return candidate, backward, forward, hinge, trial, binding, seal

    def through_return(self, store: RunStore, bindings: dict | None = None):
        candidate, backward, forward, hinge, trial, binding, seal = self.through_seal(store, bindings)
        returned = store.record(
            "return_envelope",
            valid_return(),
            dependencies=[
                candidate["artifact_id"],
                hinge["artifact_id"],
                trial["artifact_id"],
                binding["artifact_id"],
                seal["artifact_id"],
                "B-PUBLIC",
                "B-HIDDEN",
            ],
        )
        return candidate, backward, forward, hinge, trial, binding, seal, returned

    def model(self) -> dict:
        return replace_refs(
            load_strict(ROOT / "examples" / "mine" / "passage_model.json"),
            {"B-MINE": "B-PUBLIC", "B-INSPECTION": "B-HIDDEN"},
        )


class PhaseDependencyBarrierTests(ReleaseBarrierHarness):
    def test_phase_minimums_are_rejected_before_write(self) -> None:
        store = self.make_store()
        candidate = store.record("candidate", "P0")
        with self.assertRaisesRegex(RecordError, "omit latest required phase"):
            store.record("backward_sweep", valid_backward())
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        with self.assertRaisesRegex(RecordError, "omit latest required phase"):
            store.record("forward_sweep", valid_forward())
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        with self.assertRaisesRegex(RecordError, "omit latest required phase"):
            store.record("hinge_set", valid_hinges(), dependencies=[candidate["artifact_id"], backward["artifact_id"]])
        hinge = store.record(
            "hinge_set",
            valid_hinges(),
            dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]],
        )
        with self.assertRaisesRegex(RecordError, "omit latest required phase"):
            store.record("trial", valid_trials())
        trial = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        with self.assertRaisesRegex(RecordError, "omit latest required phase"):
            store.record("binding_set", valid_bindings(), dependencies=[hinge["artifact_id"]])
        self.assertIsNotNone(trial)

    def test_latest_phase_artifact_is_required_not_merely_any_prior_one(self) -> None:
        store = self.make_store()
        candidate = store.record("candidate", "P0")
        stale_backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        with self.assertRaisesRegex(RecordError, "omit latest required phase"):
            store.record(
                "hinge_set",
                valid_hinges(),
                dependencies=[candidate["artifact_id"], stale_backward["artifact_id"], forward["artifact_id"]],
            )

    def test_phase_minimums_are_recomputed_during_audit(self) -> None:
        builders = {
            "backward_sweep": lambda store: (
                lambda candidate: store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
            )(store.record("candidate", "P0")),
            "forward_sweep": lambda store: (
                lambda candidate: store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
            )(store.record("candidate", "P0")),
            "hinge_set": lambda store: self.through_trial(store)[3],
            "trial": lambda store: self.through_trial(store)[4],
            "binding_set": lambda store: self.through_seal(store)[5],
        }
        for kind, build in builders.items():
            with self.subTest(kind=kind):
                store = self.make_store()
                event = build(store)
                rewrite_artifact(store, event["artifact_id"], dependencies=[])
                result = store.audit()
                self.assertEqual(result["status"], "FAIL")
                self.assertTrue(any("latest required phase artifacts" in item for item in result["failures"]), result["failures"])


class BindingAndReturnBarrierTests(ReleaseBarrierHarness):
    def test_binding_set_covers_every_live_hinge_trial_and_affected_field(self) -> None:
        store = self.make_store()
        _, _, _, hinge, trial = self.through_trial(store)
        omitted = valid_bindings()
        omitted["bindings"] = omitted["bindings"][:1]
        with self.assertRaisesRegex(RecordError, "does not cover"):
            store.record("binding_set", omitted, dependencies=[hinge["artifact_id"], trial["artifact_id"]])
        wrong_field = valid_bindings()
        wrong_field["bindings"][0]["affected_fields"] = ["reentry"]
        with self.assertRaisesRegex(RecordError, "affected_fields omit"):
            store.record("binding_set", wrong_field, dependencies=[hinge["artifact_id"], trial["artifact_id"]])

    def test_retired_hinge_needs_no_binding_when_no_current_trial_uses_it(self) -> None:
        store = self.make_store()
        candidate = store.record("candidate", "P0")
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        hinges = valid_hinges()
        hinges["hinges"][1]["status"] = "RETIRED"
        hinge = store.record(
            "hinge_set",
            hinges,
            dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]],
        )
        trials = valid_trials()
        trials["trials"] = trials["trials"][:1]
        trial = store.record("trial", trials, dependencies=[hinge["artifact_id"]])
        bindings = valid_bindings()
        bindings["bindings"] = bindings["bindings"][:1]
        store.record("binding_set", bindings, dependencies=[hinge["artifact_id"], trial["artifact_id"]])
        self.assertIsNotNone(store.seal())

    def test_seal_refuses_a_stored_binding_omission(self) -> None:
        store = self.make_store()
        _, _, _, _, _, binding, _ = self.through_seal(store)
        incomplete = valid_bindings()
        incomplete["bindings"] = incomplete["bindings"][:1]
        rewrite_artifact(store, binding["artifact_id"], payload=incomplete)
        with self.assertRaisesRegex(RecordError, "Seal refuses incomplete BindingSet"):
            store.seal()
        audit = store.audit()
        self.assertEqual(audit["status"], "FAIL")
        self.assertTrue(any("does not cover" in item for item in audit["failures"]), audit["failures"])

    def test_return_binding_refs_must_cover_their_field(self) -> None:
        store = self.make_store()
        candidate, _, _, hinge, trial, binding, seal = self.through_seal(store)
        returned = valid_return()
        returned["components"][0]["binding_refs"] = ["BD-2"]
        returned["reverse_trace"]["answer"] = ["B-PUBLIC", "BD-2"]
        dependencies = [
            candidate["artifact_id"], hinge["artifact_id"], trial["artifact_id"],
            binding["artifact_id"], seal["artifact_id"], "B-PUBLIC", "B-HIDDEN",
        ]
        with self.assertRaisesRegex(RecordError, "do not cover the field"):
            store.record("return_envelope", returned, dependencies=dependencies)

    def test_earned_return_requires_supported_witnessed_covering_binding(self) -> None:
        bindings = valid_bindings()
        bindings["bindings"][0]["status"] = "OPEN"
        bindings["bindings"][0]["warrant"]["status"] = "OPEN"
        bindings["bindings"][0]["warrant"]["witness_refs"] = []
        store = self.make_store()
        candidate, _, _, hinge, trial, binding, seal = self.through_seal(store, bindings)
        dependencies = [
            candidate["artifact_id"], hinge["artifact_id"], trial["artifact_id"],
            binding["artifact_id"], seal["artifact_id"], "B-PUBLIC", "B-HIDDEN",
        ]
        with self.assertRaisesRegex(RecordError, "ADMITTED, SUPPORTED, witnessed"):
            store.record("return_envelope", valid_return(), dependencies=dependencies)


class DerivedAuditBarrierTests(ReleaseBarrierHarness):
    def test_passage_assessment_payload_is_exactly_recomputed_during_audit(self) -> None:
        store = self.make_store()
        store.record("passage_model", self.model(), dependencies=["B-PUBLIC", "B-HIDDEN"])
        assessment = store.assess_passage(state="C-ACCESSIBLE", successor="C-COLLAPSED")
        payload = store._read_wrapper(assessment)["payload"]
        payload["boundary"] = "tampered deterministic result"
        rewrite_artifact(store, assessment["artifact_id"], payload=payload)
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("deterministic recomputation" in item for item in result["failures"]), result["failures"])

    def test_passage_assessment_requires_one_passage_model_dependency_during_audit(self) -> None:
        store = self.make_store()
        model = store.record("passage_model", self.model(), dependencies=["B-PUBLIC", "B-HIDDEN"])
        assessment = store.assess_passage(state="C-ACCESSIBLE", successor="C-COLLAPSED")
        rewrite_artifact(
            store,
            assessment["artifact_id"],
            dependencies=[model["artifact_id"], "B-PUBLIC"],
        )
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("exactly one PassageModel" in item for item in result["failures"]), result["failures"])

    def test_current_seal_or_return_change_reopens_every_return_field(self) -> None:
        store = self.make_store()
        *_, seal, returned = self.through_return(store)
        for changed in (seal["artifact_id"], returned["artifact_id"]):
            with self.subTest(changed=changed):
                result = store.reopen([changed])
                self.assertEqual(result["affected_fields"], ["answer", "reentry"])
                self.assertEqual(result["unchanged_fields"], [])

    def test_same_logical_hinge_ids_with_changed_payload_stale_the_sealed_chain(self) -> None:
        store = self.make_store()
        candidate, backward, forward, _, _, _, _ = self.through_seal(store)
        changed_hinges = valid_hinges()
        changed_hinges["hinges"][0]["discriminator"] = "changed discriminator with the same logical Hinge ID"
        store.record(
            "hinge_set",
            changed_hinges,
            dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]],
        )
        with self.assertRaisesRegex(RecordError, "stale phase snapshot"):
            store.seal()
        audit = store.audit()
        self.assertEqual(audit["status"], "FAIL")
        self.assertTrue(any("current trial is stale" in item for item in audit["failures"]), audit["failures"])


class ReentryBarrierTests(ReleaseBarrierHarness):
    def make_reentry(self, *, two_returns: bool = False):
        store = self.make_store()
        candidate, _, _, hinge, trial, binding, _, first_return = self.through_return(store)
        current_return = first_return
        if two_returns:
            second_seal = store.seal()
            current_return = store.record(
                "return_envelope",
                valid_return(),
                dependencies=[
                    candidate["artifact_id"], hinge["artifact_id"], trial["artifact_id"],
                    binding["artifact_id"], second_seal["artifact_id"], "B-PUBLIC", "B-HIDDEN",
                ],
            )
        child = Path(tempfile.mkdtemp()) / "child"
        self.addCleanup(lambda: __import__("shutil").rmtree(child.parent, ignore_errors=True))
        supplied_spec = child_run_spec(store, ["H-1"], run_id="child-run")
        result = store.create_child(["H-1"], child, child_spec=supplied_spec)
        reentry_event = next(event for event in reversed(store.events()) if event["kind"] == "reentry")
        return store, result, reentry_event, first_return, current_return, supplied_spec

    def test_reentry_uses_latest_return_and_emits_an_empty_child_shell(self) -> None:
        store, result, reentry, first_return, current_return, supplied_spec = self.make_reentry(two_returns=True)
        self.assertEqual(reentry["dependencies"], [current_return["artifact_id"]])
        self.assertNotIn(first_return["artifact_id"], reentry["dependencies"])
        self.assertEqual(result["child_state"], "EMPTY_REASSESSMENT_SHELL")
        self.assertEqual(result["child_artifacts"], [])
        child = RunStore(Path(result["child_run"]))
        self.assertEqual(len(child.events()), 1)
        self.assertEqual(child.run_spec(), supplied_spec)
        self.assertEqual(result["reentry"]["child_run_spec"], supplied_spec)
        self.assertEqual(result["reentry"]["child_run_spec_hash"], digest_json(supplied_spec))
        self.assertEqual(store.audit()["status"], "PASS", store.audit()["failures"])

    def test_occupied_child_target_is_rejected_before_parent_append(self) -> None:
        store = self.make_store()
        self.through_return(store)
        before = store.events()
        occupied = Path(tempfile.mkdtemp())
        self.addCleanup(lambda: __import__("shutil").rmtree(occupied, ignore_errors=True))
        (occupied / "occupied.txt").write_text("occupied\n", encoding="utf-8")
        with self.assertRaisesRegex(RecordError, "child run target is not empty"):
            store.create_child(
                ["H-1"],
                occupied,
                child_spec=child_run_spec(store, ["H-1"], run_id="blocked-child"),
            )
        self.assertEqual(store.events(), before)

    def test_invalid_child_spec_is_rejected_before_parent_append(self) -> None:
        store = self.make_store()
        self.through_return(store)
        before = store.events()
        target = Path(tempfile.mkdtemp()) / "child"
        self.addCleanup(lambda: __import__("shutil").rmtree(target.parent, ignore_errors=True))
        same_id = child_run_spec(store, ["H-1"], run_id=store.run_spec()["run_id"])
        with self.assertRaisesRegex(RecordError, "run_id must be new"):
            store.create_child(["H-1"], target, child_spec=same_id)
        missing_material = child_run_spec(store, ["H-1"], run_id="child-missing-material")
        missing_material["lineage"]["reentry"]["changed_material"] = []
        with self.assertRaisesRegex(RecordError, "account for every"):
            store.create_child(["H-1"], target, child_spec=missing_material)
        self.assertEqual(store.events(), before)
        self.assertFalse(target.exists())

    def test_child_create_failure_leaves_parent_bytes_and_head_unchanged(self) -> None:
        store = self.make_store()
        self.through_return(store)
        target = Path(tempfile.mkdtemp()) / "child"
        self.addCleanup(lambda: __import__("shutil").rmtree(target.parent, ignore_errors=True))
        supplied_spec = child_run_spec(store, ["H-1"], run_id="child-create-failure")
        events_before = store.events_path.read_bytes()
        head_before = store.events()[-1]["record_hash"]
        artifacts_before = sorted(path.name for path in store.artifacts_path.iterdir())
        with mock.patch.object(RunStore, "create", side_effect=OSError("injected child create failure")):
            with self.assertRaisesRegex(OSError, "injected child create failure"):
                store.create_child(["H-1"], target, child_spec=supplied_spec)
        self.assertEqual(store.events_path.read_bytes(), events_before)
        self.assertEqual(store.events()[-1]["record_hash"], head_before)
        self.assertFalse(any(event["kind"] == "reentry" for event in store.events()))
        self.assertEqual(sorted(path.name for path in store.artifacts_path.iterdir()), artifacts_before)
        self.assertFalse(target.exists())

    def test_parent_append_failure_rolls_back_reentry_and_staged_child(self) -> None:
        store = self.make_store()
        self.through_return(store)
        target = Path(tempfile.mkdtemp()) / "child"
        self.addCleanup(lambda: __import__("shutil").rmtree(target.parent, ignore_errors=True))
        supplied_spec = child_run_spec(store, ["H-1"], run_id="parent-append-failure")
        events_before = store.events_path.read_bytes()
        artifacts_before = sorted(path.name for path in store.artifacts_path.iterdir())
        original_record = store._record

        def append_then_fail(*args, **kwargs):
            original_record(*args, **kwargs)
            raise OSError("injected failure after parent append")

        with mock.patch.object(store, "_record", side_effect=append_then_fail):
            with self.assertRaisesRegex(OSError, "after parent append"):
                store.create_child(["H-1"], target, child_spec=supplied_spec)
        self.assertEqual(store.events_path.read_bytes(), events_before)
        self.assertFalse(any(event["kind"] == "reentry" for event in store.events()))
        self.assertEqual(sorted(path.name for path in store.artifacts_path.iterdir()), artifacts_before)
        self.assertFalse(target.exists())

    def test_reentry_parent_head_partition_and_carry_proof_are_recomputed_by_audit(self) -> None:
        mutations = {
            "parent_run_id": lambda payload: payload.update({"parent_run_id": "wrong-parent"}),
            "parent_head_hash": lambda payload: payload.update({"parent_head_hash": "0" * 64}),
            "affected_fields": lambda payload: payload.update({"affected_fields": ["answer", "reentry"], "carried_fields": [], "carry_proof": {}}),
            "carry_proof": lambda payload: payload["carry_proof"]["reentry"].update({"source_return_hash": "wrong"}),
        }
        expected = {
            "parent_run_id": "parent_run_id",
            "parent_head_hash": "parent_head_hash",
            "affected_fields": "affected_fields",
            "carry_proof": "carry_proof",
        }
        for name, mutate in mutations.items():
            with self.subTest(name=name):
                store, _, reentry, _, _, _ = self.make_reentry()
                payload = copy.deepcopy(store._read_wrapper(reentry)["payload"])
                mutate(payload)
                rewrite_artifact(store, reentry["artifact_id"], payload=payload)
                result = store.audit()
                self.assertEqual(result["status"], "FAIL")
                self.assertTrue(any(expected[name] in item for item in result["failures"]), result["failures"])

    def test_reentry_rejects_a_noncurrent_or_extra_return_dependency_during_audit(self) -> None:
        store, _, reentry, first_return, current_return, _ = self.make_reentry(two_returns=True)
        rewrite_artifact(store, reentry["artifact_id"], dependencies=[first_return["artifact_id"], current_return["artifact_id"]])
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("only on the current ReturnEnvelope" in item for item in result["failures"]), result["failures"])


if __name__ == "__main__":
    unittest.main()
