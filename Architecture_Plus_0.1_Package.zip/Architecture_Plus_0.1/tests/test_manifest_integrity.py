from __future__ import annotations

import copy
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.canonical import atomic_write_text, digest_json, dumps_canonical, load_strict
from architecture_plus.package import MANIFEST_NAME, freeze, verify


class ManifestIntegrityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.packet = Path(self.temporary.name) / "packet"
        shutil.copytree(
            ROOT,
            self.packet,
            ignore=shutil.ignore_patterns("MANIFEST.json", "__pycache__", ".pytest_cache", "dist"),
        )
        freeze(self.packet)

    @property
    def manifest_path(self) -> Path:
        return self.packet / MANIFEST_NAME

    def write_manifest(self, manifest: dict) -> None:
        atomic_write_text(self.manifest_path, dumps_canonical(manifest) + "\n")

    def assert_manifest_failure(self, phrase: str) -> None:
        result = verify(self.packet)
        self.assertEqual(result["manifest"], "FAIL", result["failures"])
        self.assertTrue(any(phrase in failure for failure in result["failures"]), result["failures"])

    def test_freeze_produces_a_self_consistent_exact_inventory(self) -> None:
        manifest = load_strict(self.manifest_path)
        self.assertEqual(manifest["file_count"], len(manifest["files"]))
        self.assertEqual(manifest["content_fingerprint"], digest_json(manifest["files"]))
        paths = {row["path"] for row in manifest["files"]}
        self.assertIn("docs/README_Plus_0.1.docx", paths)
        self.assertNotIn("tools/build_readme_plus_docx.py", paths)
        result = verify(self.packet)
        self.assertEqual(result["manifest"], "PASS", result["failures"])

    def test_metadata_tampering_is_rejected(self) -> None:
        original = load_strict(self.manifest_path)
        mutations = {
            "schema_version": "architecture-plus.manifest/9.9",
            "release": "Architecture+ 9.9",
            "profile": "expanded",
            "boundary": "Hashes prove everything.",
        }
        for field, replacement in mutations.items():
            with self.subTest(field=field):
                manifest = copy.deepcopy(original)
                manifest[field] = replacement
                self.write_manifest(manifest)
                self.assert_manifest_failure(field)
        manifest = copy.deepcopy(original)
        manifest["private"] = True
        self.write_manifest(manifest)
        self.assert_manifest_failure("unknown private")

    def test_duplicate_rows_are_rejected_even_with_recomputed_metadata(self) -> None:
        manifest = load_strict(self.manifest_path)
        manifest["files"].append(copy.deepcopy(manifest["files"][-1]))
        manifest["file_count"] = len(manifest["files"])
        manifest["content_fingerprint"] = digest_json(manifest["files"])
        self.write_manifest(manifest)
        self.assert_manifest_failure("unique")

    def test_reordered_rows_are_rejected_even_with_recomputed_fingerprint(self) -> None:
        manifest = load_strict(self.manifest_path)
        manifest["files"][0], manifest["files"][1] = manifest["files"][1], manifest["files"][0]
        manifest["content_fingerprint"] = digest_json(manifest["files"])
        self.write_manifest(manifest)
        self.assert_manifest_failure("sorted canonically")

    def test_unsafe_path_is_rejected_even_with_recomputed_fingerprint(self) -> None:
        manifest = load_strict(self.manifest_path)
        manifest["files"][0]["path"] = "../escape"
        manifest["content_fingerprint"] = digest_json(manifest["files"])
        self.write_manifest(manifest)
        self.assert_manifest_failure("unsafe path segment")

    def test_row_shape_types_and_lowercase_hash_are_enforced(self) -> None:
        original = load_strict(self.manifest_path)
        mutations = (
            ("exactly path, bytes, and sha256", lambda row: row.update({"private": "x"})),
            ("nonnegative integer", lambda row: row.update({"bytes": True})),
            ("lowercase hexadecimal", lambda row: row.update({"sha256": "A" * 64})),
        )
        for phrase, mutate in mutations:
            with self.subTest(phrase=phrase):
                manifest = copy.deepcopy(original)
                mutate(manifest["files"][0])
                manifest["content_fingerprint"] = digest_json(manifest["files"])
                self.write_manifest(manifest)
                self.assert_manifest_failure(phrase)

    def test_file_count_fingerprint_and_actual_inventory_are_enforced(self) -> None:
        original = load_strict(self.manifest_path)
        manifest = copy.deepcopy(original)
        manifest["file_count"] += 1
        self.write_manifest(manifest)
        self.assert_manifest_failure("file_count")
        manifest = copy.deepcopy(original)
        manifest["content_fingerprint"] = "0" * 64
        self.write_manifest(manifest)
        self.assert_manifest_failure("content_fingerprint mismatch")
        self.write_manifest(original)
        (self.packet / "UNMANIFESTED.txt").write_text("drift\n", encoding="utf-8")
        self.assert_manifest_failure("unmanifested files")


if __name__ == "__main__":
    unittest.main()
