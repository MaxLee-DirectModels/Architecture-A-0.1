from __future__ import annotations

import copy
import json
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.canonical import digest_json, load_strict
from architecture_plus.field import validate_operator_reserve
from architecture_plus.records import RecordError, SCHEMA_VERSION, validate_artifact, validate_passage_model


def minimal_run_spec() -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "kind": "RunSpec",
        "run_id": "coverage-child",
        "request": "Reassess one affected field.",
        "formation_mode": "NATIVE",
        "requested_output_form": "bounded return",
        "unavoidable_policy_ids": [],
        "firewall_waivers": [],
        "return_contract": {
            "fields": [
                {"id": "extraction-status", "description": "status", "required": True, "risk_tier": "normal"},
                {"id": "next-action", "description": "action", "required": True, "risk_tier": "high"},
            ],
            "use": "coverage test",
            "horizon": "child run",
            "protected": [],
            "standing": "test only",
        },
        "basis": [],
        "allowed_tools": [],
        "budget": {"max_moves": 2, "max_field_terms": 2, "max_prompt_chars": 2000},
    }


class ReleaseCoverageTests(unittest.TestCase):
    def test_operator_card_fields_are_enforced(self) -> None:
        source = load_strict(ROOT / "reserve" / "operators.json")
        required = {
            "id", "name", "trigger", "requirements", "intervention", "expected_changed_fields",
            "falsifier", "cost", "contraindications", "scope", "evidence", "lease",
        }
        for field in sorted(required):
            with self.subTest(field=field):
                candidate = copy.deepcopy(source)
                del candidate["operators"][0][field]
                with self.assertRaises(ValueError):
                    validate_operator_reserve(candidate)

    def test_passage_model_required_inputs_are_enforced(self) -> None:
        source = load_strict(ROOT / "examples" / "mine" / "passage_model.json")
        required = {
            "schema_version", "kind", "model_id", "model_version", "regime", "scope",
            "empirical_standing", "domain", "bearer", "target", "regard", "demand",
            "horizon", "current_configuration", "initial_configuration", "configuration_schema",
            "qualification_dimensions", "transition_rules", "consequence_rules", "configurations",
            "passages", "basis_refs", "assumptions", "evidence_refs", "verifiers",
            "resource_accounts", "protected_conditions", "omitted_effects", "uncertainty",
        }
        for field in sorted(required):
            with self.subTest(field=field):
                candidate = copy.deepcopy(source)
                del candidate[field]
                with self.assertRaises((RecordError, TypeError)):
                    validate_passage_model(candidate)
        candidate = copy.deepcopy(source)
        candidate["configurations"][0]["features"] = ["not", "an", "object"]
        with self.assertRaises(RecordError):
            validate_passage_model(candidate)
        candidate = copy.deepcopy(source)
        del candidate["passages"][0]["conditions"]
        with self.assertRaises(RecordError):
            validate_passage_model(candidate)

    def test_return_component_fields_are_enforced(self) -> None:
        source = load_strict(ROOT / "examples" / "mine" / "return.json")
        direct_fields = [
            "field_id", "native_return", "outcome", "domain_disposition", "completion",
            "basis_refs", "binding_refs", "assumptions", "support_ceiling", "residual", "reentry",
        ]
        for field in direct_fields:
            with self.subTest(field=field):
                candidate = copy.deepcopy(source)
                del candidate["components"][0][field]
                with self.assertRaises(RecordError):
                    validate_artifact("return_envelope", candidate, {"extraction-status", "next-action"})
        candidate = copy.deepcopy(source)
        del candidate["reverse_trace"]["extraction-status"]
        with self.assertRaises(RecordError):
            validate_artifact("return_envelope", candidate, {"extraction-status", "next-action"})
        for field in ("assumptions", "residuals"):
            with self.subTest(root_field=field):
                candidate = copy.deepcopy(source)
                del candidate[field]
                with self.assertRaises(RecordError):
                    validate_artifact("return_envelope", candidate, {"extraction-status", "next-action"})

    def test_open_certificate_fields_are_enforced(self) -> None:
        source = load_strict(ROOT / "examples" / "mine" / "return.json")
        component = next(row for row in source["components"] if row["outcome"] == "OPEN")
        required = list(component["open_certificate"])
        self.assertEqual(len(required), 12)
        for field in required:
            with self.subTest(field=field):
                candidate = copy.deepcopy(source)
                target = next(row for row in candidate["components"] if row["outcome"] == "OPEN")
                del target["open_certificate"][field]
                with self.assertRaises(RecordError):
                    validate_artifact("return_envelope", candidate, {"extraction-status", "next-action"})
        candidate = copy.deepcopy(source)
        target = next(row for row in candidate["components"] if row["outcome"] == "OPEN")
        certificate = target["open_certificate"]
        certificate["earliest_useful_reentry"] = ["after", "qualified evidence"]
        certificate["artifact_fingerprint"] = "sha256:" + digest_json({key: value for key, value in certificate.items() if key != "artifact_fingerprint"})
        validate_artifact("return_envelope", candidate, {"extraction-status", "next-action"})

    def test_outcome_stages_are_exact(self) -> None:
        source = load_strict(ROOT / "examples" / "mine" / "outcome.json")
        self.assertEqual(len(source["stages"]), 12)
        for stage in list(source["stages"]):
            with self.subTest(stage=stage):
                candidate = copy.deepcopy(source)
                del candidate["stages"][stage]
                with self.assertRaises(RecordError):
                    validate_artifact("outcome_receipt", candidate, {"extraction-status", "next-action"})
        candidate = copy.deepcopy(source)
        candidate["stages"]["implied_success"] = copy.deepcopy(candidate["stages"]["effect"])
        with self.assertRaises(RecordError):
            validate_artifact("outcome_receipt", candidate, {"extraction-status", "next-action"})

    def test_reentry_contract_rejects_bad_child_hash(self) -> None:
        child = minimal_run_spec()
        record = {
            "kind": "Reentry",
            "parent_run_id": "parent-run",
            "parent_head_hash": "a" * 64,
            "changed_refs": ["B-CHANGED"],
            "affected_fields": ["next-action"],
            "carried_fields": ["extraction-status"],
            "carry_proof": {
                "extraction-status": {
                    "source_return_hash": "b" * 64,
                    "dependency_refs": ["B-STABLE"],
                    "equivalence_witness": "dependency-disjoint",
                    "support_ceiling": "test only",
                }
            },
            "first_exact_break": "B-CHANGED changed",
            "remaining_obligations": ["reassess next-action"],
            "earliest_useful_reentry": "child TARGET",
            "child_run_spec": child,
            "child_run_spec_hash": digest_json(child),
        }
        validate_artifact("reentry", record, {"extraction-status", "next-action"})
        record["earliest_useful_reentry"] = ["child", "TARGET"]
        validate_artifact("reentry", record, {"extraction-status", "next-action"})
        record["child_run_spec_hash"] = "0" * 64
        with self.assertRaises(RecordError):
            validate_artifact("reentry", record, {"extraction-status", "next-action"})

    def test_coverage_audit_passes(self) -> None:
        result = subprocess.run(
            [sys.executable, str(ROOT / "tools" / "audit_coverage.py")],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual(payload["status"], "PASS")


if __name__ == "__main__":
    unittest.main()
