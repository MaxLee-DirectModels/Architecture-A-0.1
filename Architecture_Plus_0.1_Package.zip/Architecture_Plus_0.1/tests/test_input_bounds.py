from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.canonical import (
    CanonicalError,
    MAX_INPUT_BYTES,
    MAX_STRING_CHARS,
    MAX_TOTAL_NODES,
    load_strict,
    validate_finite,
)


class InputBoundTests(unittest.TestCase):
    def test_file_byte_bound_is_checked_before_parse(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "large.json"
            path.write_bytes(b" " * (MAX_INPUT_BYTES + 1))
            with self.assertRaisesRegex(CanonicalError, "JSON input exceeds"):
                load_strict(path)

    def test_string_and_total_node_bounds_are_finite(self) -> None:
        with self.assertRaisesRegex(CanonicalError, "JSON string exceeds"):
            validate_finite("x" * (MAX_STRING_CHARS + 1))
        with self.assertRaisesRegex(CanonicalError, "total nodes"):
            validate_finite([[None] * 2_001 for _ in range(100)])


if __name__ == "__main__":
    unittest.main()
