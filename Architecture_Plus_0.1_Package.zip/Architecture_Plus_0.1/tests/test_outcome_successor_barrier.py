from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.canonical import load_strict
from architecture_plus.records import RecordError, validate_artifact


class OutcomeSuccessorBarrierTests(unittest.TestCase):
    def fixture(self):
        return load_strict(ROOT / "examples" / "mine" / "outcome.json")

    def test_exact_open_successor_contract_is_accepted(self) -> None:
        validate_artifact("outcome_receipt", self.fixture(), {"answer"})

    def test_successor_or_learning_claim_cannot_bypass_open_stages(self) -> None:
        for mutate in (
            lambda value: value["successor_signature"].update({"outcome": "EARNED"}),
            lambda value: value["successor_signature"].update({"opened": ["P-NEW"]}),
            lambda value: value["learning_updates"].append("promote rule as true"),
        ):
            value = copy.deepcopy(self.fixture())
            mutate(value)
            with self.assertRaises(RecordError):
                validate_artifact("outcome_receipt", value, {"answer"})

    def test_reopen_triggers_are_typed(self) -> None:
        value = self.fixture()
        del value["reopen_triggers"][0]["affected_stages"]
        with self.assertRaises(RecordError):
            validate_artifact("outcome_receipt", value, {"answer"})


if __name__ == "__main__":
    unittest.main()
