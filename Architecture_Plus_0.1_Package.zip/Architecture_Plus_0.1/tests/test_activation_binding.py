from __future__ import annotations

import argparse
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))
sys.path.insert(0, str(ROOT / "tests"))

from architecture_plus.cli import build_parser, command_activate
from architecture_plus.records import RecordError
from architecture_plus.store import RunStore
from test_architecture_plus import run_spec, valid_backward, valid_forward, valid_hinges


class ActivationBindingTests(unittest.TestCase):
    def make_hinge_run(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        store = RunStore(Path(temporary.name) / "run")
        store.create(run_spec())
        candidate = store.record("candidate", "P0")
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        store.record("hinge_set", valid_hinges(), dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]])
        return store

    def args(self, store, *, context_ref="H-1", field="answer"):
        return argparse.Namespace(
            query="challenge trial", limit=5, operator_limit=2, context="hinge",
            run=str(store.path), context_ref=context_ref, predicted_changed_field=field,
            cost="one lookup", falsifier="no changed return", output=str(store.path / "activation.json"),
        )

    def test_bound_activation_resolves_current_hinge_and_field(self) -> None:
        store = self.make_hinge_run()
        self.assertEqual(command_activate(self.args(store)), 0)
        result = __import__("json").loads((store.path / "activation.json").read_text(encoding="utf-8"))
        self.assertRegex(result["activation_fingerprint"], r"^sha256:[0-9a-f]{64}$")

    def test_invented_context_or_field_is_rejected(self) -> None:
        store = self.make_hinge_run()
        with self.assertRaises(RecordError):
            command_activate(self.args(store, context_ref="H-INVENTED"))
        with self.assertRaises(RecordError):
            command_activate(self.args(store, field="reentry"))

    def test_cli_has_no_arbitrary_field_slice_injection(self) -> None:
        prompt = next(action for action in build_parser()._actions if action.dest == "command").choices["prompt"]
        self.assertNotIn("field_slice", {action.dest for action in prompt._actions})


if __name__ == "__main__":
    unittest.main()
