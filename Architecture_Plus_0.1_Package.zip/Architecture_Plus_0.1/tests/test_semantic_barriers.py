from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.canonical import load_strict
from architecture_plus.records import RecordError, validate_artifact


ALL_STAGES = (
    "recommendation",
    "choice",
    "permission",
    "attempt",
    "execution",
    "occurrence",
    "technical_receipt",
    "observation",
    "evaluation",
    "attribution",
    "effect",
    "durability",
)
NON_RECOMMENDATION_STAGES = set(ALL_STAGES[1:])


def hinge(hinge_id: str) -> dict:
    return {
        "hinge_id": hinge_id,
        "candidate": "candidate A",
        "rival": "rival B",
        "affected_fields": ["answer"],
        "consequence_split": {"candidate": "return A", "rival": "return B"},
        "basis_refs": ["B-1"],
        "assumptions": [],
        "discriminator": "inspect the differentiating evidence",
        "move": "run one bounded check",
        "cost": "one check",
        "risk": "low",
        "contraindications": ["no qualified evidence"],
        "status": "CANDIDATE",
        "expiry_or_reopen": ["evidence changes"],
    }


def stage(*, outcome: str, disposition: str, evidence: bool, limit: str) -> dict:
    return {
        "actor": "fixture",
        "time": "fixture-time",
        "basis_refs": ["B-1"],
        "evidence_refs": ["EV-1"] if evidence else [],
        "outcome": outcome,
        "disposition": disposition,
        "native_result": "bounded fixture result",
        "limits": [limit] if limit else [],
    }


def outcome_receipt() -> dict:
    stages = {}
    for name in ALL_STAGES:
        if name in NON_RECOMMENDATION_STAGES:
            disposition = "NOT_APPLICABLE" if name == "durability" else "UNKNOWN"
            stages[name] = stage(
                outcome="OPEN",
                disposition=disposition,
                evidence=False,
                limit="0.1 has no typed external stage profile",
            )
        else:
            stages[name] = stage(
                outcome="EARNED",
                disposition="POSITIVE",
                evidence=True,
                limit="",
            )
    return {
        "kind": "OutcomeReceipt",
        "stages": stages,
        "successor_signature": {
            "outcome": "OPEN", "opened": "OPEN", "closed": "OPEN",
            "preserved": "OPEN", "redirected": "OPEN", "basis_refs": ["B-1"],
            "support_ceiling": "no typed external consequence profile",
            "unknowns": ["world effect"],
        },
        "attribution_limits": [],
        "learning_updates": [],
        "reopen_triggers": [],
    }


class SemanticBarrierTests(unittest.TestCase):
    def test_duplicate_hinge_id_is_rejected(self) -> None:
        first = hinge("H-1")
        record = {"kind": "HingeSet", "hinges": [first, copy.deepcopy(first)]}
        with self.assertRaisesRegex(RecordError, "duplicate hinge_id: H-1"):
            validate_artifact("hinge_set", record, {"answer"})

    def test_only_recommendation_can_be_earned(self) -> None:
        source = outcome_receipt()
        for name in sorted(NON_RECOMMENDATION_STAGES):
            with self.subTest(stage=name):
                candidate = copy.deepcopy(source)
                candidate["stages"][name] = stage(
                    outcome="EARNED",
                    disposition="POSITIVE",
                    evidence=True,
                    limit="",
                )
                with self.assertRaisesRegex(RecordError, "no typed external stage profile"):
                    validate_artifact("outcome_receipt", candidate, {"answer"})

    def test_nonrecommendation_stages_cannot_assert_rejection(self) -> None:
        source = outcome_receipt()
        for name in sorted(NON_RECOMMENDATION_STAGES):
            with self.subTest(stage=name):
                candidate = copy.deepcopy(source)
                candidate["stages"][name] = stage(
                    outcome="REJECTED",
                    disposition="NEGATIVE",
                    evidence=True,
                    limit="",
                )
                with self.assertRaisesRegex(RecordError, "requires OPEN"):
                    validate_artifact("outcome_receipt", candidate, {"answer"})

    def test_open_nonrecommendation_and_earned_recommendation_are_accepted(self) -> None:
        validate_artifact("outcome_receipt", outcome_receipt(), {"answer"})

    def test_schema_mirrors_explicit_outcome_ceiling(self) -> None:
        defs = load_strict(ROOT / "schemas" / "records.schema.json")["$defs"]
        stages = defs["OutcomeReceipt"]["properties"]["stages"]
        self.assertFalse(stages["additionalProperties"])
        self.assertEqual(set(stages["required"]), set(ALL_STAGES))
        self.assertEqual(set(stages["properties"]), set(ALL_STAGES))
        self.assertEqual(stages["properties"]["recommendation"], {"$ref": "#/$defs/OutcomeStage"})
        for name in NON_RECOMMENDATION_STAGES:
            self.assertEqual(stages["properties"][name], {"$ref": "#/$defs/OpenOutcomeStage"})
        ceiling = defs["OpenOutcomeStage"]["allOf"][1]["properties"]
        self.assertEqual(ceiling["outcome"], {"const": "OPEN"})
        self.assertEqual(ceiling["disposition"], {"enum": ["UNKNOWN", "NOT_APPLICABLE"]})

    def test_schema_encodes_native_binding_trial_and_fingerprint_barriers(self) -> None:
        defs = load_strict(ROOT / "schemas" / "records.schema.json")["$defs"]
        native = defs["RunSpec"]["allOf"][0]
        self.assertEqual(native["if"]["properties"]["formation_mode"], {"const": "NATIVE"})
        self.assertEqual(native["then"]["properties"]["firewall_waivers"], {"maxItems": 0})

        status_pairs = {}
        for rule in defs["Binding"]["allOf"]:
            binding_status = rule["if"]["properties"]["status"]["const"]
            warrant_status = rule["then"]["properties"]["warrant"]["properties"]["status"]["const"]
            status_pairs[binding_status] = warrant_status
        self.assertEqual(status_pairs, {"ADMITTED": "SUPPORTED", "OPEN": "OPEN", "REJECTED": "REJECTED"})

        trial_rule = defs["Trial"]["allOf"][0]
        self.assertEqual(
            trial_rule["then"]["properties"]["result"]["enum"],
            ["INCOMPARABLE", "OPEN"],
        )
        unmatched = set()
        for condition in trial_rule["if"]["anyOf"]:
            carrier = next(iter(condition["properties"]))
            self.assertFalse(condition["properties"][carrier]["properties"]["matched"]["const"])
            unmatched.add(carrier)
        self.assertEqual(unmatched, {"matched_budget", "matched_tools"})
        self.assertEqual(
            defs["OpenCertificate"]["properties"]["artifact_fingerprint"]["pattern"],
            "^sha256:[0-9a-f]{64}$",
        )

    def test_prompts_state_exact_outcome_and_budget_ceilings(self) -> None:
        outcome_prompt = (ROOT / "prompts" / "outcome.txt").read_text(encoding="utf-8")
        trial_prompt = (ROOT / "prompts" / "trial.txt").read_text(encoding="utf-8")
        self.assertIn("only recommendation may be `EARNED`", outcome_prompt)
        self.assertIn("must each use outcome `OPEN`", outcome_prompt)
        self.assertIn("candidate and rival as nonnegative integers", trial_prompt)
        self.assertIn("Any unmatched budget or tool access", trial_prompt)


if __name__ == "__main__":
    unittest.main()
