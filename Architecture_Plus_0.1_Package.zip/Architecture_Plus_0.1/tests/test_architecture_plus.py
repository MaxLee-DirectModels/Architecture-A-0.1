from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.canonical import CanonicalError, digest_file, digest_json, load_strict, loads_strict
from architecture_plus.cli import build_parser
from architecture_plus.field import activate, validate_operator_reserve
from architecture_plus.package import verify
from architecture_plus.passage import assess
from architecture_plus.prompts import firewall_projection, render_prompt
from architecture_plus.records import RecordError, SCHEMA_VERSION, validate_artifact, validate_run_spec
from architecture_plus.store import RunStore


def run_spec() -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "kind": "RunSpec",
        "run_id": "test-run",
        "request": "Produce the smallest defensible result.",
        "formation_mode": "NATIVE",
        "requested_output_form": "test return",
        "unavoidable_policy_ids": [],
        "firewall_waivers": [],
        "return_contract": {
            "fields": [
                {"id": "answer", "description": "The answer", "required": True, "risk_tier": "normal"},
                {"id": "reentry", "description": "An exact reentry", "required": True, "risk_tier": "normal"},
            ],
            "use": "test",
            "horizon": "current run",
            "protected": ["do not invent evidence"],
            "standing": "test only",
        },
        "basis": [
            {"id": "B-PUBLIC", "kind": "fact", "content": "PUBLIC-MARKER", "expose_to_free": True},
            {"id": "B-HIDDEN", "kind": "reserve", "content": "HIDDEN-MARKER", "expose_to_free": False},
        ],
        "allowed_tools": [],
        "budget": {"max_moves": 4, "max_field_terms": 5, "max_prompt_chars": 50000},
    }


def child_run_spec(store: RunStore, changed_refs: list[str], *, run_id: str) -> dict:
    child = copy.deepcopy(store.run_spec())
    child["run_id"] = run_id
    parent_basis = {item["id"]: item for item in store.run_spec().get("basis", [])}
    material = []
    for changed_ref in sorted(set(changed_refs)):
        basis_ref = changed_ref
        if basis_ref in parent_basis:
            item = next(item for item in child["basis"] if item["id"] == basis_ref)
            item["content"] = str(item.get("content", item.get("reference", ""))) + " [changed for child reassessment]"
            item.pop("reference", None)
        else:
            child.setdefault("basis", []).append({
                "id": basis_ref,
                "kind": "changed_material",
                "content": f"Replacement material for {changed_ref}",
                "expose_to_free": True,
            })
        material.append({"changed_ref": changed_ref, "basis_ref": basis_ref})
    child["lineage"] = {
        "reentry": {
            "parent_run_id": store.run_spec()["run_id"],
            "parent_head_hash": store.events()[-1]["record_hash"],
            "changed_material": material,
        }
    }
    return child


def valid_hinges() -> dict:
    return {
        "kind": "HingeSet",
        "hinges": [{
            "hinge_id": "H-1",
            "candidate": "A",
            "rival": "B",
            "affected_fields": ["answer"],
            "consequence_split": {"candidate": "answer A", "rival": "answer B"},
            "basis_refs": ["B-PUBLIC"],
            "assumptions": [],
            "discriminator": "check",
            "move": "compare",
            "cost": "low",
            "risk": "low",
            "contraindications": ["no discriminator"],
            "status": "CANDIDATE",
            "expiry_or_reopen": ["new evidence"],
        }, {
            "hinge_id": "H-2",
            "candidate": "witness is present",
            "rival": "witness is absent",
            "affected_fields": ["reentry"],
            "consequence_split": {"candidate": "reentry can close", "rival": "reentry remains open"},
            "basis_refs": ["B-HIDDEN"],
            "assumptions": [],
            "discriminator": "inspect witness",
            "move": "request witness",
            "cost": "unknown",
            "risk": "low",
            "contraindications": [],
            "status": "OPEN",
            "expiry_or_reopen": ["witness arrives"],
        }],
    }


def valid_return() -> dict:
    envelope = {
        "kind": "ReturnEnvelope",
        "components": [
            {"field_id": "answer", "native_return": "bounded", "outcome": "EARNED", "domain_disposition": "POSITIVE", "completion": "COMPLETE", "basis_refs": ["B-PUBLIC"], "binding_refs": ["BD-1"], "dependency_refs": ["B-PUBLIC"], "depends_on_fields": [], "assumptions": [], "support_ceiling": "test", "residual": [], "reentry": "on change", "limits": []},
            {
                "field_id": "reentry",
                "outcome": "OPEN",
                "native_return": "witness needed",
                "domain_disposition": "UNKNOWN",
                "completion": "NONE",
                "basis_refs": ["B-HIDDEN"],
                "binding_refs": ["BD-2"],
                "dependency_refs": ["B-HIDDEN"],
                "depends_on_fields": [],
                "assumptions": [],
                "support_ceiling": "none",
                "residual": ["witness"],
                "reentry": "when witness arrives",
                "limits": ["test fixture"],
                "open_certificate": {
                    "first_exact_break": "missing witness",
                    "deepest_supported_prefix": "NONE_EARNED",
                    "affected_fields": ["reentry"],
                    "unaffected_fields": ["answer"],
                    "remaining_obligations": ["obtain witness"],
                    "needed": {"evidence": ["witness"], "event": [], "permission": [], "choice": [], "capability": []},
                    "reverse_evidence": ["B-HIDDEN"],
                    "assumptions": [],
                    "support_ceiling": "none",
                    "earliest_useful_reentry": "when witness arrives",
                    "artifact_fingerprint": "sha256:RECOMPUTE",
                    "unexamined_scope": ["open world"],
                },
            },
        ],
        "reverse_trace": {"answer": ["B-PUBLIC", "BD-1"], "reentry": ["B-HIDDEN", "BD-2"]},
        "assumptions": [],
        "residuals": ["external witness remains open"],
        "stop_basis": {
            "thin": {"outcome": "EARNED", "method": "ablate", "result": "binding changes answer"},
            "missing_frame_scout": {"outcome": "OPEN", "method": "bounded scout", "result": "not externally run", "open_reason": "test has no external source"},
            "move_budget": {"used": 2, "maximum": 4, "remaining": 2, "outcome": "OPEN", "basis": "external witness required"},
            "closure": "return exact OPEN",
        },
    }
    certificate = envelope["components"][1]["open_certificate"]
    certificate["artifact_fingerprint"] = "sha256:" + digest_json({key: value for key, value in certificate.items() if key != "artifact_fingerprint"})
    return envelope


def valid_bindings() -> dict:
    return {
        "kind": "BindingSet",
        "bindings": [
            {"binding_id": "BD-1", "binding_type": "claim", "statement": "bounded answer", "status": "ADMITTED", "scope": "test", "affected_fields": ["answer"], "hinge_refs": ["H-1"], "trial_refs": ["T-1"], "basis_refs": ["B-PUBLIC"], "dependencies": ["B-PUBLIC"], "warrant": {"rule": "test rule", "verifier": "test verifier", "scope": "test", "standing_ceiling": "test", "status": "SUPPORTED", "witness_refs": ["B-PUBLIC"]}, "cost": "low", "contraindications": ["basis change"], "expiry": "run end", "reopen_conditions": ["B-PUBLIC changes"]},
            {"binding_id": "BD-2", "binding_type": "obligation", "statement": "witness remains missing", "status": "OPEN", "scope": "test", "affected_fields": ["reentry"], "hinge_refs": ["H-2"], "trial_refs": ["T-2"], "basis_refs": ["B-HIDDEN"], "dependencies": ["B-HIDDEN"], "warrant": {"rule": "test rule", "verifier": "test verifier", "scope": "test", "standing_ceiling": "none", "status": "OPEN", "witness_refs": []}, "cost": "unknown", "contraindications": [], "expiry": "witness or run end", "reopen_conditions": ["witness arrives"]},
        ],
    }


def valid_trials() -> dict:
    return {
        "kind": "TrialSet",
        "trials": [
            {"trial_id": "T-1", "hinge_id": "H-1", "candidate": "A", "rival": "B", "shared_criteria": ["same criterion"], "discriminator": "check", "move": "check", "execution_status": "EXECUTED", "matched_budget": {"candidate": 1, "rival": 1, "unit": "test pass", "matched": True}, "matched_tools": {"candidate": ["test tool"], "rival": ["test tool"], "matched": True}, "observations": ["A has support"], "evidence_refs": ["B-PUBLIC"], "uncertainty": [], "limitations": [], "result": "SUPPORTS_A", "declared_update": "admit A locally", "changed_return_fields": ["answer"]},
            {"trial_id": "T-2", "hinge_id": "H-2", "candidate": "witness is present", "rival": "witness is absent", "shared_criteria": ["same witness standard"], "discriminator": "inspect witness", "move": "request witness", "execution_status": "DESIGNED", "matched_budget": {"candidate": 1, "rival": 1, "unit": "test pass", "matched": True}, "matched_tools": {"candidate": ["witness request"], "rival": ["witness request"], "matched": True}, "observations": [], "evidence_refs": [], "uncertainty": ["witness missing"], "limitations": ["not executed"], "result": "OPEN", "declared_update": "keep reentry open", "changed_return_fields": ["reentry"]},
        ],
    }


def valid_backward() -> dict:
    return {"kind": "BackwardSweep", "observations": ["return needs support"], "candidate_hinges": ["H-1"], "unsupported_links": ["witness missing"], "open": ["reentry witness"]}


def valid_forward() -> dict:
    return {"kind": "ForwardSweep", "observations": ["basis warrants a check"], "candidate_hinges": ["H-1"], "proposed_moves": ["check"], "open": ["reentry witness"]}


class CanonicalTests(unittest.TestCase):
    def test_duplicate_json_key_is_rejected(self) -> None:
        with self.assertRaises(CanonicalError):
            loads_strict('{"a":1,"a":2}')

    def test_nfc_colliding_key_is_rejected(self) -> None:
        with self.assertRaises(CanonicalError):
            loads_strict('{"é":1,"é":2}')

    def test_nonfinite_number_is_rejected(self) -> None:
        with self.assertRaises(CanonicalError):
            loads_strict('{"a":NaN}')

    def test_binary_float_is_rejected(self) -> None:
        with self.assertRaises(CanonicalError):
            loads_strict('{"a":0.1}')


class ContractTests(unittest.TestCase):
    def test_run_spec_accepts_minimal_valid_record(self) -> None:
        self.assertEqual(validate_run_spec(run_spec())["run_id"], "test-run")

    def test_run_spec_rejects_unknown_field(self) -> None:
        value = run_spec()
        value["ontology"] = "smuggled"
        with self.assertRaises(RecordError):
            validate_run_spec(value)

    def test_hinge_must_change_declared_return(self) -> None:
        hinge = valid_hinges()
        hinge["hinges"][0]["affected_fields"] = ["not-a-return"]
        with self.assertRaises(RecordError):
            validate_artifact("hinge_set", hinge, {"answer", "reentry"})

    def test_return_must_cover_every_field(self) -> None:
        envelope = valid_return()
        envelope["components"].pop()
        with self.assertRaises(RecordError):
            validate_artifact("return_envelope", envelope, {"answer", "reentry"})

    def test_open_requires_exact_certificate(self) -> None:
        envelope = valid_return()
        del envelope["components"][1]["open_certificate"]["earliest_useful_reentry"]
        with self.assertRaises(RecordError):
            validate_artifact("return_envelope", envelope, {"answer", "reentry"})

    def test_unknown_semantic_field_is_rejected(self) -> None:
        hinge = valid_hinges()
        hinge["hinges"][0]["magic"] = "smuggled"
        with self.assertRaises(RecordError):
            validate_artifact("hinge_set", hinge, {"answer", "reentry"})

    def test_supported_outcome_stage_requires_evidence(self) -> None:
        receipt = {"kind": "OutcomeReceipt", "stages": {"execution": {"status": "SUPPORTED", "evidence_refs": []}}}
        with self.assertRaises(RecordError):
            validate_artifact("outcome_receipt", receipt, {"answer", "reentry"})

    def test_binding_requires_witness_when_admitted(self) -> None:
        bindings = valid_bindings()
        bindings["bindings"][0]["warrant"]["witness_refs"] = []
        with self.assertRaises(RecordError):
            validate_artifact("binding_set", bindings, {"answer", "reentry"})

    def test_trial_rejects_binary_float_budget(self) -> None:
        trials = valid_trials()
        trials["trials"][0]["matched_budget"]["candidate"] = 0.5
        with self.assertRaises((RecordError, CanonicalError)):
            validate_artifact("trial", trials, {"answer", "reentry"})

    def test_hinge_requires_materially_different_rivals(self) -> None:
        hinges = valid_hinges()
        hinges["hinges"][0]["rival"] = "A"
        with self.assertRaises(RecordError):
            validate_artifact("hinge_set", hinges, {"answer", "reentry"})

    def test_trial_tool_access_is_compared_not_asserted(self) -> None:
        trials = valid_trials()
        trials["trials"][0]["matched_tools"]["rival"] = ["different tool"]
        with self.assertRaises(RecordError):
            validate_artifact("trial", trials, {"answer", "reentry"})

    def test_rejected_binding_requires_counterwitness(self) -> None:
        bindings = valid_bindings()
        binding = bindings["bindings"][0]
        binding["status"] = "REJECTED"
        binding["warrant"]["status"] = "REJECTED"
        binding["warrant"]["witness_refs"] = []
        with self.assertRaises(RecordError):
            validate_artifact("binding_set", bindings, {"answer", "reentry"})


class FirewallTests(unittest.TestCase):
    def test_free_projection_excludes_hidden_basis_and_return_contract(self) -> None:
        projection = firewall_projection(run_spec())
        self.assertIn("PUBLIC-MARKER", projection)
        self.assertNotIn("HIDDEN-MARKER", projection)
        self.assertNotIn("return_contract", projection)

    def test_free_prompt_does_not_leak_hidden_basis(self) -> None:
        prompt = render_prompt(ROOT, "free", run_spec(), {})
        self.assertIn("PUBLIC-MARKER", prompt)
        self.assertNotIn("HIDDEN-MARKER", prompt)
        self.assertNotIn("The answer", prompt)

    def test_sweeps_require_frozen_candidate(self) -> None:
        with self.assertRaises(RecordError):
            render_prompt(ROOT, "backward", run_spec(), {})
        with self.assertRaises(RecordError):
            render_prompt(ROOT, "forward", run_spec(), {})

    def test_sweeps_do_not_leak_each_other(self) -> None:
        artifacts = {
            "candidate": "P0",
            "backward_sweep": {"secret": "BACKWARD-SECRET"},
            "forward_sweep": {"secret": "FORWARD-SECRET"},
        }
        backward = render_prompt(ROOT, "backward", run_spec(), artifacts)
        forward = render_prompt(ROOT, "forward", run_spec(), artifacts)
        self.assertNotIn("FORWARD-SECRET", backward)
        self.assertNotIn("BACKWARD-SECRET", forward)


class StoreTests(unittest.TestCase):
    def make_store(self) -> tuple[tempfile.TemporaryDirectory, RunStore]:
        temp = tempfile.TemporaryDirectory()
        store = RunStore(Path(temp.name) / "run")
        store.create(run_spec())
        return temp, store

    def test_p0_can_be_frozen_only_once(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        store.record("candidate", "P0", dependencies=["B-PUBLIC"])
        with self.assertRaises(RecordError):
            store.record("candidate", "P1", dependencies=["B-PUBLIC"])

    def test_unknown_dependency_is_rejected(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        with self.assertRaises(RecordError):
            store.record("candidate", "P0", dependencies=["B-NOT-THERE"])

    def test_hidden_dependency_cannot_enter_p0(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        with self.assertRaises(RecordError):
            store.record("candidate", "P0", dependencies=["B-HIDDEN"])

    def test_same_inputs_produce_same_event_chain(self) -> None:
        temp1, store1 = self.make_store()
        temp2, store2 = self.make_store()
        self.addCleanup(temp1.cleanup)
        self.addCleanup(temp2.cleanup)
        store1.record("candidate", "P0", dependencies=["B-PUBLIC"])
        store2.record("candidate", "P0", dependencies=["B-PUBLIC"])
        self.assertEqual(store1.audit()["head_hash"], store2.audit()["head_hash"])

    def test_tampering_is_detected(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        event = store.record("candidate", "P0", dependencies=["B-PUBLIC"])
        path = store.path / event["artifact_path"]
        path.write_text(path.read_text(encoding="utf-8") + " ", encoding="utf-8")
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("artifact_hash mismatch" in failure for failure in result["failures"]))

    def test_selective_reentry_uses_declared_basis_refs(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        candidate = store.record("candidate", "P0", dependencies=["B-PUBLIC"])
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        hinge = store.record("hinge_set", valid_hinges(), dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]])
        trial = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        binding = store.record("binding_set", valid_bindings(), dependencies=[hinge["artifact_id"], trial["artifact_id"]])
        seal = store.seal()
        store.record("return_envelope", valid_return(), dependencies=[candidate["artifact_id"], hinge["artifact_id"], trial["artifact_id"], binding["artifact_id"], seal["artifact_id"], "B-PUBLIC", "B-HIDDEN"])
        public_change = store.reopen(["B-PUBLIC"])
        hidden_change = store.reopen(["B-HIDDEN"])
        self.assertEqual(public_change["affected_fields"], ["answer", "reentry"])
        self.assertEqual(hidden_change["affected_fields"], ["reentry"])

    def test_seal_integrity_audits(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        candidate = store.record("candidate", "P0")
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        hinge = store.record("hinge_set", valid_hinges(), dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]])
        trial = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        store.record("binding_set", valid_bindings(), dependencies=[hinge["artifact_id"], trial["artifact_id"]])
        store.seal(represented_operations=["draft"])
        result = store.audit()
        self.assertEqual(result["status"], "PASS", result["failures"])

    def test_unknown_reentry_reference_reopens_all_fields(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        result = store.reopen(["UNKNOWN"])
        self.assertEqual(result["affected_fields"], ["answer", "reentry"])

    def test_create_child_partitions_fields_without_mutating_parent_prefix(self) -> None:
        temp, store = self.make_store()
        self.addCleanup(temp.cleanup)
        candidate = store.record("candidate", "P0")
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        hinge = store.record("hinge_set", valid_hinges(), dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]])
        trial = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        binding = store.record("binding_set", valid_bindings(), dependencies=[hinge["artifact_id"], trial["artifact_id"]])
        seal = store.seal()
        store.record("return_envelope", valid_return(), dependencies=[candidate["artifact_id"], hinge["artifact_id"], trial["artifact_id"], binding["artifact_id"], seal["artifact_id"], "B-PUBLIC", "B-HIDDEN"])
        prior_head = store.events()[-1]["record_hash"]
        child = Path(temp.name) / "child"
        result = store.create_child(
            ["B-PUBLIC"],
            child,
            child_spec=child_run_spec(store, ["B-PUBLIC"], run_id="child-run"),
        )
        self.assertEqual(result["reentry"]["affected_fields"], ["answer", "reentry"])
        self.assertEqual(result["reentry"]["carried_fields"], [])
        self.assertEqual(store.events()[-2]["record_hash"], prior_head)
        self.assertEqual(RunStore(child).run_spec()["run_id"], "child-run")


class PassageAndFieldTests(unittest.TestCase):
    def test_passage_model_reports_opened_closed_preserved(self) -> None:
        model = load_strict(ROOT / "examples" / "mine" / "passage_model.json")
        result = assess(model, "C-ACCESSIBLE", "C-COLLAPSED")
        self.assertEqual(result["successor_signature"]["closed"], ["P-COLLAPSE", "P-EXTRACT"])
        self.assertEqual(result["successor_signature"]["opened"], [])
        self.assertIn("P-CLEAR", [item["passage_id"] for item in result["successor_field"]["open"]])

    def test_unknown_passage_configuration_is_rejected(self) -> None:
        model = load_strict(ROOT / "examples" / "mine" / "passage_model.json")
        with self.assertRaises(RecordError):
            assess(model, "NOT-A-STATE")

    def test_passage_comparison_without_k_is_incomparable(self) -> None:
        model = load_strict(ROOT / "examples" / "mine" / "passage_model.json")
        del model["comparison_relation"]
        result = assess(model, "C-ACCESSIBLE", "C-COLLAPSED")
        self.assertEqual(result["outcome"], "OPEN")
        self.assertEqual(result["domain_disposition"], "INCOMPARABLE")
        self.assertEqual(result["successor_signature"]["opened"], "OPEN")

    def test_passage_comparison_requires_complete_identity_domain(self) -> None:
        model = load_strict(ROOT / "examples" / "mine" / "passage_model.json")
        model["comparison_relation"]["domain"] = ["P-EXTRACT"]
        result = assess(model, "C-ACCESSIBLE", "C-COLLAPSED")
        self.assertEqual(result["outcome"], "OPEN")
        self.assertEqual(result["domain_disposition"], "INCOMPARABLE")
        self.assertEqual(result["successor_signature"]["closed"], "OPEN")

    def test_resource_account_requires_every_gate(self) -> None:
        model = load_strict(ROOT / "examples" / "mine" / "passage_model.json")
        del model["resource_accounts"][0]["gate_status"]["usable"]
        with self.assertRaises(RecordError):
            assess(model, "C-COLLAPSED")

    def test_field_is_capped_deterministic_and_nonnormative(self) -> None:
        first = activate(ROOT, "standing authority evidence passage", limit=3, operator_limit=2)
        second = activate(ROOT, "standing authority evidence passage", limit=3, operator_limit=2)
        self.assertEqual(first, second)
        self.assertLessEqual(len(first["terms"]), 3)
        self.assertLessEqual(len(first["operators"]), 2)
        self.assertEqual(first["authority"], "nonnormative_dormant_reserve")
        for operator in first["operators"]:
            self.assertIn("activation_reason", operator)

    def test_operator_reserve_absence_is_exact_open(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_root = Path(temp)
            (temp_root / "reserve").mkdir()
            (temp_root / "reserve" / "lexicon.json").write_text((ROOT / "reserve" / "lexicon.json").read_text(encoding="utf-8"), encoding="utf-8")
            result = activate(temp_root, "challenge trial", limit=2, operator_limit=2)
            self.assertEqual(result["operators"], [])
            self.assertEqual(result["operator_open"], "reserve/operators.json is absent")

    def test_operator_limit_zero_disables_operator_cards(self) -> None:
        result = activate(ROOT, "challenge trial", limit=2, operator_limit=0)
        self.assertEqual(result["operators"], [])

    def test_stopword_only_lookup_is_open_and_empty(self) -> None:
        result = activate(ROOT, "the and or to with", limit=2, operator_limit=2)
        self.assertEqual(result["status"], "OPEN")
        self.assertEqual(result["terms"], [])
        self.assertEqual(result["operators"], [])

    def test_bound_activation_requires_exact_context_contract(self) -> None:
        with self.assertRaises(ValueError):
            activate(ROOT, "challenge", context="hinge")

    def test_operators_remain_available_when_lexicon_is_absent(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_root = Path(temp)
            (temp_root / "reserve").mkdir()
            (temp_root / "reserve" / "operators.json").write_text((ROOT / "reserve" / "operators.json").read_text(encoding="utf-8"), encoding="utf-8")
            result = activate(temp_root, "challenge trial", limit=2, operator_limit=2)
            self.assertEqual(result["lexicon_open"], "reserve/lexicon.json is absent")
            self.assertLessEqual(len(result["operators"]), 2)
            self.assertEqual(result["authority"], "nonnormative_dormant_reserve")

    def test_operator_authority_is_validated(self) -> None:
        data = load_strict(ROOT / "reserve" / "operators.json")
        data["authority"] = "NORMATIVE"
        with self.assertRaises(ValueError):
            validate_operator_reserve(data)


class PacketTests(unittest.TestCase):
    def test_cli_parser_builds_without_option_conflicts(self) -> None:
        self.assertEqual(build_parser().prog, "architecture-plus")

    def test_packet_structure_verifies_before_freeze(self) -> None:
        result = verify(ROOT)
        self.assertEqual(result["status"], "PASS", result["failures"])
        self.assertIn(result["manifest"], {"NOT_FROZEN", "PASS"})

    def test_json_schema_is_strict_json(self) -> None:
        schema = load_strict(ROOT / "schemas" / "records.schema.json")
        self.assertEqual(schema["$defs"]["RunSpec"]["properties"]["schema_version"]["const"], SCHEMA_VERSION)
        self.assertFalse(schema["$defs"]["BindingSet"]["additionalProperties"])
        self.assertFalse(schema["$defs"]["OpenCertificate"]["additionalProperties"])
        self.assertFalse(schema["$defs"]["OpenCertificate"]["properties"]["needed"]["additionalProperties"])
        self.assertIn("array", schema["$defs"]["OpenCertificate"]["properties"]["earliest_useful_reentry"]["type"])
        for field in ("qualification_dimensions", "transition_rules", "consequence_rules", "assumptions", "verifiers", "protected_conditions", "omitted_effects"):
            self.assertEqual(schema["$defs"]["PassageModel"]["properties"][field]["items"]["type"], "string")


if __name__ == "__main__":
    unittest.main()
