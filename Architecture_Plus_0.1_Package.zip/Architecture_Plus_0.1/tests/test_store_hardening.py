from __future__ import annotations

import copy
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))
sys.path.insert(0, str(ROOT / "tests"))

from architecture_plus.canonical import digest_file, digest_json, dumps_canonical, load_strict
from architecture_plus.records import RecordError
from architecture_plus.store import RunStore
from test_architecture_plus import (
    run_spec,
    valid_backward,
    valid_bindings,
    valid_forward,
    valid_hinges,
    valid_return,
    valid_trials,
)


def replace_refs(value, replacements: dict[str, str]):
    if isinstance(value, str):
        return replacements.get(value, value)
    if isinstance(value, list):
        return [replace_refs(item, replacements) for item in value]
    if isinstance(value, dict):
        return {key: replace_refs(item, replacements) for key, item in value.items()}
    return value


class StoreHarness(unittest.TestCase):
    def make_store(self, *, max_moves: int = 4) -> tuple[tempfile.TemporaryDirectory, RunStore]:
        temporary = tempfile.TemporaryDirectory()
        spec = run_spec()
        spec["budget"]["max_moves"] = max_moves
        store = RunStore(Path(temporary.name) / "run")
        store.create(spec)
        self.addCleanup(temporary.cleanup)
        return temporary, store

    def through_hinges(self, store: RunStore):
        candidate = store.record("candidate", "P0")
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        hinge = store.record(
            "hinge_set",
            valid_hinges(),
            dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]],
        )
        return candidate, backward, forward, hinge

    def through_seal(self, store: RunStore):
        candidate, _, _, hinge = self.through_hinges(store)
        trial = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        binding = store.record("binding_set", valid_bindings(), dependencies=[hinge["artifact_id"], trial["artifact_id"]])
        seal = store.seal()
        return candidate, hinge, trial, binding, seal


class StrictStorageTests(StoreHarness):
    def test_event_duplicate_key_is_rejected_by_strict_parser(self) -> None:
        _, store = self.make_store()
        line = store.events_path.read_text(encoding="utf-8").rstrip("\n")
        store.events_path.write_text(line[:-1] + ',"sequence":1}\n', encoding="utf-8")
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("duplicate" in failure for failure in result["failures"]))

    def test_event_unknown_field_is_rejected_even_with_recomputed_hash(self) -> None:
        _, store = self.make_store()
        event = store.events()[0]
        event["private"] = "smuggled"
        body = {key: value for key, value in event.items() if key != "record_hash"}
        event["record_hash"] = digest_json(body)
        store.events_path.write_text(dumps_canonical(event) + "\n", encoding="utf-8")
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("unknown private" in failure for failure in result["failures"]))

    def test_event_noncanonical_json_is_rejected(self) -> None:
        _, store = self.make_store()
        value = store.events()[0]
        store.events_path.write_text(__import__("json").dumps(value) + "\n", encoding="utf-8")
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("not canonical" in failure for failure in result["failures"]))

    def test_wrapper_unknown_field_is_rejected_after_storage_hash_is_recomputed(self) -> None:
        _, store = self.make_store()
        recorded = store.record("candidate", "P0")
        events = store.events()
        wrapper_path = store.path / recorded["artifact_path"]
        wrapper = load_strict(wrapper_path)
        wrapper["private"] = "smuggled"
        wrapper_path.write_text(dumps_canonical(wrapper) + "\n", encoding="utf-8")
        events[-1]["artifact_hash"] = digest_file(wrapper_path)
        body = {key: value for key, value in events[-1].items() if key != "record_hash"}
        events[-1]["record_hash"] = digest_json(body)
        store.events_path.write_text("\n".join(dumps_canonical(event) for event in events) + "\n", encoding="utf-8")
        result = store.audit()
        self.assertEqual(result["status"], "FAIL")
        self.assertTrue(any("wrapper" in failure and "unknown private" in failure for failure in result["failures"]))


class PrewriteCrossRecordTests(StoreHarness):
    def test_hinge_with_unknown_basis_is_rejected_before_write(self) -> None:
        _, store = self.make_store()
        candidate = store.record("candidate", "P0")
        backward = store.record("backward_sweep", valid_backward(), dependencies=[candidate["artifact_id"]])
        forward = store.record("forward_sweep", valid_forward(), dependencies=[candidate["artifact_id"]])
        hinges = valid_hinges()
        hinges["hinges"][0]["basis_refs"] = ["B-INVENTED"]
        before = len(store.events())
        with self.assertRaisesRegex(RecordError, "unknown basis_refs"):
            store.record("hinge_set", hinges, dependencies=[candidate["artifact_id"], backward["artifact_id"], forward["artifact_id"]])
        self.assertEqual(len(store.events()), before)

    def test_trial_hinge_orientation_fields_and_evidence_are_checked_prewrite(self) -> None:
        _, store = self.make_store()
        _, _, _, hinge = self.through_hinges(store)
        mutations = []
        unknown_hinge = valid_trials()
        unknown_hinge["trials"][0]["hinge_id"] = "H-INVENTED"
        mutations.append(unknown_hinge)
        invented_evidence = valid_trials()
        invented_evidence["trials"][0]["evidence_refs"] = ["B-INVENTED"]
        mutations.append(invented_evidence)
        reversed_orientation = valid_trials()
        reversed_orientation["trials"][0]["candidate"] = "B"
        reversed_orientation["trials"][0]["rival"] = "A"
        mutations.append(reversed_orientation)
        wrong_fields = valid_trials()
        wrong_fields["trials"][0]["changed_return_fields"] = ["reentry"]
        mutations.append(wrong_fields)
        for payload in mutations:
            with self.subTest(payload=payload["trials"][0]):
                with self.assertRaises(RecordError):
                    store.record("trial", payload, dependencies=[hinge["artifact_id"]])

    def test_cumulative_trial_moves_enforce_run_budget(self) -> None:
        _, store = self.make_store(max_moves=2)
        _, _, _, hinge = self.through_hinges(store)
        first = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        extra = copy.deepcopy(valid_trials())
        extra["trials"] = [extra["trials"][0]]
        extra["trials"][0]["trial_id"] = "T-3"
        with self.assertRaisesRegex(RecordError, "cumulative Trial moves 3 exceed max_moves 2"):
            store.record("trial", extra, dependencies=[hinge["artifact_id"]])
        self.assertIsNotNone(first)

    def test_binding_invented_refs_are_rejected_prewrite(self) -> None:
        _, store = self.make_store()
        _, _, _, hinge = self.through_hinges(store)
        trial = store.record("trial", valid_trials(), dependencies=[hinge["artifact_id"]])
        fields = [
            ("hinge_refs", ["H-INVENTED"]),
            ("trial_refs", ["T-INVENTED"]),
            ("basis_refs", ["B-INVENTED"]),
            ("dependencies", ["B-INVENTED"]),
        ]
        for field, replacement in fields:
            bindings = valid_bindings()
            bindings["bindings"][0][field] = replacement
            with self.subTest(field=field):
                with self.assertRaises(RecordError):
                    store.record("binding_set", bindings, dependencies=[hinge["artifact_id"], trial["artifact_id"]])
        bindings = valid_bindings()
        bindings["bindings"][0]["warrant"]["witness_refs"] = ["B-INVENTED"]
        with self.assertRaises(RecordError):
            store.record("binding_set", bindings, dependencies=[hinge["artifact_id"], trial["artifact_id"]])

    def test_passage_model_invented_evidence_is_rejected_prewrite(self) -> None:
        _, store = self.make_store()
        model = replace_refs(load_strict(ROOT / "examples" / "mine" / "passage_model.json"), {"B-MINE": "B-PUBLIC", "B-INSPECTION": "B-HIDDEN"})
        model["evidence_refs"].append("B-INVENTED")
        with self.assertRaisesRegex(RecordError, "unknown basis/evidence refs"):
            store.record("passage_model", model, dependencies=["B-PUBLIC", "B-HIDDEN"])

    def test_return_requires_current_support_refs_and_exact_cumulative_budget(self) -> None:
        _, store = self.make_store()
        candidate, hinge, trial, binding, seal = self.through_seal(store)
        dependencies = [candidate["artifact_id"], hinge["artifact_id"], trial["artifact_id"], binding["artifact_id"], seal["artifact_id"], "B-PUBLIC", "B-HIDDEN"]
        bad_ref = valid_return()
        bad_ref["components"][0]["dependency_refs"].append("B-INVENTED")
        with self.assertRaisesRegex(RecordError, "unknown support refs"):
            store.record("return_envelope", bad_ref, dependencies=dependencies)
        bad_budget = valid_return()
        bad_budget["stop_basis"]["move_budget"] = {"used": 1, "maximum": 4, "remaining": 3, "outcome": "OPEN", "basis": "wrong count"}
        with self.assertRaisesRegex(RecordError, "does not match cumulative Trial moves"):
            store.record("return_envelope", bad_budget, dependencies=dependencies)

    def test_outcome_requires_current_return_and_known_refs_prewrite(self) -> None:
        _, store = self.make_store()
        candidate, hinge, trial, binding, seal = self.through_seal(store)
        return_event = store.record(
            "return_envelope",
            valid_return(),
            dependencies=[candidate["artifact_id"], hinge["artifact_id"], trial["artifact_id"], binding["artifact_id"], seal["artifact_id"], "B-PUBLIC", "B-HIDDEN"],
        )
        outcome = replace_refs(load_strict(ROOT / "examples" / "mine" / "outcome.json"), {"B-MINE": "B-PUBLIC", "B-INSPECTION": "B-HIDDEN"})
        with self.assertRaisesRegex(RecordError, "current ReturnEnvelope"):
            store.record("outcome_receipt", outcome, dependencies=[])
        outcome["stages"]["recommendation"]["evidence_refs"].append("B-INVENTED")
        with self.assertRaisesRegex(RecordError, "unknown evidence_refs"):
            store.record("outcome_receipt", outcome, dependencies=[return_event["artifact_id"]])


class SelectiveReentryTests(StoreHarness):
    def through_return(self, store: RunStore):
        candidate, hinge, trial, binding, seal = self.through_seal(store)
        returned = store.record(
            "return_envelope",
            valid_return(),
            dependencies=[
                candidate["artifact_id"],
                hinge["artifact_id"],
                trial["artifact_id"],
                binding["artifact_id"],
                seal["artifact_id"],
                "B-PUBLIC",
                "B-HIDDEN",
            ],
        )
        return hinge, trial, returned

    def test_logical_hinge_and_trial_reach_only_their_binding_field(self) -> None:
        _, store = self.make_store()
        self.through_return(store)
        for changed_ref in ("H-1", "T-1"):
            with self.subTest(changed_ref=changed_ref):
                result = store.reopen([changed_ref])
                self.assertEqual(result["affected_fields"], ["answer"])
                self.assertEqual(result["unchanged_fields"], ["reentry"])
                self.assertEqual(result["unknown_refs"], [])

    def test_changed_hinge_and_trial_artifacts_reach_contained_bindings(self) -> None:
        _, store = self.make_store()
        hinge, trial, _ = self.through_return(store)
        for changed_ref in (hinge["artifact_id"], trial["artifact_id"]):
            with self.subTest(changed_ref=changed_ref):
                result = store.reopen([changed_ref])
                self.assertEqual(result["affected_fields"], ["answer", "reentry"])
                self.assertEqual(result["unchanged_fields"], [])

    def test_unrelated_known_artifact_carries_disjoint_return_fields(self) -> None:
        _, store = self.make_store()
        self.through_return(store)
        unrelated = store.record("note", "not cited by the Return")
        result = store.reopen([unrelated["artifact_id"]])
        self.assertEqual(result["outcome"], "EARNED")
        self.assertEqual(result["affected_fields"], [])
        self.assertEqual(result["unchanged_fields"], ["answer", "reentry"])
        self.assertEqual(result["unknown_refs"], [])

    def test_runspec_change_reopens_every_return_field(self) -> None:
        _, store = self.make_store()
        self.through_return(store)
        result = store.reopen(["RUNSPEC"])
        self.assertEqual(result["affected_fields"], ["answer", "reentry"])
        self.assertEqual(result["unchanged_fields"], [])

    def test_seal_and_reentry_cannot_be_recorded_generically(self) -> None:
        _, store = self.make_store()
        for kind in ("seal", "reentry", "passage_assessment"):
            with self.subTest(kind=kind):
                with self.assertRaisesRegex(RecordError, "derived record"):
                    store.record(kind, {})

    def test_passage_assessment_is_exactly_derived_from_current_model(self) -> None:
        _, store = self.make_store()
        model = replace_refs(
            load_strict(ROOT / "examples" / "mine" / "passage_model.json"),
            {"B-MINE": "B-PUBLIC", "B-INSPECTION": "B-HIDDEN"},
        )
        model_event = store.record("passage_model", model, dependencies=["B-PUBLIC", "B-HIDDEN"])
        assessment_event = store.assess_passage(state="C-ACCESSIBLE", successor="C-COLLAPSED")
        wrapper = store._read_wrapper(assessment_event)
        from architecture_plus.passage import assess
        self.assertEqual(wrapper["payload"], assess(model, "C-ACCESSIBLE", "C-COLLAPSED"))
        self.assertEqual(assessment_event["dependencies"], [model_event["artifact_id"]])


if __name__ == "__main__":
    unittest.main()
