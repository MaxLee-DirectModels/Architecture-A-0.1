from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))

from architecture_plus.field import activate


class FieldNoiseTests(unittest.TestCase):
    def test_generic_noise_does_not_activate_terms_or_operators(self) -> None:
        for query in (
            "something about things and stuff",
            "we need to think about the problem and make a good answer",
            "foo bar baz quux",
        ):
            with self.subTest(query=query):
                result = activate(ROOT, query, limit=12, operator_limit=4)
                self.assertEqual(result["status"], "OPEN")
                self.assertEqual(result["terms"], [])
                self.assertEqual(result["operators"], [])

    def test_exact_operator_name_remains_addressable(self) -> None:
        result = activate(ROOT, "Native Forge", limit=2, operator_limit=2)
        self.assertEqual(result["status"], "LOOKUP")
        self.assertTrue(any(item["name"] == "Native Forge" for item in result["operators"]))


if __name__ == "__main__":
    unittest.main()
