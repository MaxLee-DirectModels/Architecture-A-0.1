# Architecture+ 0.1 — executable packet

Architecture+ organizes declared actors' inquiry, creation, action,
consequence, and learning within their authority. Passage Theory supplies
conditional predictions only through explicit, domain-local Passage Models.
Subsystems: Architecture+ Operating Core (architecture), Consequence Compiler
(reference runtime), Earned Structure (persistence doctrine).
`spec/system.json` is the sole normative source. The code is a finite executable
projection of that source, not a truth engine, universal ontology, domain model,
authority system, safety system, or world-action engine.
The reference runtime, CLI, audits, and tests use only the Python standard
library.

## Run it

Requires Python 3.10+ and no third-party packages. From this directory:

```bash
PYTHONPATH=runtime python -m architecture_plus inspect
PYTHONPATH=runtime python -m architecture_plus verify
PYTHONPATH=runtime python -m unittest discover -s tests -v
PYTHONPATH=runtime python -m architecture_plus demo --output /tmp/aplus-mine-demo
```

Start a run and emit its NATIVE formation prompt. The CLI phase name `free` is
the implementation alias for canonical mode `NATIVE`:

```bash
PYTHONPATH=runtime python -m architecture_plus init \
  --spec examples/mine/run_spec.json --run /tmp/aplus-run
PYTHONPATH=runtime python -m architecture_plus prompt \
  --run /tmp/aplus-run --phase free --output /tmp/p0-prompt.txt
PYTHONPATH=runtime python -m architecture_plus record \
  --run /tmp/aplus-run --kind candidate --input examples/mine/candidate.txt
```

P0 can be recorded once. The runtime fingerprints a NATIVE prompt projection
containing only the raw request, explicitly exposed Basis, unavoidable policy
IDs, declared tools, and requested output form. That does not prove what an
external model host actually exposed. Unless the full effective invocation and
context are controlled and attested, the manifest records that question as
OPEN.

After recording independent `backward_sweep`, `forward_sweep`, `hinge_set`,
`trial`, and `binding_set` artifacts, derive a Seal:

```bash
PYTHONPATH=runtime python -m architecture_plus seal --run /tmp/aplus-run
PYTHONPATH=runtime python -m architecture_plus prompt \
  --run /tmp/aplus-run --phase return
```

## Commands

- `init` freezes a RunSpec.
- `prompt` renders one boundary-controlled phase.
- `record` appends a validated structured artifact or an explicitly raw carrier
  (`candidate`, `note`, or `external_evidence`) to the deterministic hash chain.
- `passage` assesses a supplied finite Passage Model; successor comparison
  requires an explicit `PASSAGE_IDENTITY` relation K. Explicit correspondence
  remains OPEN in 0.1.
- `activate` retrieves capped, nonnormative term and operator slices from the
  dormant reserves. Retrieval proposes probes and interventions; it supplies no
  evidence or authority.
- `seal` fingerprints the current record boundary, open obligations, and
  represented operation intent. It is not an independent permission or
  execution engine.
- `audit` verifies local structure, dependencies, manifests, and hash chain.
- `reopen` finds the dependency-reachable Return slice after change.
- `create-child --child-spec CHILD_RUN_SPEC.json` validates the complete changed
  material and lineage before appending Reentry, preserves the parent prefix,
  then initializes the child. Its new RunSpec is frozen before new work or Seal.
- `OutcomeReceipt` permits runtime `EARNED` only for recommendation. Stages
  from choice through durability remain `OPEN` with disposition `UNKNOWN` or
  `NOT_APPLICABLE` until typed external stage profiles exist.
- `freeze` writes `MANIFEST.json`; `verify` checks the packet and manifest.
- `demo` builds and audits the complete mine example.

PASS means local finite conformance to the packet's declared structural contracts. It
does not establish truth, input authenticity, authority, permission,
legitimacy, safety, occurrence, causation, world effect, durability, open-world
completeness, or comparative value.

## Packet map

- `spec/system.json` — sole normative authority.
- `theory/passage.json` — exact Passage Theory projection and local-model
  contract.
- `runtime/` — deterministic records, prompts, audit, replay, reentry, Passage
  assessment, and package verification.
- `reserve/lexicon.json` — dormant 762-term probe reserve.
- `reserve/operators.json` — dormant 38-card intervention reserve; each card
  carries a trigger, requirements, predicted changed fields, falsifier, cost,
  contraindications, evidence lineage, and lease.
- `reserve/anomalies.jsonl` — useful historical anomalies and their release
  consequences.
- `qualification/coverage.json`, `tools/audit_coverage.py`, and `tests/` — every
  declared 0.1 obligation has an executable, structural, or exact OPEN
  disposition; adversarial checks reject false crossings.
- `examples/mine/` — worked Configuration–Passage–Consequence example.
- `docs/README_Plus_0.1.docx` — manifested human-resolution carrier; faithful
  to the normative source but not itself normative.

The compiled `README+ 0.1` document ships in the packet. Its
`tools/build_readme_plus_docx.py` builder is excluded because it requires
`python-docx`; the executable packet remains standard-library-only.
